import express from 'express';
import { MercadoPagoConfig, Preference } from 'mercadopago';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDoc, collection, getDocs } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';
import 'dotenv/config';

const firebaseConfigRaw = fs.readFileSync(path.join(process.cwd(), 'firebase-applet-config.json'), 'utf8');
const firebaseConfig = JSON.parse(firebaseConfigRaw);
const appFirebase = initializeApp(firebaseConfig);
const db = getFirestore(appFirebase, firebaseConfig.firestoreDatabaseId);

export const app = express();

app.use(express.json());

// API constraints check
if (!process.env.MERCADOPAGO_ACCESS_TOKEN) {
  console.warn("WARNING: MERCADOPAGO_ACCESS_TOKEN is missing. MercadoPago integration will fail until configured.");
}

app.post('/api/mercadopago/preference', async (req, res) => {
  try {
    const { orderId, payer } = req.body;
    const accessToken = process.env.MERCADOPAGO_ACCESS_TOKEN;
    
    if (!accessToken) {
      return res.status(500).json({ error: 'MERCADOPAGO_ACCESS_TOKEN no está configurado.' });
    }

    if (!orderId) {
      return res.status(400).json({ error: 'orderId es requerido.' });
    }

    // 1. Fetch order from DB to secure the price
    const orderRef = doc(db, 'orders', orderId);
    const orderSnap = await getDoc(orderRef);
    
    if (!orderSnap.exists()) {
      return res.status(404).json({ error: 'Pedido no encontrado en la base de datos.' });
    }

    const orderData = orderSnap.data();

    // 2. Validate price against DB to prevent Client-Side Price Spoofing
    const productsSnap = await getDocs(collection(db, 'products'));
    const productsMap = new Map();
    productsSnap.forEach(doc => productsMap.set(doc.id, doc.data()));

    let realSubtotal = 0;
    if (Array.isArray(orderData.items)) {
      for (const item of orderData.items) {
         const p = productsMap.get(item.id);
         if (p) {
            const price = (p.isOffer && p.offerPrice) ? p.offerPrice : p.price;
            realSubtotal += (price * (item.quantity || 1));
         }
      }
    }

    let realDiscount = 0;
    if (orderData.coupon === 'FIDELITY') {
       const settingsRef = doc(db, 'settings', 'store');
       const settingsSnap = await getDoc(settingsRef);
       const settingsData = settingsSnap.data() || {};
       
       const cleanPhone = String(orderData.phone || '').replace(/\D/g, '');
       const fidelityRef = doc(db, 'customerFidelity', cleanPhone);
       const fidelitySnap = await getDoc(fidelityRef);
       
       const fidelityFreq = settingsData.fidelityFrequency !== undefined ? settingsData.fidelityFrequency : 3;
       const fidelityThreshold = settingsData.fidelityThreshold !== undefined ? settingsData.fidelityThreshold : 20000;
       const count = fidelitySnap.exists() ? (fidelitySnap.data().count || 0) : 0;
       
       if (count === 0 || count % fidelityFreq !== 0 || realSubtotal < fidelityThreshold) {
           return res.status(400).json({ error: 'No calificás para el descuento de fidelidad.' });
       }

       const fidelityPercent = settingsData.fidelityDiscount !== undefined ? settingsData.fidelityDiscount : 15;
       const expectedFidelityDiscount = Math.round(realSubtotal * (fidelityPercent / 100));

       if (Math.abs(orderData.discount - expectedFidelityDiscount) > 10) { 
           return res.status(400).json({ error: 'Descuento manipulado.' });
       }
       realDiscount = orderData.discount;
    } else if (orderData.coupon) {
       const couponRef = doc(db, 'coupons', orderData.coupon);
       const couponSnap = await getDoc(couponRef);
       
       if (couponSnap.exists()) {
          const data = couponSnap.data();
          if (data.active) {
              if (data.type === 'percentage') {
                 realDiscount = Math.round(realSubtotal * (data.value / 100));
              } else {
                 realDiscount = data.value;
              }
          }
       }
    }
    
    const realDelivery = orderData.deliveryCost || 0;
    if (orderData.method === 'delivery' && orderData.zone) {
       const settingsRef = doc(db, 'settings', 'store');
       const settingsSnap = await getDoc(settingsRef);
       const settingsData = settingsSnap.data() || {};
       if (settingsData.deliveryZones && Array.isArray(settingsData.deliveryZones)) {
          const z = settingsData.deliveryZones.find((z: any) => z.name === orderData.zone);
          if (z && realDelivery < z.price) {
              return res.status(400).json({ error: 'Costo de envío manipulado.' });
          }
       }
    }

    const expectedTotal = Math.max(0, realSubtotal - realDiscount) + realDelivery;

    if (Math.abs(orderData.totalAmount - expectedTotal) > 10) {
        return res.status(400).json({ error: 'El monto del pedido es incorrecto.' });
    }

    const client = new MercadoPagoConfig({ accessToken, options: { timeout: 5000 } });
    const preference = new Preference(client);

    const protocol = req.headers['x-forwarded-proto'] || 'https';
    const host = req.headers['x-forwarded-host'] || req.get('host') || req.hostname;
    
    let origin = req.headers.origin;
    if (origin === 'null') origin = undefined;
    
    let referer = req.headers.referer?.split('?')[0].replace(/\/$/, '');
    if (referer === 'null') referer = undefined;

    // VERCEL SPECIFIC BASE URL LOGIC
    let baseUrl = origin || referer || `${protocol}://${host}`;
    if (process.env.VERCEL_URL) {
      baseUrl = `https://${process.env.VERCEL_URL}`;
    }

    let orderTitle = 'Pedido Minami Sushi';
    if (orderData.items && orderData.items.length > 0) {
      orderTitle += ` (${orderData.items.length} items)`;
    }

    const preferenceData = {
      items: [{
        id: orderId,
        title: orderTitle,
        quantity: 1,
        unit_price: orderData.totalAmount, 
      }],
      payer: {
        name: payer.name || orderData.name,
        email: payer.email || 'customer@example.com'
      },
      external_reference: orderId,
      back_urls: {
        success: `${baseUrl}/?mp_success=true&order_id=${orderId}`,
        pending: `${baseUrl}/?mp_pending=true&order_id=${orderId}`,
        failure: `${baseUrl}/?mp_failure=true&order_id=${orderId}`
      },
      auto_return: 'approved' as const,
    };

    const result = await preference.create({ body: preferenceData });
    res.json({ id: result.id, init_point: result.init_point });
  } catch (error: any) {
    console.error('Error creating preference:', error.message || error);
    res.status(500).json({ error: error.message || 'No se pudo crear la preferencia de Mercado Pago.' });
  }
});
