/**
 * Converts a Google Drive sharing link into a direct image source URL.
 * Supports standard sharing links and direct /uc?id= links.
 */
export function getDirectImageUrl(url: string | undefined | null): string {
  if (!url) return '';
  
  const trimmedUrl = url.trim();
  
  // If it's a data URL, return as is
  if (trimmedUrl.startsWith('data:image/')) return trimmedUrl;

  // Dropbox support
  if (trimmedUrl.includes('dropbox.com')) {
    // Convert to direct download link
    const base = trimmedUrl.split('?')[0];
    return base.replace('www.dropbox.com', 'dl.dropboxusercontent.com') + '?raw=1';
  }

  // Handle Google Drive links
  if (trimmedUrl.includes('drive.google.com') || trimmedUrl.includes('docs.google.com') || trimmedUrl.includes('google.com/open')) {
    try {
      let fileId = '';

      // Pattern 1: /file/d/FILE_ID/view
      if (trimmedUrl.includes('/file/d/')) {
        const parts = trimmedUrl.split('/file/d/');
        if (parts.length > 1) {
          fileId = parts[1].split('/')[0].split('?')[0].split('#')[0];
        }
      } 
      // Pattern 2: ?id=FILE_ID or &id=FILE_ID or open?id=FILE_ID
      else if (trimmedUrl.includes('id=')) {
        const match = trimmedUrl.match(/[?&]id=([a-zA-Z0-9_-]{25,})/);
        if (match) {
          fileId = match[1];
        } else {
          // Alternative ID match for shorter IDs if they exist (though usually 33 chars)
          const shortMatch = trimmedUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
          if (shortMatch) fileId = shortMatch[1];
        }
      }
      // Pattern 3: /uc?id=FILE_ID
      else if (trimmedUrl.includes('/uc')) {
        const match = trimmedUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
        if (match) fileId = match[1];
      }

      if (fileId && fileId.length > 5) {
        // This is a more stable hotlinking endpoint for Drive images
        return `https://lh3.googleusercontent.com/d/${fileId}`;
      }
    } catch (e) {
      console.error("Error parsing Google Drive URL", e);
    }
  }

  return trimmedUrl;
}
