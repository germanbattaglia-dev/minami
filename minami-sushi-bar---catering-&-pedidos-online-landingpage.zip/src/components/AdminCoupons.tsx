import React, { useState } from 'react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc, deleteDoc, addDoc, collection, serverTimestamp, setDoc } from 'firebase/firestore';
import { Plus, Trash2, Edit2, Play, Square, Percent, Banknote } from 'lucide-react';

export default function AdminCoupons({ coupons }: { coupons: any[] }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<any>(null);
  
  const defaultForm = { code: '', type: 'percentage', value: '', minAmount: '', active: true };
  const [form, setForm] = useState(defaultForm);

  const openModal = (coupon?: any) => {
    if (coupon) {
      setEditingCoupon(coupon);
      setForm({
        code: coupon.code,
        type: coupon.type,
        value: String(coupon.value),
        minAmount: coupon.minAmount ? String(coupon.minAmount) : '',
        active: !!coupon.active
      });
    } else {
      setEditingCoupon(null);
      setForm(defaultForm);
    }
    setIsModalOpen(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data: any = {
        code: form.code.toUpperCase().trim(),
        type: form.type,
        value: Number(form.value),
        active: form.active,
        createdAt: editingCoupon ? editingCoupon.createdAt : serverTimestamp()
      };
      if (form.minAmount) data.minAmount = Number(form.minAmount);
      
      if (editingCoupon) {
        // If they changed the code, we would theoretically need to create new and delete old, 
        // but for simplicity we assume code can't be edited or we just update.
        // Actually, let's keep using updateDoc if editing. Wait, code shouldn't change.
        const codeDiff = form.code.toUpperCase().trim() !== editingCoupon.code;
        if(codeDiff) {
           await deleteDoc(doc(db, 'coupons', editingCoupon.id));
           await setDoc(doc(db, 'coupons', form.code.toUpperCase().trim()), data);
        } else {
           await updateDoc(doc(db, 'coupons', editingCoupon.id), data);
        }
      } else {
        await setDoc(doc(db, 'coupons', form.code.toUpperCase().trim()), data);
      }
      setIsModalOpen(false);
    } catch (e) {
      handleFirestoreError(e, editingCoupon ? OperationType.UPDATE : OperationType.CREATE, 'coupons');
    }
  };

  const del = async (id: string) => {
    if(!window.confirm("¿Seguro de eliminar este cupón?")) return;
    try {
      await deleteDoc(doc(db, 'coupons', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `coupons/${id}`);
    }
  };

  const toggleActive = async (coupon: any) => {
    try {
      await updateDoc(doc(db, 'coupons', coupon.id), { active: !coupon.active });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `coupons/${coupon.id}`);
    }
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-display font-bold text-brand-black">Cupones de Descuento</h1>
          <p className="text-brand-gray">Crear códigos promocionales o para fidelidad.</p>
        </div>
        <button onClick={() => openModal()} className="flex items-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white px-4 py-2 rounded-full shadow-sm text-sm font-bold transition-colors">
          <Plus size={18} /> Nuevo Cupón
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
          {coupons.length === 0 ? (
            <div className="col-span-full py-12 text-center text-gray-400 italic bg-gray-50 rounded-xl border border-dashed border-gray-200">No hay cupones.</div>
          ) : coupons.map(c => (
            <div key={c.id} className={`border ${c.active ? 'border-brand-orange' : 'border-gray-200 opacity-60'} rounded-xl p-5 shadow-sm relative group bg-white`}>
              <div className="flex justify-between items-start mb-2">
                <span className="font-mono text-xl font-bold bg-gray-100 px-2 py-1 rounded inline-block tracking-widest text-brand-black">{c.code}</span>
                <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-full ${c.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>{c.active ? 'Activo' : 'Inactivo'}</span>
              </div>
              <div className="flex items-center gap-2 text-3xl font-bold text-brand-orange mb-4">
                {c.type === 'percentage' ? <><Percent size={28}/> {c.value}</> : <><Banknote size={28}/> {c.value}</>}
              </div>
              {c.minAmount && <div className="text-xs text-gray-500 mb-4 whitespace-nowrap">Mínimo: ${c.minAmount.toLocaleString()}</div>}
              
              <div className="flex gap-2 justify-end border-t border-gray-100 pt-3">
                <button onClick={() => toggleActive(c)} className="w-8 h-8 rounded bg-gray-50 text-gray-600 flex items-center justify-center hover:bg-gray-200 transition-colors" title={c.active ? "Desactivar" : "Activar"}>{c.active ? <Square size={14}/> : <Play size={14}/>}</button>
                <button onClick={() => openModal(c)} className="w-8 h-8 rounded bg-gray-50 text-gray-600 flex items-center justify-center hover:bg-blue-50 hover:text-blue-600 transition-colors"><Edit2 size={14}/></button>
                <button onClick={() => del(c.id)} className="w-8 h-8 rounded bg-gray-50 text-gray-600 flex items-center justify-center hover:bg-red-50 hover:text-red-500 transition-colors"><Trash2 size={14}/></button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-brand-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl p-6">
            <h2 className="text-2xl font-bold mb-6">{editingCoupon ? 'Editar' : 'Nuevo'} Cupón</h2>
            <form onSubmit={save} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Código</label>
                <input required type="text" value={form.code} onChange={e=>setForm({...form, code: e.target.value.toUpperCase()})} className="w-full border p-2 rounded focus:border-brand-orange outline-none font-mono uppercase" placeholder="EJ: SUSHI20" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Tipo</label>
                  <select value={form.type} onChange={e=>setForm({...form, type: e.target.value})} className="w-full border p-2 rounded focus:border-brand-orange outline-none bg-white">
                    <option value="percentage">Porcentaje (%)</option>
                    <option value="fixed">Monto Fijo ($)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Valor</label>
                  <input required type="number" min="1" value={form.value} onChange={e=>setForm({...form, value: e.target.value})} className="w-full border p-2 rounded focus:border-brand-orange outline-none" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Monto Mínimo de Compra (Opcional)</label>
                <input type="number" min="0" value={form.minAmount} onChange={e=>setForm({...form, minAmount: e.target.value})} className="w-full border p-2 rounded focus:border-brand-orange outline-none" placeholder="Ej: 15000" />
              </div>
              <div className="pt-4 flex gap-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 bg-gray-100 rounded-lg font-bold">Cancelar</button>
                <button type="submit" className="flex-1 px-4 py-2 bg-brand-orange text-white rounded-lg font-bold">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
