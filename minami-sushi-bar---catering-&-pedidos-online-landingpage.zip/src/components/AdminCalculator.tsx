import React, { useMemo, useState } from 'react';
import { ClipboardList, CheckSquare, Printer, Eye, X } from 'lucide-react';

// Helper to render Truco-style tally marks
const TallyMarks = ({ count, size = 'sm', color = 'brand-orange' }: { count: number, size?: 'xs' | 'sm' | 'lg', color?: string }) => {
  const safeCount = Number(count) || 0;
  const fullSquares = Math.floor(safeCount / 5);
  const remainder = Math.floor(safeCount % 5);
  
  const boxClass = size === 'lg' ? 'w-8 h-8' : size === 'xs' ? 'w-3 h-3' : 'w-5 h-5';
  // Use explicit border color for printing reliability
  const borderStyle = color === 'black' ? '1.5px solid black' : '1.5px solid #FF5001';
  const bgColorStyle = color === 'black' ? 'black' : '#FF5001';

  return (
    <div className="flex flex-wrap gap-1.5 items-center" style={{ WebkitPrintColorAdjust: 'exact', printColorAdjust: 'exact' }}>
      {[...Array(fullSquares)].map((_, i) => (
        <div key={i} className={`relative ${boxClass} shrink-0`} style={{ border: borderStyle }}>
          <div className="absolute top-0 left-0 w-[140%] h-[1.5px] origin-top-left rotate-[45deg]" style={{ background: bgColorStyle }}></div>
        </div>
      ))}
      {remainder > 0 && (
        <div className={`relative ${boxClass} shrink-0`}>
          {remainder >= 1 && <div className="absolute top-0 left-0 w-[1.5px] h-full" style={{ background: bgColorStyle }}></div>}
          {remainder >= 2 && <div className="absolute top-0 left-0 w-full h-[1.5px]" style={{ background: bgColorStyle }}></div>}
          {remainder >= 3 && <div className="absolute top-0 right-0 w-[1.5px] h-full" style={{ background: bgColorStyle }}></div>}
          {remainder >= 4 && <div className="absolute bottom-0 left-0 w-full h-[1.5px]" style={{ background: bgColorStyle }}></div>}
        </div>
      )}
    </div>
  );
};

export default function AdminCalculator({ orders }: { orders: any[] }) {
  const [showPreview, setShowPreview] = useState(false);
  const pendingOrders = orders.filter(o => !o.isCompleted && o.forAssembly);
  
  const preparationList = useMemo(() => {
    const itemsMap: Record<string, { name: string, totalCount: number, markCount: number, category: string, isSushi: boolean }> = {};
    
    function processItem(item: any, quantityMultiplier: number = 1) {
      if (!item || !item.name) return;

      // Handle Combos
      if (item.comboContents && item.comboContents.trim()) {
        const lines = item.comboContents.split('\n').filter((l: string) => l.trim());
        lines.forEach((line: string) => {
          // Handle formats like "1x Name", "1 x Name", or just "Name" (which assumes 1)
          const match = line.match(/^(\d+)\s*[xX]\s*(.*)$/) || line.match(/^(\d+)\s+(.*)$/);
          
          if (match) {
            const qty = parseInt(match[1]);
            const name = match[2].trim();
            if (!name) return;
            const lowerName = name.toLowerCase();
            let subCat = 'rolls';
            if (lowerName.includes('salsa')) subCat = 'salsas';
            else if (lowerName.includes('nigiri') || lowerName.includes('sashimi') || lowerName.includes('geisha')) subCat = 'nigiri';
            
            processItem({
              id: 'sub-' + lowerName.replace(/\s+/g, '-'),
              name: name,
              category: subCat,
              quantity: qty * item.quantity
            }, 1);
          } else {
             const name = line.trim();
             if (!name) return;
             const lowerName = name.toLowerCase();
             let subCat = 'rolls';
             if (lowerName.includes('salsa')) subCat = 'salsas';
             else if (lowerName.includes('nigiri') || lowerName.includes('sashimi') || lowerName.includes('geisha')) subCat = 'nigiri';

             processItem({
              id: 'sub-' + lowerName.replace(/\s+/g, '-'),
              name: name,
              category: subCat,
              quantity: 1 * item.quantity
            }, 1);
          }
        });
        return;
      }

      const catVal = (item.category || '').trim().toLowerCase();

      // Explicitly skip items in the 'combinados' category if they were not already desglosados
      // This ensures that even if it doesn't have comboContents, it won't show up in the tally.
      // Also skip 'extras' category entirely as it is not part of the preparation list.
      if (catVal === 'combinados' || catVal === 'extras') {
        return;
      }
      const nameLower = (item.name || '').trim().toLowerCase();
      
      const isNigiri = nameLower.includes('nigiri') || catVal === 'nigiri' || nameLower.includes('sashimi') || nameLower.includes('geisha') || catVal === 'sashimi' || catVal === 'geishas';
      
      const knownSushiRolls = ['calipso', 'bariloche', 'buenos aires', 'orlando', 'masuki', 'tokio', 'new york', 'philadelphia', 'bs as', 'bsas', 'salmon', 'atun', 'vegetariano', 'vegano', 'roll', 'maki', 'calafate'];
      const matchesSushiName = knownSushiRolls.some(k => nameLower.includes(k));

      // All sushi rolls should get the 0.5 mutliplier. 
      // If category is rolls but it's nigiri (sashimi, geishas), nigiri overrides it to not use the 0.5 multiplier.
      const isSushi = (catVal === 'rolls' || catVal === 'veggie' || matchesSushiName || (!catVal && !!item.pieces)) && !isNigiri && !catVal.includes('salsa') && catVal !== 'extras' && catVal !== 'picoteo' && !nameLower.includes('salsa');

      const normalizedName = String(item.name || '').normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
      const itemId = normalizedName.replace(/[^a-z0-9]/g, '-');

      if (!itemsMap[itemId]) {
        let finalCat = catVal || 'other';
        if (isSushi) finalCat = 'rolls';
        else if (isNigiri) finalCat = 'nigiri';
        else if (catVal.includes('salsa') || nameLower.includes('salsa')) finalCat = 'salsas';
        else if (catVal === 'extras' || catVal === 'picoteo') finalCat = catVal;

        itemsMap[itemId] = { 
          name: String(item.name || '').trim(), 
          totalCount: 0, 
          markCount: 0, 
          category: finalCat,
          isSushi
        };
      }
      
      const currentItem = itemsMap[itemId];
      
      // Logic: 
      // Planilla de Armado Sushi: 1 palito = 0.5 un. -> means 1 unit = 2 palitos.
      // Otros: 1 palito = 1 un. -> means 1 unit = 1 palito.
      
      const quantityVal = Number(item.quantity) || 0;
      const units = quantityVal * quantityMultiplier;
      
      if (currentItem.isSushi) {
        // Sushi: 1 unit order = 0.5 internal units (where 1 full unit = 2 pieces)
        currentItem.markCount += units;
        currentItem.totalCount += units * 0.5;
      } else {
        // Others: 1 unit = 1 mark
        currentItem.markCount += units;
        currentItem.totalCount += units;
      }
    }

    pendingOrders.forEach(order => {
      if (order.items && Array.isArray(order.items)) {
        order.items.forEach((item: any) => processItem(item));
      }
    });

    return Object.values(itemsMap).sort((a, b) => b.totalCount - a.totalCount);
  }, [pendingOrders]);

  const totalRawRiceGrams = useMemo(() => {
    let grams = 0;
    preparationList.forEach(item => {
      if (item.isSushi) {
        grams += item.totalCount * 45; // Sushi rolls: 45g per 1 totalCount (2 marks)
      } else if (item.category === 'nigiri') {
        grams += item.totalCount * 22.5; // Nigiri: 22.5g per 1 totalCount (1 mark)
      }
    });
    return Math.round(grams);
  }, [preparationList]);

  const marmasInfo = useMemo(() => {
    const totalVarieties = preparationList
      .filter(item => item.category === 'rolls')
      .reduce((acc, item) => acc + item.markCount, 0);
      
    const marmasCount = Math.floor(totalVarieties / 4);
    const residualVarieties = totalVarieties % 4;
    
    return {
      totalVarieties,
      marmasCount,
      residualVarieties
    };
  }, [preparationList]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden h-full flex flex-col">
      <div className="p-4 lg:p-6 border-b border-gray-100 bg-brand-black text-white flex flex-col lg:flex-row justify-between items-center gap-4 lg:gap-8">
        {/* Left Section - Title */}
        <div className="flex-1 w-full flex flex-col items-center lg:items-start justify-center">
          <h2 className="text-2xl font-bold font-display flex items-center justify-center lg:justify-start gap-3 w-full">
            <ClipboardList className="text-brand-orange" />
            Planilla de Armado
          </h2>
        </div>

        {/* Center Section - Metrics */}
        <div className="flex-[2] flex flex-wrap justify-center items-center gap-3 w-full">
          {marmasInfo.totalVarieties > 0 && (
            <div className="inline-flex items-center gap-1.5 text-white bg-brand-orange px-4 py-2 rounded-xl text-sm font-bold shadow-sm">
              <span className="text-xl">🍱</span>
              <span className="text-[15px]">{marmasInfo.marmasCount} {marmasInfo.marmasCount === 1 ? 'Marma' : 'Marmas'}</span>
              {marmasInfo.residualVarieties > 0 && (
                 <span className="text-white/80 font-semibold text-xs ml-1">
                   (+{marmasInfo.residualVarieties} variad.)
                 </span>
              )}
            </div>
          )}
          
          {totalRawRiceGrams > 0 && (
            <div className="inline-flex items-center gap-3 bg-white/10 px-4 py-2 rounded-xl text-sm border border-white/20">
              <span className="text-2xl">🍚</span>
              <div className="flex flex-col leading-none">
                <span className="text-white font-bold text-[15px]">{(totalRawRiceGrams / 1000).toFixed(2)} kg</span>
                <span className="text-[9px] text-gray-400 font-bold mt-1 tracking-wider uppercase">Arroz Crudo</span>
              </div>
              <div className="hidden sm:block border-l border-white/10 pl-3 ml-1">
                <span className="text-[10px] text-gray-400 leading-tight block">45g por unidad (2 pz)</span>
                <span className="text-[10px] text-gray-400 leading-tight block">22.5g por Nigiri (1 pz)</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Section - Buttons */}
        <div className="flex-1 flex w-full justify-center lg:justify-end gap-2">
          <button 
            onClick={() => setShowPreview(true)}
            className="bg-brand-orange hover:bg-brand-orange-dark text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-colors text-sm font-bold shadow-lg shadow-brand-orange/20"
          >
            <Eye size={18} /> Vista Ticket
          </button>
        </div>
      </div>
      
      <div className="p-4 overflow-y-auto flex-1 bg-gray-50/50">
        {preparationList.length === 0 ? (
          <div className="text-center text-gray-400 py-12 flex flex-col items-center gap-3">
            <CheckSquare size={48} className="text-gray-300" />
            <p className="text-lg">No hay pedidos pendientes.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Rice calculated in header */}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {preparationList.map((item, index) => (
                <div key={index} className="bg-white p-3 rounded-xl shadow-sm border border-gray-200 hover:border-brand-orange transition-all group flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-gray-900 text-[11px] leading-tight uppercase group-hover:text-brand-orange transition-colors flex-1 pr-1">
                      {item.name}
                    </h3>
                    <div className="text-right shrink-0">
                      <div className="text-md font-black text-brand-black leading-none">
                        {item.totalCount % 1 === 0 ? item.totalCount : (item.totalCount || 0).toFixed(1)}
                      </div>
                      <div className="text-[7px] font-bold text-gray-400 uppercase">Unid.</div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-2 border border-gray-100 mt-auto">
                    <TallyMarks count={item.markCount} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Printer Modal Preview */}
      {showPreview && (
        <div className="fixed inset-0 bg-brand-black/80 backdrop-blur-sm z-[300] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50">
              <span className="font-bold text-gray-900 font-display">Vista Ticket Térmico</span>
              <button onClick={() => setShowPreview(false)} className="text-gray-400 hover:text-red-500 transition-colors"><X size={24} /></button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 flex justify-center bg-gray-200">
              <div id="preparation-ticket" className="bg-white shadow-lg w-[48mm] p-4 text-black font-mono text-[9px] print:m-0 print:w-full print:shadow-none">
                <div className="text-center border-b border-black pb-2 mb-3">
                  <h1 className="text-sm font-bold tracking-widest leading-tight">MINAMI SUSHI</h1>
                  <p className="text-[10px] uppercase font-bold mt-1">PLANILLA DE ARMADO</p>
                  <p className="text-[9px] mt-1">{new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
                
                <div className="space-y-3">
                  {(() => {
                    const categoriesOrder = ['rolls', 'nigiri', 'picoteo', 'salsas'];
                    const categoryLabels: Record<string, string> = { 
                      rolls: 'SUSHI', 
                      nigiri: 'NIGIRIS (1x1)',
                      picoteo: 'PICOTEO', 
                      salsas: 'SALSAS'
                    };
                    const grouped: Record<string, any[]> = {};
                    
                    preparationList.forEach((item) => {
                      const cat = (item.category || 'otros').toLowerCase();
                      if (!grouped[cat]) grouped[cat] = [];
                      grouped[cat].push(item);
                    });

                    const sortedCats = categoriesOrder.filter(c => grouped[c] && grouped[c].length > 0);
                    Object.keys(grouped).forEach(c => {
                      if (!categoriesOrder.includes(c) && !sortedCats.includes(c)) sortedCats.push(c);
                    });

                    return sortedCats.map(cat => (
                      <div key={cat} className="space-y-1.5">
                        <div className="font-black bg-gray-100 text-center py-1 border-y border-gray-300 uppercase text-[11px] tracking-widest">{categoryLabels[cat] || cat.toUpperCase()}</div>
                        {grouped[cat].map((item, i) => (
                          <div key={i} className="pb-1 border-b border-dotted border-gray-200 last:border-0">
                            <div className="flex justify-between font-bold text-[11px] mb-0.5 uppercase">
                              <span className="flex-1 pr-1 leading-tight">{item.name}</span>
                              <span className="shrink-0">{item.totalCount % 1 === 0 ? item.totalCount : item.totalCount.toFixed(1)} {item.isSushi ? 'R' : 'U'}</span>
                            </div>
                            <div className="flex flex-wrap gap-1">
                               <TallyMarks count={item.markCount} size="xs" color="black" />
                            </div>
                          </div>
                        ))}
                      </div>
                    ));
                  })()}
                </div>

                <div className="mt-4 text-center border-t border-black pt-3">
                  {totalRawRiceGrams > 0 && (
                    <div className="mb-3 pb-3 border-b border-black border-dotted">
                      <p className="font-black text-sm">ARROZ CRUDO: {(totalRawRiceGrams / 1000).toFixed(2)} KG</p>
                      <p className="text-[10px] italic">({totalRawRiceGrams.toLocaleString()}g)</p>
                    </div>
                  )}
                  <p className="font-bold text-[11px] uppercase">ITEMS: {preparationList.length}</p>
                </div>
              </div>
            </div>

            <div className="p-4 border-t bg-white">
              <button 
                onClick={handlePrint}
                className="w-full bg-brand-orange text-white py-3 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-brand-orange/20"
              >
                <Printer size={18} /> Imprimir Comanda
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @media print {
          body * {
            visibility: hidden;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          #preparation-ticket, #preparation-ticket * {
            visibility: visible;
          }
          #preparation-ticket {
            position: absolute;
            left: 0;
            top: 0;
            width: 48mm;
            margin: 0;
            padding: 4mm;
            box-shadow: none !important;
            background: white !important;
            z-index: 9999;
          }
           .bg-gray-100 { background-color: #f3f4f6 !important; }
        }
      `}</style>
    </div>
  );
}
