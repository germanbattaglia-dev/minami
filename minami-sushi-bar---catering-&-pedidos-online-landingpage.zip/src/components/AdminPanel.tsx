import React, { useEffect, useState, useRef, useMemo } from 'react';
import { db, auth, loginWithGoogle, logout, handleFirestoreError, OperationType, loginWithEmail, registerWithEmail } from '../firebase';
import { collection, onSnapshot, query, orderBy, getDocs, doc, updateDoc, deleteDoc, addDoc, serverTimestamp, writeBatch, setDoc, increment } from 'firebase/firestore';
import { onAuthStateChanged, User } from 'firebase/auth';
import { LogOut, CheckCircle2, Circle, Trash2, Plus, Edit2, X, Image as ImageIcon, Banknote, GripVertical, TrendingUp, Search, ChevronUp, ChevronDown } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { getDirectImageUrl } from '../lib/imageUtils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { format, subDays, startOfDay, endOfDay, isSameDay } from 'date-fns';

import AdminStats from './AdminStats';
import AdminCoupons from './AdminCoupons';
import AdminSettings from './AdminSettings';
import AdminCalculator from './AdminCalculator';
import AdminBlog from './AdminBlog';
import AdminLanding from './AdminLanding';

export default function AdminPanel() {
  const [user, setUser] = useState<User | null>(null);
  const [quotes, setQuotes] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [coupons, setCoupons] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({});
  const [customerFidelity, setCustomerFidelity] = useState<Record<string, number>>({});
  const [storeOpen, setStoreOpen] = useState<boolean>(true);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'quotes' | 'products' | 'orders' | 'coupons' | 'settings' | 'stats' | 'calculator' | 'landing'>('quotes');
  const [showNewOrderModal, setShowNewOrderModal] = useState(false);
  const [manualOrderItems, setManualOrderItems] = useState<any[]>([]);
  const [manualOrderForm, setManualOrderForm] = useState({
    name: '',
    phone: '',
    address: '',
    method: 'delivery' as 'delivery' | 'pickup',
    paymentMethod: 'efectivo',
    deliveryCost: 0,
    adminNotes: ''
  });
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  // Product Modal State
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isAdjustPriceModalOpen, setIsAdjustPriceModalOpen] = useState(false);
  const [adjustPriceMode, setAdjustPriceMode] = useState<'fixed' | 'percentage'>('percentage');
  const [adjustPriceVal, setAdjustPriceVal] = useState('');
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [productForm, setProductForm] = useState({ 
    name: '', category: 'rolls', desc: '', subCategories: [] as string[], price: '', img: '', 
    pieces: '', tags: [] as string[], isOffer: false, offerPrice: '', isOutOfStock: false, isFeatured: false, inSlider: false,
    comboContents: '', comboVarieties: [] as string[]
  });
  const [customTag, setCustomTag] = useState('');
  const [customSubCategory, setCustomSubCategory] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Login Modal State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [permissionError, setPermissionError] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const { todayStats, weekStats, allStats } = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    
    // Start of week (Monday)
    const day = now.getDay();
    const diff = now.getDate() - day + (day === 0 ? -6 : 1);
    const startOfWeek = new Date(now.getFullYear(), now.getMonth(), diff).getTime();

    const stats = {
      today: { count: 0, revenue: 0 },
      week: { count: 0, revenue: 0 },
      all: { count: 0, revenue: 0 }
    };

    orders.forEach(o => {
      let t = 0;
      if (o.createdAt) {
        if (o.createdAt.toMillis) {
          t = o.createdAt.toMillis();
        } else if (o.createdAt.seconds) {
          t = o.createdAt.seconds * 1000;
        } else if (typeof o.createdAt === 'number') {
          t = o.createdAt;
        } else {
          try {
            t = new Date(o.createdAt).getTime();
          } catch(e) {}
        }
      }

      const amount = Number(o.totalAmount) || 0;

      stats.all.count++;
      stats.all.revenue += amount;

      if (t >= startOfToday) {
        stats.today.count++;
        stats.today.revenue += amount;
      }
      
      if (t >= startOfWeek) {
        stats.week.count++;
        stats.week.revenue += amount;
      }
    });

    return { todayStats: stats.today, weekStats: stats.week, allStats: stats.all };
  }, [orders]);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      // First try to login
      await loginWithEmail(email, password);
    } catch (err: any) {
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        // If not found, try to register
        try {
          await registerWithEmail(email, password);
        } catch (regErr: any) {
          if (regErr.code === 'auth/weak-password') setAuthError('La contraseña es demasiado débil (mínimo 6 caracteres).');
          else setAuthError(regErr.message || 'Error al crear la cuenta.');
        }
      }
      else if (err.code === 'auth/wrong-password') setAuthError('Contraseña incorrecta.');
      else setAuthError(err.message || 'Ocurrió un error en la autenticación.');
    }
  };

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      setPermissionError(false); // reset on login
    });
    return () => unsubAuth();
  }, []);

  useEffect(() => {
    if (!user) return;
    
    // Quotes Snapshot
    const qQuotes = query(collection(db, 'quotes'), orderBy('createdAt', 'desc'));
    const unsubQuotes = onSnapshot(qQuotes, (snapshot) => {
      setQuotes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      if (error.message.includes('permission-denied') || error.message.includes('Missing or insufficient permissions')) {
        setPermissionError(true);
        logout();
      }
      handleFirestoreError(error, OperationType.LIST, 'quotes');
    });

    // Products Snapshot
    const qProducts = query(collection(db, 'products'));
    const unsubProducts = onSnapshot(qProducts, (snapshot) => {
      let fetchedProducts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      fetchedProducts.sort((a: any, b: any) => {
        const orderA = a.sortOrder ?? 9999;
        const orderB = b.sortOrder ?? 9999;
        return orderA - orderB;
      });
      setProducts(fetchedProducts);
    }, (error) => {
      if (error.message.includes('permission-denied') || error.message.includes('Missing or insufficient permissions')) {
        setPermissionError(true);
        logout();
      }
      handleFirestoreError(error, OperationType.LIST, 'products');
    });

    // Orders Snapshot
    const qOrders = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubOrders = onSnapshot(qOrders, (snapshot) => {
      setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
    });

    // Coupons Snapshot
    const qCoupons = query(collection(db, 'coupons'), orderBy('createdAt', 'desc'));
    const unsubCoupons = onSnapshot(qCoupons, (snapshot) => {
      setCoupons(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'coupons');
    });

    // Settings Snapshot
    const unsubSettings = onSnapshot(doc(db, 'settings', 'store'), (docSnap) => {
      if (docSnap.exists()) {
        setSettings(docSnap.data());
        setStoreOpen(docSnap.data().ordersOpen !== false);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/store');
    });

    // Customer Fidelity Snapshot
    const unsubFidelity = onSnapshot(collection(db, 'customerFidelity'), (snapshot) => {
      const fidelity: Record<string, number> = {};
      snapshot.docs.forEach(docSnap => {
        fidelity[docSnap.id] = docSnap.data().count || 0;
      });
      setCustomerFidelity(fidelity);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'customerFidelity');
    });

    return () => {
      unsubQuotes();
      unsubProducts();
      unsubOrders();
      unsubCoupons();
      unsubSettings();
      unsubFidelity();
    }
  }, [user]);

  // Quotes Actions
  const toggleStatus = async (quote: any) => {
    try {
      const newStatus = quote.status === 'new' ? 'read' : 'new';
      await updateDoc(doc(db, 'quotes', quote.id), { status: newStatus });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `quotes/${quote.id}`);
    }
  };

  const deleteQuote = async (id: string) => {
    if (!window.confirm("¿Seguro que querés eliminar esta cotización?")) return;
    try {
      await deleteDoc(doc(db, 'quotes', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `quotes/${id}`);
    }
  };

  // Product Actions
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Use canvas to compress image to stay under 1MB limit
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        
        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setProductForm(prev => ({ ...prev, img: dataUrl }));
      };
      
      if (typeof event.target?.result === 'string') {
        img.src = event.target.result;
      }
    };
    reader.readAsDataURL(file);
  };

  const defaultProductForm = {
    name: '', category: 'rolls', desc: '', subCategories: [] as string[], price: '', img: '', 
    pieces: '', tags: [] as string[], isOffer: false, offerPrice: '', isOutOfStock: false, isFeatured: false, inSlider: false,
    comboContents: '', comboVarieties: [] as string[]
  };

  const applyPriceAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = Number(adjustPriceVal);
    if (!val || val <= 0) return;

    if (!window.confirm(`¿Estás seguro de aumentar el precio de TODOS los productos en un ${adjustPriceMode === 'percentage' ? val + '%' : '$' + val}?`)) return;

    setIsAdjustPriceModalOpen(false);
    setAdjustPriceVal('');

    try {
      const batch = writeBatch(db);
      products.forEach(p => {
        const productRef = doc(db, 'products', p.id);
        const newPrice = adjustPriceMode === 'percentage' 
          ? Math.round(p.price * (1 + (val / 100)))
          : p.price + val;
        batch.update(productRef, { price: newPrice });
      });
      await batch.commit();
      alert('Precios actualizados con éxito');
    } catch (error) {
      console.error(error);
      alert('Error al actualizar precios');
    }
  };

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name) return alert("Falta el nombre del producto");
    if (!productForm.price) return alert("Falta el precio del producto");
    if (!productForm.category) return alert("Falta seleccionar una categoría");

    setIsSaving(true);
    try {
      const data: any = {
        name: productForm.name,
        category: productForm.category,
        desc: productForm.desc,
        subCategories: productForm.subCategories,
        price: Number(productForm.price),
        img: productForm.img,
        createdAt: editingProduct && editingProduct.createdAt ? editingProduct.createdAt : serverTimestamp(),
        pieces: productForm.pieces,
        isOffer: productForm.isOffer,
        isOutOfStock: productForm.isOutOfStock,
        isFeatured: productForm.isFeatured,
        inSlider: productForm.inSlider,
        tags: productForm.tags,
        comboContents: productForm.comboContents,
        comboVarieties: productForm.comboVarieties || []
      };
      if (!editingProduct) data.sortOrder = products.length; // Add to end
      if (productForm.offerPrice) data.offerPrice = Number(productForm.offerPrice);

      if (editingProduct) {
        delete data.createdAt;
        await updateDoc(doc(db, 'products', editingProduct.id), data);
      } else {
        await addDoc(collection(db, 'products'), data);
      }
      setIsProductModalOpen(false);
      setEditingProduct(null);
      setProductForm(defaultProductForm);
    } catch (error) {
      console.error(error);
      alert("Error al guardar el producto. Por favor reintente.");
      handleFirestoreError(error, editingProduct ? OperationType.UPDATE : OperationType.CREATE, 'products');
    } finally {
      setIsSaving(false);
    }
  };

  const editProduct = (product: any) => {
    setEditingProduct(product);
    setProductForm({
      ...defaultProductForm,
      name: product.name,
      category: product.category,
      desc: product.desc || '',
      subCategories: product.subCategories || (product.subCategory ? [product.subCategory] : []),
      price: String(product.price),
      img: product.img || '',
      pieces: product.pieces || '',
      tags: product.tags || [],
      isOffer: !!product.isOffer,
      offerPrice: product.offerPrice ? String(product.offerPrice) : '',
      isOutOfStock: !!product.isOutOfStock,
      isFeatured: !!product.isFeatured,
      inSlider: !!product.inSlider,
      comboContents: product.comboContents || '',
      comboVarieties: product.comboVarieties || []
    });
    setIsProductModalOpen(true);
  };

  const handleDragEnd = async (result: any) => {
    if (!result.destination) return;
    const items = Array.from(products);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setProducts(items); // Optimistic UI update
    
    try {
      const batch = writeBatch(db);
      items.forEach((item, index) => {
        batch.update(doc(db, 'products', item.id), { sortOrder: index });
      });
      await batch.commit();
    } catch(e) {
      handleFirestoreError(e, OperationType.UPDATE, 'products');
    }
  };

  const reorderProduct = async (id: string, direction: 'up' | 'down', categoryItems: any[]) => {
    const currentIndexInCategory = categoryItems.findIndex(p => p.id === id);
    if (currentIndexInCategory === -1) return;
    
    const neighborIndexInCategory = direction === 'up' ? currentIndexInCategory - 1 : currentIndexInCategory + 1;
    if (neighborIndexInCategory < 0 || neighborIndexInCategory >= categoryItems.length) return;
    
    const neighbor = categoryItems[neighborIndexInCategory];
    
    // Find global indices
    const globalIndexCurrent = products.findIndex(p => p.id === id);
    const globalIndexNeighbor = products.findIndex(p => p.id === neighbor.id);
    
    const items = [...products];
    const [movedItem] = items.splice(globalIndexCurrent, 1);
    items.splice(globalIndexNeighbor, 0, movedItem);
    
    setProducts(items); // Optimistic update
    
    try {
      const batch = writeBatch(db);
      items.forEach((item, index) => {
        batch.update(doc(db, 'products', item.id), { sortOrder: index });
      });
      await batch.commit();
    } catch(e) {
      console.error(e);
      handleFirestoreError(e, OperationType.UPDATE, 'products');
    }
  };

  const deleteProduct = async (id: string) => {
    if (!window.confirm("¿Seguro que querés eliminar este producto?")) return;
    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `products/${id}`);
    }
  };

  const openNewProductModal = () => {
    setEditingProduct(null);
    setProductForm(defaultProductForm);
    setIsProductModalOpen(true);
  };

  const updateStoreStatus = async (status: string) => {
    try {
      await setDoc(doc(db, 'settings', 'store'), { ordersOpen: status }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'settings/store');
    }
  };

  const deleteOrder = async (id: string) => {
    if (!window.confirm("¿Seguro que querés eliminar este pedido? Se descontará de sus compras.")) return;
    try {
      const order = orders.find(o => o.id === id);
      if (order && order.phone) {
        const cleanPhone = order.phone.replace(/\D/g, '');
        await setDoc(doc(db, 'customerFidelity', cleanPhone), { 
          count: increment(-1),
          lastUpdate: serverTimestamp()
        }, { merge: true });
      }
      await deleteDoc(doc(db, 'orders', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `orders/${id}`);
    }
  };

  const deleteCustomer = async (phone: string, name: string) => {
    if (!window.confirm(`¿Seguro que querés eliminar todos los datos (pedidos) del cliente ${name} (${phone})?`)) return;
    
    try {
      const q = query(collection(db, 'orders'));
      const querySnapshot = await getDocs(q);
      const batch = writeBatch(db);
      let count = 0;
      
      querySnapshot.forEach((d) => {
        if (d.data().phone === phone) {
          batch.delete(doc(db, 'orders', d.id));
          count++;
        }
      });

      if (count > 0) {
        await batch.commit();
        alert(`Se eliminaron ${count} pedidos del cliente.`);
      } else {
        alert("No se encontraron pedidos de este cliente.");
      }
    } catch (e) {
       console.error(e);
       alert("Error al eliminar los datos del cliente.");
    }
  };

  const updateCustomerFidelity = async (phone: string, count: number) => {
    try {
      const cleanPhone = phone.replace(/\D/g, '');
      await setDoc(doc(db, 'customerFidelity', cleanPhone), { 
        count,
        lastUpdate: serverTimestamp()
      }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `customerFidelity/${phone}`);
    }
  };

  const handleCreateManualOrder = async () => {
    if (!manualOrderForm.name || !manualOrderForm.phone || manualOrderItems.length === 0) {
      alert("Por favor completá nombre, teléfono y agregá al menos un producto.");
      return;
    }

    try {
      const subTotal = manualOrderItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
      const totalAmount = subTotal + (manualOrderForm.method === 'delivery' ? (manualOrderForm.deliveryCost || 0) : 0);
      const totalItems = manualOrderItems.reduce((acc, item) => acc + item.quantity, 0);
      
      const orderData = {
        name: manualOrderForm.name,
        phone: manualOrderForm.phone,
        address: manualOrderForm.address,
        method: manualOrderForm.method,
        paymentMethod: manualOrderForm.paymentMethod,
        items: manualOrderItems.map(item => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          isCombo: !!item.isCombo,
          subtitle: item.subtitle || ''
        })),
        subTotal,
        deliveryCost: manualOrderForm.deliveryCost,
        discount: 0,
        totalAmount,
        totalItems,
        status: 'new',
        isPaid: false,
        isCompleted: false,
        forAssembly: false,
        adminNotes: manualOrderForm.adminNotes, // Admin notes for internal tracking
        notes: "", // Public notes
        createdAt: serverTimestamp(),
      };

      await addDoc(collection(db, 'orders'), orderData);
      
      // Update fidelity
      const cleanPhone = manualOrderForm.phone.replace(/\D/g, '');
      await setDoc(doc(db, 'customerFidelity', cleanPhone), { 
        count: increment(1),
        lastUpdate: serverTimestamp()
      }, { merge: true });

      setShowNewOrderModal(false);
      setManualOrderItems([]);
      setManualOrderForm({
        name: '',
        phone: '',
        address: '',
        method: 'delivery',
        paymentMethod: 'efectivo',
        deliveryCost: 0,
        adminNotes: ''
      });
      alert("Pedido cargado con éxito.");
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'orders');
    }
  };

  const [productSearch, setProductSearch] = useState('');

  const sushiVarieties = useMemo(() => {
    return products.filter(p => p && p.name && p.category === 'rolls').sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  }, [products]);

  const toggleComboItem = (variety: any) => {
    const currentVarieties = productForm.comboVarieties || [];
    const isSelected = currentVarieties.includes(variety.id);
    
    let newVarieties: string[];
    if (isSelected) {
      newVarieties = currentVarieties.filter(id => id !== variety.id);
    } else {
      newVarieties = [...currentVarieties, variety.id];
    }
    
    // Also sync with comboContents for assembly/calculators
    const lines = productForm.comboContents.split('\n').filter(l => l.trim());
    let newContents = '';
    if (isSelected) {
      newContents = lines.filter(l => !l.includes(variety.name)).join('\n');
    } else {
      newContents = [...lines, `1x ${variety.name}`].join('\n');
    }
    
    setProductForm({ 
      ...productForm, 
      comboVarieties: newVarieties,
      comboContents: newContents 
    });
  };

  const productsByCategory = useMemo(() => {
    const groups: Record<string, any[]> = {};
    const filtered = products.filter(p => {
      if (!p || !p.name) return false;
      if (!productSearch) return true;
      const search = productSearch.toLowerCase();
      const name = String(p.name).toLowerCase();
      const cat = (p.category || '').toLowerCase();
      const description = (p.desc || '').toLowerCase();
      return name.includes(search) || 
             cat.includes(search) ||
             description.includes(search);
    });
    
    filtered.forEach(p => {
      const cat = p.category || 'Sin Categoría';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(p);
    });
    return groups;
  }, [products, productSearch]);

  const toggleOrderCompleted = async (order: any) => {
    try {
      const isCompleted = !(order.isCompleted || false);
      const updates: any = { isCompleted };
      
      const fidelityThreshold = settings?.fidelityThreshold !== undefined ? settings.fidelityThreshold : 20000;

      if (isCompleted && !order.fidelityGranted && order.subTotal >= fidelityThreshold) {
        updates.fidelityGranted = true;
        const cleanPhone = order.phone.replace(/\D/g, '');
        await setDoc(doc(db, 'customerFidelity', cleanPhone), {
          count: increment(1),
          lastUpdate: serverTimestamp()
        }, { merge: true });
      }
      
      await updateDoc(doc(db, 'orders', order.id), updates);
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const toggleOrderForAssembly = async (id: string, forAssembly: boolean) => {
    try {
      await updateDoc(doc(db, 'orders', id), { forAssembly: !forAssembly });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `orders/${id}`);
    }
  };

  const updateOrderPaid = async (id: string, isPaid: boolean) => {
    try {
      await updateDoc(doc(db, 'orders', id), { isPaid });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `orders/${id}`);
    }
  };

  const sendWhatsAppReady = (order: any) => {
    let msg = `*MINAMI SUSHI*\n\nHola ${order.name}, ¡tu pedido está listo! `;
    if (order.method === 'delivery') {
      msg += `¿Ya te lo podemos enviar a ${order.address}?`;
    } else {
      msg += `¡Ya podés pasar a retirarlo por Las Heras 323!`;
    }
    
    let phoneNum = order.phone.replace(/[^0-9]/g, '');
    if (!phoneNum.startsWith('54')) phoneNum = '549' + phoneNum;
    
    window.open(`https://wa.me/${phoneNum}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const sendWhatsAppOrder = (order: any) => {
    let msg = `*PEDIDO MINAMI SUSHI*\n\n`;
    msg += `*Hola ${order.name}! Tomamos tu pedido:*\n\n`;
    
    order.items.forEach((item: any) => {
        msg += `- ${item.quantity}x ${item.name} ($${item.price.toLocaleString()})\n`;
    });
    
    msg += `\n*Subtotal:* $${order.subTotal.toLocaleString()}\n`;
    if (order.deliveryCost > 0) msg += `*Envío:* $${order.deliveryCost.toLocaleString()}\n`;
    if (order.discount > 0) msg += `*Descuento:* -$${order.discount.toLocaleString()}\n`;
    msg += `*TOTAL: $${order.totalAmount.toLocaleString()}*\n\n`;
    
    msg += `*Tipo:* ${order.method === 'delivery' ? 'Delivery a ' + order.address : 'Retiro por Local'}\n`;
    msg += `*Pago:* ${order.paymentMethod.toUpperCase()}\n`;
    
    if (order.notes) msg += `\n*NOTAS:* ${order.notes}\n`;
    if (order.adminNotes) msg += `\n*INFO EXTRA:* ${order.adminNotes}\n`;

    if (order.paymentMethod === 'transferencia') {
        msg += `\nRecordá enviarnos el comprobante de pago por este medio. ¡Muchas gracias!`;
    }
    
    let phoneNum = order.phone.replace(/[^0-9]/g, '');
    if (!phoneNum.startsWith('54')) phoneNum = '549' + phoneNum;
    
    window.open(`https://wa.me/${phoneNum}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const updateAdminNotes = async (orderId: string, notes: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { adminNotes: notes });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `orders/${orderId}/adminNotes`);
    }
  };

  const printTicket = (order: any) => {
    const escapeHtml = (unsafe: string) => {
      return (unsafe || '').replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    };

    const categoriesOrder = ['combinados', 'rolls', 'salsas', 'extras', 'picoteo'];
    const groupedItems: Record<string, any[]> = {};
    
    // Original items (combos stay as a single line on the ticket)
    order.items.forEach((item: any) => {
      const cat = (item.category || 'otros').toLowerCase();
      if (!groupedItems[cat]) groupedItems[cat] = [];
      groupedItems[cat].push(item);
    });

    const categoryLabels: Record<string, string> = {
      combinados: 'COMBINADOS',
      rolls: 'SUSHI',
      salsas: 'SALSAS',
      extras: 'EXTRAS',
      picoteo: 'PICOTEO',
      promos: 'PROMOS',
      otros: 'OTROS'
    };

    const sortedCategories = categoriesOrder.filter(cat => groupedItems[cat] && groupedItems[cat].length > 0);
    Object.keys(groupedItems).forEach(cat => {
      if (!categoriesOrder.includes(cat) && !sortedCategories.includes(cat)) {
        sortedCategories.push(cat);
      }
    });

    const ticketHtml = `
      <html>
        <head>
          <title>Comanda - ${escapeHtml(order.name)}</title>
          <style>
            body { 
              font-family: monospace; 
              width: 100%; 
              max-width: 56mm; 
              margin: 0; 
              padding: 0 2mm 0 0; 
              box-sizing: border-box;
              color: #000; 
              font-size: 13px;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            h1 { font-size: 18px; text-align: left; margin: 0 0 10px 0; border-bottom: 2px solid #000; padding-bottom: 5px; }
            .cat-title { font-weight: bold; border-top: 1px solid #000; border-bottom: 1px solid #000; padding: 2px 0; margin: 10px 0 5px 0; text-transform: uppercase; font-size: 12px; text-align: center; background: #eee; }
            .item { display: flex; justify-content: space-between; margin-bottom: 4px; border-bottom: 0.5px solid #eee; padding-bottom: 2px; }
            .item-name { flex-grow: 1; word-wrap: break-word; padding-right: 4px; font-weight: bold; }
            .item-price { white-space: nowrap; }
            .item.extra { padding: 4px; border: 1px solid #000; border-radius: 4px; margin-top: 2px; }
            .item.extra .item-name { font-weight: 900; }
            .item.extra .item-price { font-weight: bold; }
            .totals { margin-top: 10px; border-top: 1px dashed #000; padding-top: 5px; }
            .totals div { display: flex; justify-content: space-between; margin-bottom: 2px; }
            .totals .bold span:last-child { white-space: nowrap; }
            .bold { font-weight: bold; }
            @media print {
              body { width: 100%; max-width: 56mm; }
              @page { margin: 0; padding: 0; }
            }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <h1 style="text-align: center; border-bottom: 1px solid #000;">MINAMI SUSHI</h1>
          <div style="font-size: 11px;">NRO: ${escapeHtml(order.id).slice(0,6).toUpperCase()}</div>
          <div style="margin-top: 5px;">CLIENTE: <span class="bold">${escapeHtml(order.name)}</span></div>
          <div>TEL: ${escapeHtml(order.phone)}</div>
          <div class="bold">TIPO: ${escapeHtml(order.method) === 'delivery' ? 'DELIVERY' : 'PICK UP'}</div>
          ${order.method === 'delivery' ? `<div>DIR: ${escapeHtml(order.address)}</div>` : ''}
          ${order.notes ? `<div style="margin-top:5px; border: 1.5px solid #000; padding: 4px; font-weight: bold;">NOTA: ${escapeHtml(order.notes).toUpperCase()}</div>` : ''}
          ${order.adminNotes ? `<div style="margin-top:10px; margin-bottom:10px; color: #000; padding: 8px; font-weight: 900; font-size: 18px; text-align: center; border: 4px dashed #000; text-transform: uppercase;">⚠️ ${escapeHtml(order.adminNotes)} ⚠️</div>` : ''}
          ${order.isPaid ? `
            <div style="font-size: 14px; font-weight: bold; border: 2px solid #000; padding: 4px; text-align: center; margin: 10px 0;">PAGO REALIZADO ✅</div>
            ${order.method === 'delivery' ? `<div style="font-size: 11px; text-align: center; margin-bottom: 10px; font-weight: bold;">⚠️ ABONAR $${(order.deliveryCost || 0).toLocaleString()} DE ENVÍO AL REPARTIDOR ⚠️</div>` : ''}
          ` : ''}
          <div style="font-size: 11px; margin-top: 5px;">PAGO: ${order.paymentMethod ? escapeHtml(order.paymentMethod).toUpperCase() : 'EFECTIVO'}</div>
          
          <div style="margin: 10px 0; border-bottom: 1px dashed #000;"></div>
          
          ${sortedCategories.map(cat => `
            <div class="cat-title">${categoryLabels[cat] || escapeHtml(cat).toUpperCase()}</div>
            ${groupedItems[cat].map(item => `
              <div class="item ${cat === 'extras' ? 'extra' : ''}">
                <span class="item-name">${item.quantity}x ${escapeHtml(item.name).toUpperCase()}</span>
                ${order.isPaid ? '' : `<span class="item-price">$${(item.price * item.quantity).toLocaleString()}</span>`}
              </div>
            `).join('')}
          `).join('')}
          
          ${order.isPaid ? '' : `
          <div class="totals">
            <div><span>Subtotal:</span> <span>$${order.subTotal.toLocaleString()}</span></div>
            ${order.deliveryCost > 0 ? `<div><span>Envío:</span> <span>$${order.deliveryCost.toLocaleString()}</span></div>` : ''}
            <div class="bold" style="font-size: 16px; border-top: 1px solid #000; margin-top: 3px; padding-top: 3px;">
              <span>TOTAL:</span> <span>$${order.totalAmount.toLocaleString()}</span>
            </div>
          </div>
          `}
          
          <div style="text-align: center; margin-top: 20px; font-size: 10px;">¡GRACIAS POR TU COMPRA!</div>
        </body>
      </html>
    `;
    const printWindow = window.open('', '', 'width=300,height=600');
    if (printWindow) {
      printWindow.document.write(ticketHtml);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 250);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-brand-black text-white">Cargando...</div>;

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-black p-4">
        <div className="bg-white p-8 md:p-10 rounded-3xl max-w-md w-full text-center shadow-2xl">
          <div className="w-16 h-16 rounded-full bg-brand-orange text-white flex items-center justify-center font-display font-bold text-3xl mx-auto mb-6">M</div>
          <h1 className="text-3xl font-display font-bold text-brand-black mb-2">Panel Admin</h1>
          <p className="text-brand-gray mb-8 text-sm">Acceso exclusivo para administradores.</p>

          {authError && (
            <div className="bg-red-50 text-red-500 p-3 rounded-xl mb-6 text-sm font-medium">
              {authError}
            </div>
          )}
          {permissionError && (
            <div className="bg-red-50 text-red-500 p-3 rounded-xl mb-6 text-sm font-medium">
              Tu cuenta no tiene permisos de administrador.
            </div>
          )}

          <form onSubmit={handleEmailAuth} className="space-y-4 mb-6">
            <input 
              type="email" 
              placeholder="Correo electrónico" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange text-left"
              required 
            />
            <input 
              type="password" 
              placeholder="Contraseña" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange text-left"
              required 
            />
            <button 
              type="submit"
              className="w-full bg-brand-black hover:bg-gray-900 text-white py-3 rounded-full font-bold uppercase tracking-widest transition-colors"
            >
              Ingresar / Registrarse
            </button>
          </form>

          <div className="flex items-center gap-4 mb-6 text-sm text-gray-400">
            <div className="flex-1 border-b border-gray-200"></div>
            <span>O</span>
            <div className="flex-1 border-b border-gray-200"></div>
          </div>

          <button 
            onClick={loginWithGoogle}
            className="w-full border-2 border-brand-orange text-brand-orange hover:bg-brand-orange hover:text-white py-3 rounded-full font-bold uppercase tracking-widest transition-colors"
          >
            Ingresar con Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-gray-light font-sans">
      <nav className="bg-brand-black text-white py-4 px-6 fixed w-full top-0 z-50 flex justify-between items-center shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-brand-orange text-white flex items-center justify-center font-display font-bold">M</div>
          <span className="font-display font-bold text-lg hidden sm:block">Admin Minami</span>
        </div>
        <div className="flex items-center gap-4">
          {settings && (
            <div className="flex items-center gap-1.5 md:gap-2 bg-gray-800 px-2 md:px-3 py-1.5 rounded-full border border-gray-700">
              <span className="text-[9px] md:text-[10px] font-bold text-gray-500 uppercase tracking-tighter hidden xs:block">Estado:</span>
              <div className="flex gap-1">
                {[
                  { id: 'auto', label: 'AUTO', color: 'bg-blue-500', active: settings.ordersOpen === 'auto' || settings.ordersOpen === undefined },
                  { id: 'open', label: 'ABIERTO', color: 'bg-green-500', active: settings.ordersOpen === 'open' },
                  { id: 'closed', label: 'CERRADO', color: 'bg-red-500', active: settings.ordersOpen === 'closed' }
                ].map(mode => (
                  <button
                    key={mode.id}
                    onClick={() => updateStoreStatus(mode.id)}
                    className={`text-[9px] font-black px-2 py-0.5 rounded transition-all ${mode.active ? `${mode.color} text-white shadow-lg scale-110` : 'text-gray-500 hover:text-gray-300'}`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            </div>
          )}
          <a href="/" className="text-sm text-gray-300 hover:text-white transition-colors mr-2">
            Volver a la Web
          </a>
          <span className="text-sm text-gray-300 hidden sm:block">{user.email}</span>
          <button onClick={logout} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
            <LogOut size={16} /> Salir
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-200 overflow-x-auto pb-1 scrollbar-hide">
          <button
            onClick={() => setActiveTab('quotes')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'quotes' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Cotizaciones Web
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'products' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Tienda (Productos)
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'orders' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Pedidos
          </button>
          <button
            onClick={() => setActiveTab('coupons')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'coupons' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Cupones
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'stats' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Estadísticas
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'settings' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Ajustes
          </button>
          <button
            onClick={() => setActiveTab('calculator')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'calculator' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Armá tu Combinado
          </button>
          <button
            onClick={() => setActiveTab('landing')}
            className={`pb-4 px-2 font-bold whitespace-nowrap transition-colors ${activeTab === 'landing' ? 'border-b-2 border-brand-orange text-brand-black' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Landing Page
          </button>
        </div>

        {activeTab === 'calculator' && (
          <div className="h-[800px] max-h-[85vh]">
            <AdminCalculator orders={orders} />
          </div>
        )}

        {activeTab === 'orders' && (
          <>
             <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
              <div>
                <h1 className="text-3xl font-display font-bold text-brand-black">Pedidos Diarios</h1>
                <p className="text-brand-gray">Gestión de delivery y pick up.</p>
              </div>
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={() => setShowNewOrderModal(true)}
                  className="bg-brand-black text-white px-4 py-2 rounded-full shadow-sm text-sm font-bold hover:bg-gray-800 transition-colors flex items-center gap-2"
                >
                  <Plus size={16} />
                  Nuevo Pedido
                </button>
                <div className="bg-white px-4 py-2 rounded-xl shadow-sm text-xs font-semibold border border-gray-200 flex flex-col">
                  <span className="text-gray-400">Total Hoy</span>
                  <span className="text-lg text-brand-black">{todayStats.count} pedidos</span>
                </div>
                <div className="bg-white px-4 py-2 rounded-xl shadow-sm text-xs font-semibold border border-gray-200 flex flex-col">
                  <span className="text-gray-400">Ingresos Hoy</span>
                  <span className="text-lg text-green-600">${todayStats.revenue.toLocaleString()}</span>
                </div>
                <div className="bg-white px-4 py-2 rounded-xl shadow-sm text-xs font-semibold border border-gray-200 flex flex-col hidden md:flex">
                  <span className="text-gray-400">Total Sem.</span>
                  <span className="text-lg text-brand-black">{weekStats.count} pedidos</span>
                </div>
                <div className="bg-white px-4 py-2 rounded-xl shadow-sm text-xs font-semibold border border-gray-200 flex flex-col hidden md:flex">
                  <span className="text-gray-400">Ingresos Sem.</span>
                  <span className="text-lg text-green-600">${weekStats.revenue.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[800px]">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Listo</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Armar</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Fecha</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Cliente</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Tipo</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Pago</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Total</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {orders.length === 0 ? (
                       <tr><td colSpan={8} className="p-8 text-center text-gray-400 italic">No hay pedidos aún.</td></tr>
                    ) : orders.map(order => (
                       <tr key={order.id} className={`transition-colors ${order.isCompleted ? 'bg-green-50 opacity-60' : 'hover:bg-gray-50'}`}>
                         <td className="p-4">
                           <input 
                             type="checkbox" 
                             checked={order.isCompleted || false} 
                             onChange={() => toggleOrderCompleted(order)}
                             className="w-5 h-5 accent-green-600 cursor-pointer"
                             title="Marcar como listo"
                           />
                         </td>
                         <td className="p-4">
                            <input 
                              type="checkbox" 
                              checked={order.forAssembly || false} 
                              onChange={() => toggleOrderForAssembly(order.id, order.forAssembly || false)}
                              className="w-5 h-5 accent-brand-orange cursor-pointer"
                              title="Incluir en Planilla de Armado"
                            />
                          </td>
                         <td className="p-4 text-sm whitespace-nowrap">
                            <div className="font-medium">
                              {order.createdAt?.toDate ? order.createdAt.toDate().toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: '2-digit'}) : ''}
                            </div>
                            <div className="text-[10px] text-gray-400">
                              {order.createdAt?.toDate ? order.createdAt.toDate().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit'}) : ''}
                            </div>
                         </td>
                         <td className="p-4">
                           <div className="font-bold">{order.name}</div>
                           <div className="text-xs text-gray-500">{order.phone}</div>
                         </td>
                         <td className="p-4">
                           <span className={`text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wider ${order.method === 'delivery' ? 'bg-orange-100 text-orange-700' : 'bg-blue-100 text-blue-700'}`}>{order.method}</span>
                         </td>
                         <td className="p-4 text-sm font-medium uppercase text-gray-600">
                           <div className="flex flex-col gap-1">
                             <span>{order.paymentMethod}</span>
                             <label className="flex items-center gap-1 cursor-pointer">
                               <input type="checkbox" checked={!!order.isPaid} onChange={(e) => updateOrderPaid(order.id, e.target.checked)} className="rounded text-brand-orange focus:ring-brand-orange cursor-pointer" />
                               <span className="text-xs normal-case">{order.isPaid ? 'Pagado' : 'No pagado'}</span>
                             </label>
                           </div>
                         </td>
                         <td className="p-4 font-bold">${order.totalAmount.toLocaleString()}</td>
                         <td className="p-4 flex gap-2">
                            <button onClick={() => setSelectedOrder(order)} className="text-brand-orange bg-orange-100 hover:bg-orange-200 px-3 py-1 rounded shadow-sm text-xs font-bold transition-colors">Ver</button>
                            <button onClick={() => sendWhatsAppReady(order)} className="text-brand-black bg-[#E2F0CB] hover:bg-[#c6df9b] px-3 py-1 rounded shadow-sm text-xs font-bold transition-colors">Avisar Listo</button>
                             <button onClick={() => deleteOrder(order.id)} className="text-gray-400 hover:text-red-500 p-1" title="Eliminar pedido"><Trash2 size={16}/></button>
                         </td>
                       </tr>
                    ))}
                  </tbody>
                 </table>
              </div>
            </div>
          </>
        )}

        {activeTab === 'quotes' && (
          <>
            <div className="mb-6 flex justify-between items-end">
              <div>
                <h1 className="text-3xl font-display font-bold text-brand-black">Cotizaciones</h1>
                <p className="text-brand-gray">Mensajes recibidos desde la web.</p>
              </div>
              <div className="bg-white px-4 py-2 rounded-full shadow-sm text-sm font-semibold border border-gray-200">
                Total: {quotes.length}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[800px]">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Estado</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Fecha Recibido</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Nombre</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Contacto</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Evento</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Mensaje</th>
                      <th className="p-4 font-semibold text-sm text-brand-gray uppercase tracking-wider">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {quotes.length === 0 ? (
                       <tr><td colSpan={7} className="p-8 text-center text-gray-400 italic">No hay cotizaciones aún.</td></tr>
                    ) : quotes.map(quote => (
                      <tr key={quote.id} className={`hover:bg-gray-50 transition-colors ${quote.status === 'new' ? 'bg-orange-50/30' : ''}`}>
                        <td className="p-4 align-top">
                          <button onClick={() => toggleStatus(quote)} className="flex items-center gap-2 group" title="Marcar como leído/no leído">
                            {quote.status === 'new' ? (
                              <span className="flex items-center gap-1.5 text-xs font-bold text-brand-orange bg-brand-orange/10 px-2.5 py-1 rounded-full"><Circle size={10} className="fill-current" /> Nuevo</span>
                            ) : (
                              <span className="flex items-center gap-1.5 text-xs font-bold text-gray-500"><CheckCircle2 size={14} /> Leído</span>
                            )}
                          </button>
                        </td>
                        <td className="p-4 align-top text-sm text-brand-black whitespace-nowrap">
                          {quote.createdAt ? new Date(quote.createdAt.toDate ? quote.createdAt.toDate() : quote.createdAt).toLocaleDateString('es-AR', {day: '2-digit', month: 'short', hour:'2-digit', minute:'2-digit'}) : 'N/A'}
                        </td>
                        <td className="p-4 align-top font-medium text-brand-black">{quote.name}</td>
                        <td className="p-4 align-top text-sm">
                          <div className="flex flex-col gap-1">
                            <a href={`https://wa.me/${quote.phone.replace(/\D/g, '')}`} target="_blank" className="text-brand-orange hover:underline flex items-center gap-1">
                              {quote.phone}
                            </a>
                          </div>
                        </td>
                        <td className="p-4 align-top text-sm">
                          <p><span className="text-gray-500 text-xs">Tipo:</span> {quote.type || '-'}</p>
                          <p><span className="text-gray-500 text-xs">Para:</span> {quote.date ? new Date(quote.date).toLocaleDateString() : '-'}</p>
                          <p><span className="text-gray-500 text-xs">Invitados:</span> {quote.guests || '-'}</p>
                        </td>
                        <td className="p-4 align-top text-sm text-gray-600 max-w-xs truncate" title={quote.message}>
                          {quote.message || '-'}
                        </td>
                        <td className="p-4 align-top">
                          <button onClick={() => deleteQuote(quote.id)} className="text-gray-400 hover:text-red-500 transition-colors p-1" title="Eliminar">
                             <Trash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {activeTab === 'products' && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <h1 className="text-3xl font-display font-bold text-brand-black">Productos</h1>
                <p className="text-brand-gray">Gestionar menú agrupado por categorías.</p>
              </div>
              <div className="flex flex-col md:flex-row gap-3 items-center">
                <div className="relative w-full md:w-64">
                   <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                   <input 
                      type="text" 
                      placeholder="Buscar producto..." 
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-orange/20"
                   />
                </div>
                <div className="flex gap-2 w-full md:w-auto">
                  <button 
                    onClick={() => setIsAdjustPriceModalOpen(true)}
                    className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 text-brand-black px-4 py-2 rounded-full shadow-sm text-sm font-bold transition-colors"
                  >
                    <TrendingUp size={18} /> Ajustar Precios
                  </button>
                  <button 
                    onClick={openNewProductModal}
                    className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white px-4 py-2 rounded-full shadow-sm text-sm font-bold transition-colors"
                  >
                    <Plus size={18} /> Nuevo Producto
                  </button>
                </div>
              </div>
            </div>

            {Object.entries(productsByCategory).length === 0 ? (
               <div className="py-20 text-center text-gray-400 italic bg-white rounded-3xl border border-dashed border-gray-200">
                No hay productos en la tienda.
              </div>
            ) : (
              Object.entries(productsByCategory).map(([category, items]) => (
                <div key={category} className="space-y-4">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
                    <h2 className="text-sm font-black text-white uppercase tracking-[0.2em] bg-brand-black px-6 py-2 rounded-full border border-brand-orange shadow-lg shadow-brand-orange/10">{category}</h2>
                    <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {items.map((product) => (
                      <div 
                        key={product.id} 
                        onClick={() => editProduct(product)}
                        className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 flex items-center justify-between group hover:border-brand-orange/40 hover:shadow-xl hover:shadow-brand-orange/5 transition-all cursor-pointer"
                      >
                        <div className="flex items-center gap-4 min-w-0">
                          <div className="w-16 h-16 bg-gray-50 rounded-2xl overflow-hidden shrink-0 border border-gray-100 relative shadow-inner">
                            {product.img ? (
                              <img 
                                src={getDirectImageUrl(product.img)} 
                                alt={product.name} 
                                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                                referrerPolicy="no-referrer" 
                              />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-300">
                                  <ImageIcon size={28} strokeWidth={1} />
                                </div>
                            )}
                            {product.isOutOfStock && (
                              <div className="absolute inset-0 bg-red-500/80 flex items-center justify-center text-[10px] text-white font-black uppercase backdrop-blur-[2px] pointer-events-none">Agotado</div>
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <h3 className="font-black text-brand-black truncate uppercase text-sm tracking-tight group-hover:text-brand-orange transition-colors">{product.name}</h3>
                              {(product.subCategories || (product.subCategory ? [product.subCategory] : [])).map((sc: string, i: number) => (
                                <span key={i} className="text-[8px] font-black text-white bg-brand-orange/40 px-2 py-0.5 rounded-full uppercase tracking-widest">{sc}</span>
                              ))}
                            </div>
                            <div className="text-[11px] text-gray-400 line-clamp-1 h-4 italic mb-1">{product.desc || 'Sin descripción'}</div>
                            <div className="flex items-center gap-2">
                               <div className="font-black text-brand-orange text-lg">${Number(product.price || 0).toLocaleString()}</div>
                               {product.isOffer && product.offerPrice && (
                                 <div className="text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded font-black border border-green-100 italic">OFERTA!</div>
                               )}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                          <div className="flex flex-col gap-1 mr-2">
                             <button 
                               onClick={() => reorderProduct(product.id, 'up', items)} 
                               disabled={items.findIndex(p => p.id === product.id) === 0}
                               className="w-8 h-8 rounded-lg bg-gray-50 text-gray-400 flex items-center justify-center hover:text-brand-orange hover:bg-orange-50 disabled:opacity-30 disabled:hover:bg-gray-50 disabled:hover:text-gray-400 transition-all border border-transparent hover:border-brand-orange/20"
                             >
                               <ChevronUp size={16} />
                             </button>
                             <button 
                               onClick={() => reorderProduct(product.id, 'down', items)} 
                               disabled={items.findIndex(p => p.id === product.id) === items.length - 1}
                               className="w-8 h-8 rounded-lg bg-gray-50 text-gray-400 flex items-center justify-center hover:text-brand-orange hover:bg-orange-50 disabled:opacity-30 disabled:hover:bg-gray-50 disabled:hover:text-gray-400 transition-all border border-transparent hover:border-brand-orange/20"
                             >
                               <ChevronDown size={16} />
                             </button>
                          </div>
                          <button onClick={() => editProduct(product)} className="w-10 h-10 rounded-2xl bg-gray-50 text-gray-400 flex items-center justify-center hover:text-brand-orange hover:bg-orange-50 transition-all border border-transparent hover:border-brand-orange/20 shadow-sm"><Edit2 size={18} /></button>
                          <button onClick={() => deleteProduct(product.id)} className="w-10 h-10 rounded-2xl bg-gray-50 text-gray-400 flex items-center justify-center hover:text-red-500 hover:bg-red-50 transition-all border border-transparent hover:border-red-100 shadow-sm"><Trash2 size={18} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
        {activeTab === 'coupons' && <AdminCoupons coupons={coupons} />}
        {activeTab === 'stats' && <AdminStats 
          orders={orders} 
          settings={settings}
          customerFidelity={customerFidelity}
          onUpdateFidelity={updateCustomerFidelity}
          onDeleteCustomer={deleteCustomer} 
        />}
        {activeTab === 'settings' && <AdminSettings settings={settings} />}
        {activeTab === 'landing' && <AdminLanding />}
      </main>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button onClick={() => setSelectedOrder(null)} className="absolute top-4 right-4 bg-gray-100 hover:bg-gray-200 text-brand-black p-2 rounded-full transition-colors z-10"><X size={20}/></button>
            <div className="p-6">
              <h2 className="text-2xl font-bold font-display mb-4">Detalle del Pedido</h2>
              
              <div className="space-y-4 mb-6">
                <div>
                  <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Cliente</span>
                  <p className="font-medium text-lg">{selectedOrder.name}</p>
                  <p className="text-gray-600">{selectedOrder.phone}</p>
                </div>
                
                <div className="flex gap-4">
                    <div className="flex-1">
                      <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Método</span>
                      <p className="font-bold flex items-center gap-1">
                         {selectedOrder.method === 'delivery' ? <><span className="w-2 h-2 rounded-full bg-orange-500"></span> Delivery</> : <><span className="w-2 h-2 rounded-full bg-blue-500"></span> Pick Up</>}
                      </p>
                    </div>
                     <div className="flex-1">
                      <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Pago</span>
                      <p className="font-medium uppercase">{selectedOrder.paymentMethod}</p>
                    </div>
                </div>

                {selectedOrder.method === 'delivery' && (
                  <div>
                    <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Dirección de Envío</span>
                    <p className="font-medium">{selectedOrder.address}</p>
                    <p className="text-sm text-gray-500">Zona: {selectedOrder.zone}</p>
                  </div>
                )}
              </div>

              {selectedOrder.notes && (
                <div className="bg-brand-orange/10 p-4 rounded-xl mb-4 border border-brand-orange/20">
                  <h3 className="font-bold text-xs text-brand-orange mb-1 uppercase tracking-wider">Notas del Cliente</h3>
                  <p className="text-brand-black italic">{selectedOrder.notes}</p>
                </div>
              )}

              <div className="bg-blue-50 p-4 rounded-xl mb-6 border border-blue-100">
                <h3 className="font-bold text-xs text-blue-500 mb-2 uppercase tracking-wider">Notas Adicionales (Administrador)</h3>
                <textarea 
                  className="w-full bg-white border border-blue-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 min-h-[100px] resize-none"
                  placeholder="Agregar notas adicionales para el envío de WhatsApp o ticket..."
                  value={selectedOrder.adminNotes || ''}
                  onChange={(e) => setSelectedOrder({...selectedOrder, adminNotes: e.target.value})}
                  onBlur={(e) => updateAdminNotes(selectedOrder.id, e.target.value)}
                />
                <p className="text-[10px] text-blue-400 mt-2 italic font-medium">* Estas notas se incluirán al enviar por WhatsApp y en la comanda.</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-xl mb-4">
                <h3 className="font-bold text-sm text-gray-400 mb-3 uppercase tracking-wider">Productos</h3>
                <div className="space-y-4">
                  {(() => {
                    const categoriesOrder = ['combinados', 'rolls', 'salsas', 'extras', 'picoteo'];
                    const categoryLabels: Record<string, string> = { combinados: 'COMBINADOS', rolls: 'SUSHI', salsas: 'SALSAS', extras: 'EXTRAS', picoteo: 'PICOTEO' };
                    const grouped: Record<string, any[]> = {};
                    
                    selectedOrder.items?.forEach((item: any) => {
                      const cat = (item.category || 'otros').toLowerCase();
                      if (!grouped[cat]) grouped[cat] = [];
                      grouped[cat].push(item);
                    });

                    const sortedCats = categoriesOrder.filter(c => grouped[c] && grouped[c].length > 0);
                    Object.keys(grouped).forEach(c => {
                      if (!categoriesOrder.includes(c) && !sortedCats.includes(c)) sortedCats.push(c);
                    });

                    return sortedCats.map(cat => (
                      <div key={cat} className="space-y-2">
                        <div className="text-[10px] font-black text-gray-400 border-b border-gray-200 pb-1 uppercase tracking-widest">{categoryLabels[cat] || cat.toUpperCase()}</div>
                        {grouped[cat].map((item: any, i: number) => (
                          <div key={i} className="flex justify-between items-start text-sm">
                            <div className="flex gap-2 font-medium">
                              <span className="text-brand-orange font-bold">{item.quantity}x</span>
                              <span className="uppercase text-[13px]">{item.name}</span>
                            </div>
                            <span className="text-gray-600 font-bold">${(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    ));
                  })()}
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Subtotal</span>
                  <span className="font-medium">${selectedOrder.subTotal?.toLocaleString()}</span>
                </div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Descuento {selectedOrder.coupon ? `(${selectedOrder.coupon})` : ''}</span>
                    <span className="font-medium">-${selectedOrder.discount?.toLocaleString()}</span>
                  </div>
                )}
                {selectedOrder.deliveryCost > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Costo de Envío</span>
                    <span className="font-medium">${selectedOrder.deliveryCost?.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-gray-100 pt-2 text-xl font-bold bg-gray-900 text-white p-3 rounded-lg mt-2">
                  <span>TOTAL</span>
                  <span>${selectedOrder.totalAmount?.toLocaleString()}</span>
                </div>
              </div>
              
              <div className="mt-6 flex gap-2">
                 <button onClick={() => { updateAdminNotes(selectedOrder.id, selectedOrder.adminNotes || ''); sendWhatsAppOrder(selectedOrder); setSelectedOrder(null); }} className="flex-1 flex justify-center bg-[#25D366] text-white p-3 rounded-xl font-bold shadow hover:bg-[#20bd5a] transition-colors">Recibo WhatsApp</button>
                 <button onClick={() => { updateAdminNotes(selectedOrder.id, selectedOrder.adminNotes || ''); printTicket(selectedOrder); setSelectedOrder(null); }} className="flex-1 flex justify-center bg-brand-black text-white p-3 rounded-xl font-bold shadow hover:bg-gray-800 transition-colors">Imprimir Comanda</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Adjust Prices Modal */}
      {isAdjustPriceModalOpen && (
        <div className="fixed inset-0 bg-brand-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white z-10">
              <h2 className="text-xl font-display font-bold">Ajustar Precios</h2>
              <button onClick={() => setIsAdjustPriceModalOpen(false)} className="text-gray-400 hover:text-gray-700 transition-colors">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={applyPriceAdjustment} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-500 mb-2">Modo de Aumento</label>
                <div className="flex bg-gray-100 p-1 rounded-xl">
                  <button type="button" onClick={() => setAdjustPriceMode('percentage')} className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors ${adjustPriceMode === 'percentage' ? 'bg-white shadow' : 'text-gray-500'}`}>Porcentaje (%)</button>
                  <button type="button" onClick={() => setAdjustPriceMode('fixed')} className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors ${adjustPriceMode === 'fixed' ? 'bg-white shadow' : 'text-gray-500'}`}>Valor Fijo ($)</button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-500 mb-2">Valor a Aumentar</label>
                <input required autoFocus type="number" min="1" step="1" value={adjustPriceVal} onChange={e => setAdjustPriceVal(e.target.value)} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange" placeholder={adjustPriceMode === 'percentage' ? 'Ej: 15 para 15%' : 'Ej: 1000 para $1000'} />
              </div>

              <button type="submit" disabled={!adjustPriceVal || Number(adjustPriceVal) <= 0} className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white font-bold py-3 rounded-xl transition-colors disabled:opacity-50">
                Aplicar Aumento
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Product Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 bg-brand-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white z-10">
              <h2 className="text-2xl font-display font-bold">{editingProduct ? 'Editar Producto' : 'Nuevo Producto'}</h2>
              <button onClick={() => setIsProductModalOpen(false)} className="text-gray-400 hover:text-gray-700 transition-colors">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={saveProduct} className="p-6 overflow-y-auto space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Nombre *</label>
                <input required type="text" value={productForm.name} onChange={e => setProductForm({...productForm, name: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange" placeholder="Ej: Buenos Aires Roll" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Precio ($) *</label>
                  <input required min="0" step="1" type="number" value={productForm.price} onChange={e => setProductForm({...productForm, price: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange" placeholder="10000" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Categoría *</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                    {[
                      { id: 'rolls', label: 'Sushi Rolls', icon: '🍣' },
                      { id: 'picoteo', label: 'Picoteo', icon: '🍟' },
                      { id: 'salsas', label: 'Salsas', icon: '🥫' },
                      { id: 'extras', label: 'Extras', icon: '➕' },
                      { id: 'combinados', label: 'Combinados', icon: '🍱' }
                    ].map(cat => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setProductForm({...productForm, category: cat.id})}
                        className={`p-2 rounded-xl border-2 flex flex-col items-center justify-center gap-1 transition-all ${
                          productForm.category === cat.id 
                            ? 'border-brand-orange bg-brand-orange/5 text-brand-orange scale-[1.02]' 
                            : 'border-gray-100 text-gray-400 hover:border-gray-200'
                        }`}
                      >
                        <span className="text-xl">{cat.icon}</span>
                        <span className="text-[9px] font-black uppercase text-center leading-tight">{cat.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Piezas / Info</label>
                  <input type="text" value={productForm.pieces} onChange={e => setProductForm({...productForm, pieces: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange" placeholder="Ej: x4 Piezas" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Subcategorías</label>
                  <div className="flex flex-col gap-3 mb-2">
                    {productForm.subCategories.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {productForm.subCategories.map((scName: string, i: number) => (
                          <button
                            type="button"
                            key={`sel-${i}`}
                            onClick={() => setProductForm(prev => ({ ...prev, subCategories: prev.subCategories.filter(t => t !== scName) }))}
                            className="px-3 py-1 border rounded-full text-sm font-bold flex items-center gap-1 transition-colors bg-orange-100 border-brand-orange text-brand-orange hover:bg-orange-200"
                          >
                            {scName}
                          </button>
                        ))}
                      </div>
                    )}
                    
                    {productForm.subCategories.length > 0 && (
                      <div className="w-full h-px bg-gray-200 my-1"></div>
                    )}
                    
                    <div className="flex flex-wrap gap-2">
                      {[...(settings?.subCategories || [
                        { name: 'Salmón' },
                        { name: 'Palta' },
                        { name: 'Langostino' },
                        { name: 'Kanikama' }
                      ]).map((s: any) => s.name)].filter(scName => !productForm.subCategories.includes(scName)).map((scName: string, i: number) => (
                        <button
                          type="button"
                          key={`unsel-${i}`}
                          onClick={() => setProductForm(prev => ({ ...prev, subCategories: [...prev.subCategories, scName] }))}
                          className="px-3 py-1 border rounded-full text-sm font-bold flex items-center gap-1 transition-colors bg-blue-50 border-blue-200 text-blue-600 hover:border-blue-400 hover:bg-blue-100"
                        >
                          {scName}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <input type="text" value={customSubCategory} onChange={e => setCustomSubCategory(e.target.value)} placeholder="Ej: Nueva Subcat" className="border border-gray-200 rounded-lg px-3 py-1 text-sm focus:outline-none focus:border-brand-orange" />
                    <button type="button" onClick={async () => {
                      if (customSubCategory && !productForm.subCategories.includes(customSubCategory)) {
                        setProductForm(prev => ({...prev, subCategories: [...prev.subCategories, customSubCategory]}));
                        
                        const currentSubcats = settings?.subCategories || [
                          { name: 'Salmón' },
                          { name: 'Palta' },
                          { name: 'Langostino' },
                          { name: 'Kanikama' }
                        ];
                        
                        if (!currentSubcats.some((s: any) => s.name === customSubCategory)) {
                          try {
                            await setDoc(doc(db, 'settings', 'store'), { subCategories: [...currentSubcats, { name: customSubCategory }] }, { merge: true });
                          } catch (e) {
                            console.error('Error guardando subcategoría', e);
                          }
                        }
                        
                        setCustomSubCategory(''); 
                      } 
                    }} className="bg-gray-100 px-3 py-1 rounded-lg text-sm font-bold text-brand-black hover:bg-gray-200">Añadir</button>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Etiquetas</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {[...(settings?.tags || [
                    { name: 'Vegano', icon: '🌱' },
                    { name: 'Veggie', icon: '🥕' },
                    { name: 'Picante', icon: '🌶️' },
                    { name: 'Frito', icon: '🍤' },
                    { name: 'Cocido', icon: '♨️' }
                  ]).map((t: any) => t.name), ...productForm.tags.filter((t: string) => !(settings?.tags || []).some((st: any) => st.name === t))].map((tagName: string, i: number) => {
                    const isSelected = productForm.tags.includes(tagName);
                    const tagObj = (settings?.tags || []).find((t: any) => t.name === tagName);
                    return (
                      <button
                        type="button"
                        key={i}
                        onClick={() => {
                          if (isSelected) {
                            setProductForm(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tagName) }));
                          } else {
                            setProductForm(prev => ({ ...prev, tags: [...prev.tags, tagName] }));
                          }
                        }}
                        className={`px-3 py-1 border rounded-full text-sm font-bold flex items-center gap-1 transition-colors ${isSelected ? 'bg-orange-100 border-brand-orange text-brand-orange' : 'bg-white border-gray-200 text-gray-500 hover:border-brand-orange hover:text-brand-orange'}`}
                      >
                        {tagObj?.icon && <span>{tagObj.icon}</span>}
                        {tagName}
                      </button>
                    );
                  })}
                </div>
                <div className="flex gap-2">
                  <input type="text" value={customTag} onChange={e => setCustomTag(e.target.value)} placeholder="Ej: Nueva Etiqueta" className="border border-gray-200 rounded-lg px-3 py-1 text-sm focus:outline-none focus:border-brand-orange" />
                  <button type="button" onClick={async () => {
                    if (customTag && !productForm.tags.includes(customTag)) {
                      setProductForm(prev => ({...prev, tags: [...prev.tags, customTag]}));
                      
                      const currentTags = settings?.tags || [
                        { name: 'Vegano', icon: '🌱' },
                        { name: 'Veggie', icon: '🥕' },
                        { name: 'Picante', icon: '🌶️' },
                        { name: 'Frito', icon: '🍤' },
                        { name: 'Crudo', icon: '🍣' },
                        { name: 'Cocido', icon: '♨️' }
                      ];
                      
                      if (!currentTags.some((t: any) => t.name === customTag)) {
                        try {
                          await setDoc(doc(db, 'settings', 'store'), { tags: [...currentTags, { name: customTag, icon: '🏷️' }] }, { merge: true });
                        } catch (e) {
                          console.error('Error guardando etiqueta', e);
                        }
                      }
                      
                      setCustomTag('');
                    } 
                  }} className="bg-gray-100 px-3 py-1 rounded-lg text-sm font-bold text-brand-black hover:bg-gray-200">Añadir</button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 bg-gray-50 p-4 rounded-xl border border-gray-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={productForm.isOffer} onChange={e => setProductForm({...productForm, isOffer: e.target.checked})} className="accent-brand-orange w-5 h-5 rounded" />
                  <span className="text-sm font-bold text-gray-800">En PROMO</span>
                </label>
                
                {productForm.isOffer && (
                   <div>
                     <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Precio Promo ($)</label>
                     <input type="number" value={productForm.offerPrice} onChange={e => setProductForm({...productForm, offerPrice: e.target.value})} className="w-full border border-gray-200 rounded-lg px-2 py-1 text-sm focus:outline-none focus:border-brand-orange" placeholder="8000" />
                   </div>
                )}

                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={productForm.isFeatured} onChange={e => setProductForm({...productForm, isFeatured: e.target.checked})} className="accent-brand-orange w-5 h-5 rounded" />
                  <span className="text-sm font-bold text-gray-800">Destacado</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={productForm.isOutOfStock} onChange={e => setProductForm({...productForm, isOutOfStock: e.target.checked})} className="accent-red-500 w-5 h-5 rounded" />
                  <span className="text-sm font-bold text-red-600">SIN STOCK</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer md:col-span-1">
                  <input type="checkbox" checked={productForm.inSlider} onChange={e => setProductForm({...productForm, inSlider: e.target.checked})} className="accent-blue-500 w-5 h-5 rounded" />
                  <span className="text-sm font-bold text-gray-800">Slider Principal</span>
                </label>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Descripción</label>
                <textarea rows={2} value={productForm.desc} onChange={e => setProductForm({...productForm, desc: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange resize-none" placeholder="Ingredientes detallados..." />
              </div>

              {productForm.category === 'combinados' && (
                <div className="bg-orange-50 p-5 rounded-2xl border border-orange-100">
                  <label className="block text-[10px] font-black text-brand-orange uppercase tracking-widest mb-3">Qué incluye este Combinado (Lógica Armado)</label>
                  <p className="text-[10px] text-gray-500 mb-4 leading-tight italic">Tildá las variedades que componen este combo. La planilla de armado las sumará individualmente.</p>
                  
                  <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-2 scrollbar-thin">
                    {sushiVarieties.map(v => {
                      const isSelected = productForm.comboVarieties?.includes(v.id);
                      return (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => toggleComboItem(v)}
                          className={`flex items-center gap-2 p-2 rounded-lg text-[10px] font-bold text-left transition-all border ${
                            isSelected
                              ? 'bg-brand-orange text-white border-brand-orange shadow-sm'
                              : 'bg-white text-gray-600 border-gray-100 hover:border-brand-orange/30'
                          }`}
                        >
                          <div className={`w-3 h-3 rounded flex items-center justify-center ${isSelected ? 'bg-white text-brand-orange' : 'bg-gray-100'}`}>
                            {isSelected && <div className="w-1.5 h-1.5 bg-brand-orange rounded-full" />}
                          </div>
                          <span className="truncate">{v.name}</span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-4 pt-4 border-t border-orange-100">
                    <label className="block text-[8px] font-bold text-gray-400 uppercase mb-2 tracking-widest">Vista Previa de Lógica (Editable)</label>
                    <textarea 
                      rows={2} 
                      value={productForm.comboContents} 
                      onChange={e => setProductForm({...productForm, comboContents: e.target.value})} 
                      className="w-full border border-orange-200 rounded-xl px-3 py-2 focus:outline-none focus:border-brand-orange bg-white text-[10px]" 
                      placeholder="Ej: 1x Salmon Roll" 
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Imagen o Video (Foto Subida o URL)</label>
                <div className="border border-dashed border-gray-300 rounded-2xl p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => fileInputRef.current?.click()}>
                   {productForm.img ? (
                     <div className="relative w-full h-32 rounded-lg overflow-hidden group">
                       <img 
                         src={getDirectImageUrl(productForm.img)} 
                         alt="Preview" 
                         className="w-full h-full object-cover" 
                         referrerPolicy="no-referrer" 
                       />
                       <div className="absolute inset-0 bg-brand-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-sm font-bold">Cambiar Imagen</div>
                     </div>
                   ) : (
                     <div className="py-8 flex flex-col items-center gap-2 text-gray-400">
                       <ImageIcon size={32} />
                       <span className="text-sm font-medium">Click para subir foto (se comprimirá automático)</span>
                     </div>
                   )}
                </div>
                <input type="file" accept="image/jpeg, image/png, image/webp" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-xs text-gray-400 font-bold uppercase">O PEGAR URL DE VIDEO/IMAGEN:</span>
                  <input type="text" value={productForm.img} onChange={e => setProductForm({...productForm, img: e.target.value})} className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand-orange" placeholder="https://..." />
                </div>
              </div>

              <div className="pt-4">
                 <button type="submit" disabled={isSaving} className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white py-3.5 rounded-xl font-bold uppercase tracking-wide transition-colors disabled:opacity-50">
                   {isSaving ? 'Guardando...' : (editingProduct ? 'Guardar Cambios' : 'Crear Producto')}
                 </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Manual Order Modal */}
      {showNewOrderModal && (
        <div className="fixed inset-0 bg-brand-black/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 z-10">
              <div>
                <h2 className="text-2xl font-black text-brand-black uppercase tracking-tight">Nuevo Pedido Manual</h2>
                <p className="text-sm text-brand-gray font-medium">Cargá los detalles del cliente y los productos.</p>
              </div>
              <button 
                onClick={() => { setShowNewOrderModal(false); setManualOrderItems([]); }}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X size={24} className="text-gray-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: Customer Info */}
                <div className="space-y-6">
                   <h3 className="text-sm border-b pb-2 font-black uppercase text-brand-orange tracking-widest">1. Datos del Cliente</h3>
                   <div className="space-y-4">
                     <div>
                       <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Nombre Completo</label>
                       <input 
                         type="text" 
                         value={manualOrderForm.name}
                         onChange={e => setManualOrderForm({...manualOrderForm, name: e.target.value})}
                         className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange transition-colors"
                         placeholder="Ej: Juan Pérez"
                       />
                     </div>
                     <div>
                       <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Teléfono (WhatsApp)</label>
                       <input 
                         type="text" 
                         value={manualOrderForm.phone}
                         onChange={e => setManualOrderForm({...manualOrderForm, phone: e.target.value})}
                         className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange transition-colors"
                         placeholder="Ej: 1123456789"
                       />
                     </div>
                     <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Método</label>
                          <select 
                            value={manualOrderForm.method}
                            onChange={e => setManualOrderForm({...manualOrderForm, method: e.target.value as any})}
                            className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange"
                          >
                            <option value="delivery">Delivery</option>
                            <option value="pickup">Retiro en Local</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Pago</label>
                          <select 
                            value={manualOrderForm.paymentMethod}
                            onChange={e => setManualOrderForm({...manualOrderForm, paymentMethod: e.target.value})}
                            className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange"
                          >
                            <option value="efectivo">Efectivo</option>
                            <option value="transferencia">Transferencia</option>
                            <option value="mercadopago">Mercado Pago</option>
                          </select>
                        </div>
                     </div>
                     {manualOrderForm.method === 'delivery' && (
                       <>
                        <div>
                          <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Dirección de Envío</label>
                          <input 
                            type="text" 
                            value={manualOrderForm.address}
                            onChange={e => setManualOrderForm({...manualOrderForm, address: e.target.value})}
                            className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange"
                            placeholder="Ej: Av. Rivadavia 1234, 5C"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Costo de Envío ($)</label>
                          <input 
                            type="number" 
                            value={manualOrderForm.deliveryCost}
                            onChange={e => setManualOrderForm({...manualOrderForm, deliveryCost: parseInt(e.target.value) || 0})}
                            className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange"
                            placeholder="0"
                          />
                        </div>
                       </>
                     )}
                     <div>
                       <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Notas Administrativas</label>
                       <textarea 
                         value={manualOrderForm.adminNotes}
                         onChange={e => setManualOrderForm({...manualOrderForm, adminNotes: e.target.value})}
                         className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange h-24 resize-none"
                         placeholder="Detalles internos..."
                       />
                     </div>
                   </div>
                </div>

                {/* Right: Products Selection & Total */}
                <div className="space-y-6">
                   <h3 className="text-sm border-b pb-2 font-black uppercase text-brand-orange tracking-widest">2. Productos</h3>
                   
                   <div className="space-y-4">
                      {/* Search & Add */}
                      <div className="relative">
                        <input 
                          type="text"
                          placeholder="Buscar producto para agregar..."
                          className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-brand-orange"
                          onChange={(e) => {
                            const val = e.target.value.toLowerCase();
                            setProductSearch(val);
                          }}
                        />
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      </div>

                      <div className="bg-gray-50 rounded-2xl p-4 max-h-[300px] overflow-y-auto space-y-2 border border-gray-100">
                         {products
                          .filter(p => !productSearch || p.name.toLowerCase().includes(productSearch))
                          .map(p => (
                            <button
                              key={p.id}
                              onClick={() => {
                                const exists = manualOrderItems.find(item => item.id === p.id);
                                if (exists) {
                                  setManualOrderItems(manualOrderItems.map(item => 
                                    item.id === p.id ? { ...item, quantity: item.quantity + 1 } : item
                                  ));
                                } else {
                                  setManualOrderItems([...manualOrderItems, { ...p, quantity: 1 }]);
                                }
                              }}
                              className="w-full text-left bg-white p-3 rounded-xl shadow-sm border border-gray-100 hover:border-brand-orange transition-colors flex justify-between items-center group"
                            >
                               <div>
                                 <p className="font-bold text-sm text-brand-black group-hover:text-brand-orange transition-colors">{p.name.toUpperCase()}</p>
                                 <p className="text-xs text-brand-gray">${p.price.toLocaleString()}</p>
                               </div>
                               <Plus className="text-brand-orange" size={18} />
                            </button>
                         ))}
                      </div>

                      {/* Summary of Items Added */}
                      <div className="space-y-2">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest px-1">Items en pedido:</p>
                        {manualOrderItems.length === 0 ? (
                           <p className="text-sm text-gray-400 italic px-1">Sin productos agregados.</p>
                        ) : (
                          <div className="space-y-2">
                            {manualOrderItems.map(item => (
                              <div key={item.id} className="flex items-center justify-between bg-white border border-gray-100 p-3 rounded-xl shadow-sm">
                                 <div className="flex items-center gap-3">
                                   <div className="flex items-center gap-2 bg-orange-50 px-2 py-1 rounded-lg">
                                      <button onClick={() => {
                                        if (item.quantity > 1) {
                                          setManualOrderItems(manualOrderItems.map(i => i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i));
                                        } else {
                                          setManualOrderItems(manualOrderItems.filter(i => i.id !== item.id));
                                        }
                                      }} className="text-brand-orange font-bold text-lg">-</button>
                                      <span className="font-bold text-brand-orange min-w-[20px] text-center">{item.quantity}</span>
                                      <button onClick={() => {
                                        setManualOrderItems(manualOrderItems.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
                                      }} className="text-brand-orange font-bold text-lg">+</button>
                                   </div>
                                   <span className="font-bold text-xs text-brand-black">{item.name.toUpperCase()}</span>
                                 </div>
                                 <span className="font-bold text-sm text-brand-black">${(item.price * item.quantity).toLocaleString()}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                   </div>

                   {/* Total Display */}
                   <div className="bg-brand-black text-white p-6 rounded-3xl space-y-2 shadow-xl shadow-brand-black/20">
                      <div className="flex justify-between text-sm opacity-60">
                        <span>Subtotal Products:</span>
                        <span>${manualOrderItems.reduce((acc, i) => acc + (i.price * i.quantity), 0).toLocaleString()}</span>
                      </div>
                      {manualOrderForm.method === 'delivery' && (
                        <div className="flex justify-between text-sm opacity-60">
                          <span>Envío:</span>
                          <span>${(manualOrderForm.deliveryCost || 0).toLocaleString()}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-2xl font-black pt-2 border-t border-white/10">
                        <span>TOTAL:</span>
                        <span className="text-brand-orange">${(
                          manualOrderItems.reduce((acc, i) => acc + (i.price * i.quantity), 0) + 
                          (manualOrderForm.method === 'delivery' ? (manualOrderForm.deliveryCost || 0) : 0)
                        ).toLocaleString()}</span>
                      </div>
                   </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-100 bg-gray-50 flex gap-4">
               <button 
                onClick={() => { setShowNewOrderModal(false); setManualOrderItems([]); }}
                className="flex-1 bg-white border border-gray-200 text-gray-600 py-4 rounded-2xl font-bold hover:bg-gray-50 transition-colors uppercase tracking-widest text-sm"
               >
                 Cancelar
               </button>
               <button 
                onClick={handleCreateManualOrder}
                className="flex-[2] bg-brand-orange text-white py-4 rounded-2xl font-black shadow-lg shadow-brand-orange/20 hover:bg-brand-orange-dark transition-all transform active:scale-95 uppercase tracking-widest"
               >
                 Registrar Pedido
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
