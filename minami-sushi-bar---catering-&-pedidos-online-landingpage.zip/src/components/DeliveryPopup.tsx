import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, X, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DeliveryPopup() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user has already seen the popup this session to avoid annoyance
    const hasSeenPopup = sessionStorage.getItem('minami_delivery_popup_seen');
    if (!hasSeenPopup) {
      setIsOpen(true);
      sessionStorage.setItem('minami_delivery_popup_seen', 'true');
    }
  }, []);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-brand-black/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4"
        onClick={() => setIsOpen(false)}
      >
        <motion.div 
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="bg-white rounded-3xl w-full max-w-md overflow-hidden relative shadow-2xl"
          onClick={e => e.stopPropagation()}
        >
          {/* Close button */}
          <button 
            onClick={() => setIsOpen(false)}
            className="absolute top-4 right-4 z-10 w-8 h-8 bg-brand-black/10 hover:bg-brand-black/20 text-brand-black rounded-full flex items-center justify-center transition-colors"
          >
            <X size={18} />
          </button>

          {/* Header Image */}
          <div className="h-40 bg-brand-black w-full relative">
            <img 
              src="https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&q=80&w=600" 
              alt="Sushi Delivery" 
              className="w-full h-full object-cover opacity-80"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-black to-transparent" />
            <div className="absolute bottom-4 left-6 flex items-center gap-2">
              <span className="bg-brand-orange text-white text-xs font-bold uppercase tracking-wider px-2 py-1 rounded">Novedad</span>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 text-center">
            <h2 className="text-2xl font-display font-bold text-brand-black mb-2">¡Pedí Delivery o Pick Up!</h2>
            
            <div className="bg-orange-50 text-brand-orange text-sm p-4 rounded-2xl mb-6 text-left flex items-start gap-3">
              <Info size={20} className="shrink-0 mt-0.5" />
              <div>
                <p className="font-bold mb-1">Días Sábados por la noche</p>
                <p className="text-xs text-brand-orange/80">Retiros por <strong>Las Heras 323</strong><br/>Horario: 21:00 a 21:30hs</p>
              </div>
            </div>

            <p className="text-brand-gray text-sm mb-6">
              Ya podés hacer tu pedido online, armar tu combo y elegir entrega a domicilio o retiro por el local.
            </p>

            <button
              onClick={() => {
                setIsOpen(false);
                navigate('/tienda');
              }}
              className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white py-4 rounded-xl flex items-center justify-center gap-2 font-bold uppercase tracking-widest transition-colors shadow-lg shadow-brand-orange/30"
            >
              <ShoppingBag size={20} />
              Ir a la Tienda
            </button>
            
            <button
              onClick={() => setIsOpen(false)}
              className="mt-4 text-xs font-bold text-brand-gray hover:text-brand-black uppercase tracking-wider transition-colors"
            >
              Continuar viendo la web
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
