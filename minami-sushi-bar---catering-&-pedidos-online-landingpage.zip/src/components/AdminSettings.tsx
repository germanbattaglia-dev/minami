import React, { useState, useEffect } from 'react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc, setDoc } from 'firebase/firestore';
import { Plus, Trash2, Save } from 'lucide-react';

export default function AdminSettings({ settings }: { settings: any }) {
  const [zones, setZones] = useState<{name: string, price: number}[]>([]);
  const [tags, setTags] = useState<{name: string, icon: string}[]>([]);
  const [subCategories, setSubCategories] = useState<{name: string}[]>([]);
  const [fidelityDiscount, setFidelityDiscount] = useState<number>(15);
  const [fidelityFrequency, setFidelityFrequency] = useState<number>(3);
  const [fidelityThreshold, setFidelityThreshold] = useState<number>(20000);
  const [storeSchedule, setStoreSchedule] = useState<{days: string, hours: string}[]>([]);

  useEffect(() => {
    if (settings && settings.deliveryZones) setZones(settings.deliveryZones);
    else setZones([
      { name: 'Coronel Suárez (Centro)', price: 1500 },
      { name: 'Pueblo San José', price: 2500 }
    ]);
    
    if (settings?.fidelityDiscount) setFidelityDiscount(settings.fidelityDiscount);
    if (settings?.fidelityFrequency) setFidelityFrequency(settings.fidelityFrequency);
    if (settings?.fidelityThreshold !== undefined) setFidelityThreshold(settings.fidelityThreshold);
    
    if (settings?.storeSchedule) {
      if (Array.isArray(settings.storeSchedule)) {
        setStoreSchedule(settings.storeSchedule);
      } else if (typeof settings.storeSchedule === 'string') {
        setStoreSchedule([{ days: 'General', hours: settings.storeSchedule }]);
      }
    } else {
      setStoreSchedule([{ days: 'Sábados', hours: '19:30 a 23:30hs' }]);
    }


    if (settings && settings.tags) {
      setTags(settings.tags);
    } else {
      setTags([
        { name: 'Vegano', icon: '🌱' },
        { name: 'Veggie', icon: '🥕' },
        { name: 'Picante', icon: '🌶️' },
        { name: 'Frito', icon: '🍤' },
        { name: 'Cocido', icon: '♨️' }
      ]);
    }

    if (settings && settings.subCategories) {
      setSubCategories(settings.subCategories);
    } else {
      setSubCategories([
        { name: 'Salmón' },
        { name: 'Palta' },
        { name: 'Langostino' },
        { name: 'Kanikama' }
      ]);
    }
  }, [settings]);

  const save = async () => {
    try {
      await setDoc(doc(db, 'settings', 'store'), { 
        deliveryZones: zones, 
        tags, 
        subCategories, 
        fidelityDiscount, 
        fidelityFrequency,
        fidelityThreshold,
        storeSchedule 
      }, { merge: true });
      alert('Configuraciones guardadas con éxito');
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'settings/store');
    }
  };

  const addZone = () => setZones([...zones, { name: '', price: 0 }]);
  const updateZone = (i: number, field: 'name' | 'price', val: string | number) => {
    const newZones = [...zones];
    newZones[i] = { ...newZones[i], [field]: val };
    setZones(newZones);
  }
  const removeZone = (i: number) => setZones(zones.filter((_, idx) => idx !== i));

  const addTag = () => setTags([...tags, { name: '', icon: '' }]);
  const updateTag = (i: number, field: 'name' | 'icon', val: string) => {
    const newTags = [...tags];
    newTags[i] = { ...newTags[i], [field]: val };
    setTags(newTags);
  }
  const removeTag = (i: number) => setTags(tags.filter((_, idx) => idx !== i));

  const addSubCategory = () => setSubCategories([...subCategories, { name: '' }]);
  const updateSubCategory = (i: number, val: string) => {
    const newSC = [...subCategories];
    newSC[i] = { name: val };
    setSubCategories(newSC);
  }
  const removeSubCategory = (i: number) => setSubCategories(subCategories.filter((_, idx) => idx !== i));

  const addSchedule = () => setStoreSchedule([...storeSchedule, { days: '', hours: '' }]);
  const updateSchedule = (i: number, field: 'days' | 'hours', val: string) => {
    const newSched = [...storeSchedule];
    newSched[i] = { ...newSched[i], [field]: val };
    setStoreSchedule(newSched);
  }
  const removeSchedule = (i: number) => setStoreSchedule(storeSchedule.filter((_, idx) => idx !== i));

  return (
    <div className="max-w-3xl">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold text-brand-black">Ajustes Generales</h1>
        <p className="text-brand-gray">Configuraciones de la tienda.</p>
      </div>

      <div className="mb-8 bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold bg-green-100 px-3 py-1 rounded inline-block text-green-700">HORARIO</h2>
        </div>
        <p className="text-sm text-gray-500 mb-6">Configura los días y horarios en los que tomas reservas de sushi.</p>
        
        <div className="space-y-4 mb-6">
          {storeSchedule.map((item, i) => (
            <div key={i} className="flex gap-3 items-center bg-gray-50 p-4 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex-1 space-y-3">
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-bold text-gray-400 uppercase w-12 shrink-0">Días</span>
                  <input 
                    type="text" 
                    value={item.days} 
                    onChange={e => updateSchedule(i, 'days', e.target.value)} 
                    className="flex-1 bg-white border p-2.5 rounded-lg focus:border-brand-orange outline-none text-sm" 
                    placeholder="Ej: Sábados" 
                  />
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-bold text-gray-400 uppercase w-12 shrink-0">Horas</span>
                  <input 
                    type="text" 
                    value={item.hours} 
                    onChange={e => updateSchedule(i, 'hours', e.target.value)} 
                    className="flex-1 bg-white border p-2.5 rounded-lg focus:border-brand-orange outline-none text-sm" 
                    placeholder="Ej: 19:30 a 23:30hs" 
                  />
                </div>
              </div>
              <button 
                onClick={() => removeSchedule(i)} 
                className="text-gray-300 hover:text-red-500 p-2 transition-colors"
                title="Eliminar este rango"
              >
                <Trash2 size={20}/>
              </button>
            </div>
          ))}

          <button onClick={addSchedule} className="text-brand-orange font-bold text-sm flex items-center gap-2 hover:opacity-80 transition-opacity px-2">
            <Plus size={18} className="bg-brand-orange text-white rounded-full p-0.5" /> Agregar otro rango horario
          </button>
        </div>

        <div className="pt-4 border-t border-gray-100 flex justify-end">
          <button onClick={save} className="bg-brand-black hover:bg-gray-800 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all">
            <Save size={18}/> Guardar Horarios
          </button>
        </div>
      </div>

      <div className="mb-8 bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold bg-orange-100 px-3 py-1 rounded inline-block text-brand-orange">Zonas de Delivery</h2>
        </div>
        <p className="text-sm text-gray-500 mb-6">Gestiona los costos de envío para cada zona de cobertura.</p>
        
        <div className="space-y-3 mb-6">
          {zones.map((zone, i) => (
            <div key={i} className="flex gap-4 items-center bg-gray-50 p-4 rounded-xl border border-gray-100">
              <input 
                type="text" 
                value={zone.name} 
                onChange={e => updateZone(i, 'name', e.target.value)} 
                className="flex-1 bg-white border p-2.5 rounded-lg focus:border-brand-orange outline-none text-sm" 
                placeholder="Nombre de la zona (ej: Centro)" 
              />
              <div className="flex items-center gap-2">
                <span className="font-bold text-gray-400">$</span>
                <input 
                  type="number" 
                  min="0" 
                  value={zone.price} 
                  onChange={e => updateZone(i, 'price', Number(e.target.value))} 
                  className="w-32 bg-white border p-2.5 rounded-lg focus:border-brand-orange outline-none text-sm font-bold" 
                  placeholder="Costo" 
                />
              </div>
              <button 
                onClick={() => removeZone(i)} 
                className="text-gray-400 hover:text-red-500 p-2 transition-colors"
                title="Eliminar zona"
              >
                <Trash2 size={20}/>
              </button>
            </div>
          ))}

          <button onClick={addZone} className="text-brand-orange font-bold text-sm flex items-center gap-2 hover:opacity-80 transition-opacity px-2">
            <Plus size={18} className="bg-brand-orange text-white rounded-full p-0.5" /> Agregar otra zona
          </button>
        </div>

        <div className="pt-4 border-t border-gray-100 flex justify-end">
          <button onClick={save} className="bg-brand-black hover:bg-gray-800 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all">
            <Save size={18}/> Guardar Zonas
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold bg-blue-100 px-3 py-1 rounded inline-block text-blue-600">Sistema de Fidelidad</h2>
        </div>
        <p className="text-sm text-gray-500 mb-6">Configura los beneficios automáticos para tus clientes recurrentes.</p>
        
        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 flex flex-col gap-6 mb-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 mt-1 block uppercase tracking-wider">Descuento (%)</label>
              <div className="flex items-center gap-3">
                <input 
                  type="number" 
                  min="0"
                  max="100"
                  value={fidelityDiscount} 
                  onChange={e => setFidelityDiscount(Number(e.target.value))} 
                  className="w-full bg-white border p-3 rounded-xl focus:border-brand-orange outline-none font-bold text-lg" 
                />
                <span className="font-black text-gray-300 text-2xl">%</span>
              </div>
              <p className="text-[10px] text-gray-400 italic">Descuento aplicado al alcanzar la meta.</p>
            </div>
            
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 mt-1 block uppercase tracking-wider">Meta (Compras)</label>
              <div className="flex items-center gap-3">
                <input 
                  type="number" 
                  min="1"
                  value={fidelityFrequency} 
                  onChange={e => setFidelityFrequency(Number(e.target.value))} 
                  className="w-full bg-white border p-3 rounded-xl focus:border-brand-orange outline-none font-bold text-lg" 
                />
                <span className="font-bold text-gray-300 text-xs uppercase">Visitas</span>
              </div>
              <p className="text-[10px] text-gray-400 italic">Cada cuántos pedidos se dispara el beneficio.</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500 mt-1 block uppercase tracking-wider">Monto Mínimo ($)</label>
            <div className="flex items-center gap-3 max-w-sm">
              <span className="font-black text-gray-300 text-2xl">$</span>
              <input 
                type="number" 
                min="0"
                value={fidelityThreshold} 
                onChange={e => setFidelityThreshold(Number(e.target.value))} 
                className="w-full bg-white border p-3 rounded-xl focus:border-brand-orange outline-none font-bold text-lg" 
              />
            </div>
            <p className="text-[10px] text-gray-400 italic">El pedido debe superar este monto para sumar punto de fidelidad.</p>
          </div>
        </div>

        <div className="pt-4 border-t border-gray-100 flex justify-end">
          <button onClick={save} className="bg-brand-black hover:bg-gray-800 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all">
            <Save size={18}/> Guardar Fidelidad
          </button>
        </div>
      </div>

    </div>
  );
}
