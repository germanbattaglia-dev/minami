import React, { useState, useEffect } from 'react';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Plus, Edit2, Trash2, X } from 'lucide-react';
import { getDirectImageUrl } from '../lib/imageUtils';

export default function AdminBlog() {
  const [posts, setPosts] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<any>(null);
  const [isSaving, setIsSaving] = useState(false);
  
  const [form, setForm] = useState({
    title: '',
    desc: '',
    content: '',
    img: '',
    date: ''
  });

  useEffect(() => {
    const q = query(collection(db, 'blog'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setPosts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'blog');
    });

    return () => unsub();
  }, []);

  const openNewModal = () => {
    setEditingPost(null);
    setForm({ title: '', desc: '', content: '', img: '', date: '' });
    setIsModalOpen(true);
  };

  const editPost = (post: any) => {
    setEditingPost(post);
    setForm({
      title: post.title,
      desc: post.desc,
      content: post.content || '',
      img: post.img,
      date: post.date || ''
    });
    setIsModalOpen(true);
  };

  const deletePost = async (id: string) => {
    if (!window.confirm("¿Seguro que querés eliminar esta publicación?")) return;
    try {
      await deleteDoc(doc(db, 'blog', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `blog/${id}`);
    }
  };

  const savePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.desc || !form.img) return alert("Por favor completá los campos obligatorios.");
    
    setIsSaving(true);
    try {
      const data = {
        ...form,
        date: form.date || new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' }),
        createdAt: editingPost && editingPost.createdAt ? editingPost.createdAt : serverTimestamp()
      };

      if (editingPost) {
        await updateDoc(doc(db, 'blog', editingPost.id), data);
      } else {
        await addDoc(collection(db, 'blog'), data);
      }
      
      setIsModalOpen(false);
    } catch (e) {
      handleFirestoreError(e, editingPost ? OperationType.UPDATE : OperationType.CREATE, 'blog');
      alert("Error al guardar la publicación.");
    } finally {
      setIsSaving(false);
    }
  };

  const seedDefaults = async () => {
    setIsSaving(true);
    const defaults = [
      { title: "Tendencias 2024: Sushi Bars en Casamientos", date: "15 Oct 2023", img: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&q=80&w=400", desc: "Por qué cada vez más novios eligen incorporar estaciones de sushi en vivo en sus celebraciones.", content: "Cada vez más parejas deciden romper con los esquemas clásicos y apuestan por propuestas innovadoras. El Sushi Bar en vivo no solo ofrece una comida deliciosa, sino que también brinda un espectáculo visual que encanta a los invitados. Un sushiman profesional preparando las piezas en el momento garantiza la máxima frescura y calidad, adaptándose a los gustos de cada comensal." },
      { title: "Nuevas Opciones Veganas en nuestro Menú", date: "02 Sep 2023", img: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&q=80&w=400", desc: "Ampliamos nuestra carta con más opciones plant-based sin perder la esencia y el sabor premium.", content: "Escuchamos a nuestros clientes y decidimos ampliar nuestra propuesta gastronómica. Ahora contamos con una variedad de rolls y nigiris 100% basados en plantas (plant-based). Utilizamos ingredientes frescos y exóticos como hongos shiitake, palta, espárragos, queso de castañas y salsas especiales veganas. Queremos que todos puedan disfrutar de la experiencia Minami sin restricciones y con el mismo nivel de calidad." }
    ];
    try {
      for (const post of defaults.reverse()) {
        await addDoc(collection(db, 'blog'), {
          ...post,
          createdAt: serverTimestamp()
        });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'blog');
      alert("Error al cargar publicaciones de ejemplo.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-brand-black">Blog</h1>
          <p className="text-brand-gray">Gestión de publicaciones de noticias.</p>
        </div>
        <button 
          onClick={openNewModal}
          className="flex items-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white px-4 py-2 rounded-full shadow-sm text-sm font-bold transition-colors"
        >
          <Plus size={18} /> Nueva Entrada
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {posts.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            <p className="mb-4 italic">No hay publicaciones en el blog.</p>
            <button 
              onClick={seedDefaults} 
              disabled={isSaving}
              className="bg-brand-black text-white px-6 py-3 rounded-xl text-sm font-bold hover:bg-gray-800 transition-colors disabled:opacity-50"
            >
              {isSaving ? 'Cargando...' : 'Cargar publicaciones de ejemplo'}
            </button>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {posts.map(post => (
              <div key={post.id} className="p-6 flex flex-col md:flex-row gap-6 items-start md:items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex gap-4 items-center">
                  <div className="w-24 h-24 rounded-xl overflow-hidden shrink-0 shadow-sm border border-gray-100">
                    <img 
                      src={getDirectImageUrl(post.img)} 
                      alt={post.title} 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer" 
                    />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-brand-black mb-1">{post.title}</h3>
                    <p className="text-sm text-gray-500 line-clamp-2 max-w-xl mb-2">{post.desc}</p>
                    <span className="text-xs font-bold text-brand-orange uppercase tracking-wider">{post.date}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => editPost(post)} className="w-10 h-10 rounded-xl bg-gray-100 text-gray-600 flex items-center justify-center hover:bg-brand-orange hover:text-white transition-colors">
                    <Edit2 size={18} />
                  </button>
                  <button onClick={() => deletePost(post.id)} className="w-10 h-10 rounded-xl bg-gray-100 text-gray-600 flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors">
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-brand-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white z-10 sticky top-0">
              <h2 className="text-2xl font-display font-bold">{editingPost ? 'Editar Entrada' : 'Nueva Entrada'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-700 transition-colors">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={savePost} className="p-6 overflow-y-auto space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Título *</label>
                <input required type="text" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange" placeholder="Ej: Nuevas Opciones Veganas" />
              </div>
              
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Breve Resumen *</label>
                <textarea required value={form.desc} onChange={e => setForm({...form, desc: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange resize-none h-20" placeholder="Ej: Ampliamos nuestra carta vegana..."></textarea>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">URL de Imagen *</label>
                <input required type="text" value={form.img} onChange={e => setForm({...form, img: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange" placeholder="https://..." />
                {form.img && (
                  <div className="mt-2 aspect-video rounded-xl overflow-hidden border border-gray-100 max-h-32">
                    <img 
                      src={getDirectImageUrl(form.img)} 
                      alt="Preview" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer" 
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Contenido (Opcional)</label>
                <textarea value={form.content} onChange={e => setForm({...form, content: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange resize-y min-h-[150px]" placeholder="Aquí podés escribir lo que quieras o necesites informar..."></textarea>
              </div>

              <div className="pt-4">
                <button type="submit" disabled={isSaving} className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white font-bold py-4 rounded-xl transition-colors disabled:opacity-50">
                  {isSaving ? 'Guardando...' : 'Guardar Entrada'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
