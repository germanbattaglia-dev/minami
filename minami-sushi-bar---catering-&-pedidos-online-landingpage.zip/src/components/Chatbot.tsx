import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user'|'model', text: string}[]>([
    { role: 'model', text: '¡Hola! Soy el asistente virtual de Minami Sushi Bar. ¿En qué te puedo ayudar hoy? ¿Querés consultar sobre la contratación para algún evento o hacer un pedido de sushi?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const initChat = () => {
    if (!chatRef.current) {
      const systemInstruction = `Eres el asistente virtual de Minami Sushi Bar. Tu objetivo es responder consultas de forma breve, amable y profesional.

IMPORTANTE - TENEMOS DOS SERVICIOS SEPARADOS:

1. EVENTOS Y CATERING (Sushi Bar para Eventos):
- Es un servicio premium de catering in-situ para casamientos, cumpleaños y eventos corporativos.
- Para este servicio, debes sugerir SIEMPRE completar el formulario de "Cotizá tu evento" en la web o contactar por WhatsApp.
- Nunca des presupuestos automáticos, ya que cada evento es personalizado.

2. DELIVERY Y PICK UP (Tienda Online):
- ATENCIÓN: Solo funciona los DÍAS SÁBADOS por la noche.
- El pedido se realiza exclusivamente a través de la [Tienda Online](/tienda).
- Los pedidos se abren durante la semana y se retiran/envían el sábado.

Datos de contacto:
- Teléfono/WhatsApp: 2926-547663
- Email: minamisushibarr@gmail.com
- Instagram: @minamisushibar
- Retiro (Pick Up): Las Heras 323, horario de retiro de 21:00 a 21:30hs (Sábados).

Si te consultan por catering, dirígelos al formulario. Si te consultan por un pedido de sushi hoy, aclara que es solo para los sábados y envíalos a la Tienda.`;

      chatRef.current = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });
    }
  };

  const toggleChat = () => {
    if (!isOpen) initChat();
    setIsOpen(!isOpen);
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;
    
    initChat();
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const response = await chatRef.current.sendMessage({ message: userMsg });
      setMessages(prev => [...prev, { role: 'model', text: response.text }]);
    } catch (error) {
      console.error("Error communicating with Gemini AI:", error);
      setMessages(prev => [...prev, { role: 'model', text: '¡Hola! Para hacer un pedido por favor dirigite a nuestra [Tienda Online](/tienda). Recordá que tomamos pedidos únicamente para los días sábados por la noche. ¡Te esperamos!' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <button
            onClick={toggleChat}
            className="fixed bottom-24 right-6 z-40 bg-brand-black text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center border border-white/20"
            aria-label="Abrir asistente de IA"
          >
            <MessageCircle size={28} />
          </button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-[100px] right-4 sm:right-6 w-[360px] max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-2xl overflow-hidden z-[120] border border-gray-200 flex flex-col"
            style={{ height: '500px', maxHeight: 'calc(100vh - 120px)' }}
          >
            {/* Close button that appears only inside the widget on mobile if it covers the button, but the button shouldn't be fully covered on desktop */}
            <button 
              onClick={toggleChat}
              className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
            <div className="bg-brand-black p-4 flex items-center gap-3">
              <div className="w-10 h-10 bg-brand-orange rounded-full flex items-center justify-center text-white shrink-0 font-bold font-display">
                M
              </div>
              <div>
                <h3 className="text-white font-display font-bold">Asistente Minami</h3>
                <p className="text-gray-400 text-xs flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span>
                  IA Activa
                </p>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-brand-gray-light/30">
              {messages.map((msg, idx) => (
                <div key={idx} className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-gray-200 text-gray-500' : 'bg-brand-orange text-white'}`}>
                    {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                  </div>
                  <div className={`p-3 rounded-2xl text-sm leading-relaxed ${msg.role === 'user' ? 'bg-brand-black text-white rounded-tr-sm shadow-md' : 'bg-white border border-gray-100 text-gray-800 rounded-tl-sm shadow-md'}`}>
                    {msg.role === 'user' ? (
                       msg.text
                    ) : (
                      <div className="markdown-body prose prose-sm prose-orange">
                        <Markdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            a: ({node, ...props}) => <a {...props} className="text-brand-orange hover:underline font-bold" />
                          }}
                        >
                          {msg.text}
                        </Markdown>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-3 max-w-[85%] mr-auto">
                  <div className="w-8 h-8 rounded-full bg-brand-orange text-white flex items-center justify-center shrink-0">
                    <Bot size={16} />
                  </div>
                  <div className="p-3 bg-white border border-gray-100 rounded-2xl rounded-tl-sm shadow-md flex items-center gap-1.5 h-11">
                    <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1 }} className="w-2 h-2 bg-gray-300 rounded-full" />
                    <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 bg-gray-300 rounded-full" />
                    <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 bg-gray-300 rounded-full" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSend} className="p-3 bg-white border-t border-gray-100">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Escribí tu consulta..."
                  className="flex-1 bg-brand-gray-light border border-transparent focus:border-brand-orange focus:bg-white rounded-full px-4 py-2.5 text-sm outline-none transition-all"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="w-10 h-10 bg-brand-orange text-white rounded-full flex items-center justify-center hover:bg-brand-orange-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
                >
                  <Send size={18} className="-mr-1" />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
