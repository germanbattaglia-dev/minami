import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, ChevronLeft, Plus, Minus, Info, X, MapPin, CreditCard, Banknote, Smartphone, Check, Search, Building, Share2, Instagram, Image as ImageIcon, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, onSnapshot, query, orderBy, doc, getDoc } from 'firebase/firestore';
import WhatsAppButton from './WhatsAppButton';
import Chatbot from './Chatbot';
import { toBlob } from 'html-to-image';
import { getDirectImageUrl } from '../lib/imageUtils';

export default function Store() {
  const [products, setProducts] = useState<any[]>([]);
  const [availableTags, setAvailableTags] = useState<{name: string, icon: string}[]>([]);
  const [loading, setLoading] = useState(true);
  const [storeOpen, setStoreOpen] = useState(true);
  const [storeSettings, setStoreSettings] = useState<any>(null);
  const [tick, setTick] = useState(0);

  const checkIsStoreOpen = (settings: any) => {
    if (!settings) return true;
    
    // 1. Manual switch check
    // If it's explicitly 'closed', it's closed. 
    // If it's explicitly 'open', it's open.
    // If it's 'auto' (or undefined for backward compatibility), follow schedule.
    if (settings.ordersOpen === 'closed') return false;
    if (settings.ordersOpen === 'open') return true;
    
    // 3. Schedule check
    const schedule = settings.storeSchedule;
    if (!schedule || !Array.isArray(schedule) || schedule.length === 0) return true;
    
    const now = new Date();
    // Use local time for Argentina (standard for this type of local business app)
    const currentDay = now.getDay(); // 0: Sunday, 1: Monday ...
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    const dayMap: Record<number, string> = {
      0: 'domingo',
      1: 'lunes',
      2: 'martes',
      3: 'miércoles',
      4: 'jueves',
      5: 'viernes',
      6: 'sábado'
    };

    return schedule.some((item: any) => {
      const daysStr = (item.days || '').toLowerCase();
      const hoursStr = (item.hours || '').toLowerCase();
      
      let dayMatch = false;
      const todayName = dayMap[currentDay];

      if (daysStr.includes('todos') || daysStr.includes('diario') || daysStr.includes('siempre')) {
        dayMatch = true;
      } else if (daysStr.includes('lunes a viernes')) {
        dayMatch = currentDay >= 1 && currentDay <= 5;
      } else if (daysStr.includes('lunes a sábado') || daysStr.includes('lunes a sabado')) {
        dayMatch = currentDay >= 1 && currentDay <= 6;
      } else if (daysStr.includes('fin de semana')) {
        dayMatch = currentDay === 0 || currentDay === 6;
      } else if (daysStr.includes(todayName) || 
                (currentDay === 6 && daysStr.includes('sabado')) || 
                (currentDay === 3 && daysStr.includes('miercoles'))) {
        dayMatch = true;
      }
      
      if (!dayMatch) return false;

      // Hours parsing: "19:30 a 23:30hs" or "19:30 - 23:30"
      const timeRegex = /(\d{1,2})[:.](\d{2})\s*(?:a|-|hasta)\s*(\d{1,2})[:.](\d{2})/;
      const match = hoursStr.replace(/hs|horas/g, '').match(timeRegex);
      
      if (match) {
        const start = parseInt(match[1]) * 60 + parseInt(match[2]);
        const end = parseInt(match[3]) * 60 + parseInt(match[4]);
        
        if (end < start) {
          // Crosses midnight
          return currentMinutes >= start || currentMinutes <= end;
        }
        return currentMinutes >= start && currentMinutes <= end;
      }

      return true; // Fallback if format is weird but day matches
    });
  };

  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 30000); // Check every 30s
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (storeSettings) {
      setStoreOpen(checkIsStoreOpen(storeSettings));
    }
  }, [storeSettings, tick]);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'all' | 'rolls' | 'combinados' | 'picoteo' | 'salsas' | 'extras'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<{product: any, quantity: number}[]>([]);
  const [showTransferModal, setShowTransferModal] = useState(false);

  // Delivery Zones Configurable
  const [deliveryZones, setDeliveryZones] = useState<any[]>([
    { id: 'suarez', name: 'Centro', price: 1500 }
  ]);
  const minPurchase = 15000;

  // Checkout State
  const [orderMethod, setOrderMethod] = useState<'delivery' | 'pickup'>('pickup');
  const [address, setAddress] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [deliveryZone, setDeliveryZone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'efectivo' | 'transferencia' | 'mercadopago'>('efectivo');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fidelity State
  const [purchaseCount, setPurchaseCount] = useState(0);

  useEffect(() => {
    const cleanPhone = phone.replace(/\D/g, '');
    // Reset immediately if phone is changing to something new or too short
    if (!cleanPhone || cleanPhone.length < 8) {
      setPurchaseCount(0);
      return;
    }
    
    const fetchFidelity = async () => {
      try {
        const docRef = doc(db, 'customerFidelity', cleanPhone);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setPurchaseCount(docSnap.data().count || 0);
        } else {
          // If no recorded fidelity, check localStorage as fallback for this device
          const savedUser = localStorage.getItem('minami_user_data');
          if (savedUser) {
            const data = JSON.parse(savedUser);
            if (data.phone.replace(/\D/g, '') === cleanPhone) {
              setPurchaseCount(data.purchases || 0);
            } else {
              setPurchaseCount(0);
            }
          } else {
            setPurchaseCount(0);
          }
        }
      } catch (e) {
        console.error("Error fetching fidelity: ", e);
        setPurchaseCount(0);
      }
    };
    fetchFidelity();
  }, [phone]);

  const clearCustomerData = () => {
    setName('');
    setPhone('');
    setAddress('');
    setPurchaseCount(0);
    localStorage.removeItem('minami_user_data');
  };

  // Product detail modal
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [selectedVariety, setSelectedVariety] = useState<any>(null);
  const [sharingProduct, setSharingProduct] = useState<any>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const shareCardRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check Mercado Pago Return
    const params = new URLSearchParams(window.location.search);
    if (params.get('mp_success')) {
      const paymentId = params.get('payment_id');
      const savedPending = localStorage.getItem('minami_pending_mp');
      if (savedPending) {
        try {
          const { waLink } = JSON.parse(savedPending);
          const finalWaLink = waLink + encodeURIComponent(`\n\n✅ *PAGO MERCADOPAGO APROBADO*\nID de pago: ${paymentId}`);
          alert("¡Pago aprobado! Redirigiendo a WhatsApp para confirmar el pedido.");
          window.open(finalWaLink, '_blank');
          localStorage.removeItem('minami_pending_mp');
        } catch(e) {}
      }
      // Remove query params to clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (params.get('mp_pending')) {
      alert("Tu pago en Mercado Pago ha quedado pendiente. Podes confirmar tu pedido por WhatsApp y te avisamos cuando se acredite.");
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (params.get('mp_failure')) {
      alert("Hubo un problema o cancelaste el pago de Mercado Pago. Si querés podés reintentar o elegir otro medio de pago.");
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    // Check local storage for returning customer and fidelity
    const savedUser = localStorage.getItem('minami_user_data');
    if (savedUser) {
      try {
        const data = JSON.parse(savedUser);
        if (data.name && !name) {
           setName(data.name || '');
           setPhone(data.phone || '');
           if (data.address) setAddress(data.address);
        }
        if (data.purchases) {
          setPurchaseCount(data.purchases);
        }
      } catch (e) {}
    }

    const q = query(collection(db, 'products'));
    const unsub = onSnapshot(q, (snapshot) => {
      let fetchedProducts = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      fetchedProducts.sort((a: any, b: any) => {
        const orderA = a.sortOrder ?? 9999;
        const orderB = b.sortOrder ?? 9999;
        return orderA - orderB;
      });
      setProducts(fetchedProducts);
      setLoading(false);

      // Deep Linking: Auto-select product from URL if ?p=ID exists
      const params = new URLSearchParams(window.location.search);
      const productId = params.get('p');
      if (productId) {
        const product = fetchedProducts.find(p => p.id === productId);
        if (product) {
          setSelectedProduct(product);
        }
      }
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'products'));

    const unsubSettings = onSnapshot(doc(db, 'settings', 'store'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setStoreSettings(data);
        // Initial check
        setStoreOpen(checkIsStoreOpen(data));
        if (data.deliveryZones && Array.isArray(data.deliveryZones) && data.deliveryZones.length > 0) {
          setDeliveryZones(data.deliveryZones);
          setDeliveryZone(prev => prev || data.deliveryZones[0].name);
        }
        if (data.tags && Array.isArray(data.tags)) {
          setAvailableTags(data.tags);
        }
      }
    });
    
    return () => {
      unsub();
      unsubSettings();
    };
  }, []);

  // Slider State
  const sliderProducts = products.filter(p => p.inSlider);
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (sliderProducts.length === 0) return;
    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % sliderProducts.length);
    }, 4000); // 4 seconds
    return () => clearInterval(interval);
  }, [sliderProducts.length]);

  const handleApplyCoupon = async () => {
    if (!couponCode) return setAppliedCoupon(null);
    const code = couponCode.trim().toUpperCase();
    try {
      const docRef = doc(db, 'coupons', code);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists() && docSnap.data().active) {
        setAppliedCoupon({ id: code, ...docSnap.data() });
      } else {
        alert('Cupón inválido o inactivo.');
        setAppliedCoupon(null);
      }
    } catch (e) {
      alert('Error verificando el cupón.');
      setAppliedCoupon(null);
    }
  };

  const handleShare = (product: any, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSharingProduct(product);
  };

  const executeShare = async (product: any, mode: 'text' | 'image') => {
    if (isCapturing) return;

    const isOffer = product.isOffer && product.offerPrice;
    const finalPrice = isOffer ? product.offerPrice : product.price;
    const storeUrl = `${window.location.origin}${window.location.pathname}?p=${product.id}`;
    
    let pricingText = `Precio: *$${finalPrice.toLocaleString()}*`;
    if (isOffer) {
      pricingText = `🔥 *¡EN PROMOCIÓN!* \nDe ~$${product.price.toLocaleString()}~ a solo *$${product.offerPrice.toLocaleString()}*`;
    }
    
    const text = `🍱 *${product.name}* en Minami Sushi Bar\n\n${product.desc ? product.desc + '\n\n' : ''}${pricingText}\n\n🔗 Pedilo directamente acá:\n${storeUrl}`;

    if (mode === 'text') {
      if (navigator.share) {
        try {
          await navigator.share({
            title: `Minami Sushi Bar - ${product.name}`,
            text: text,
            url: storeUrl,
          });
          setSharingProduct(null);
        } catch (err) {
          if (err instanceof Error && err.name !== 'AbortError') {
            const waLink = `https://wa.me/?text=${encodeURIComponent(text)}`;
            window.open(waLink, '_blank');
            setSharingProduct(null);
          }
        }
      } else {
        const waLink = `https://wa.me/?text=${encodeURIComponent(text)}`;
        window.open(waLink, '_blank');
        setSharingProduct(null);
      }
      return;
    }

    // Mode: Image (Premium Card)
    setIsCapturing(true);
    
    // Simple text for image sharing context
    const shortText = `Minami Sushi Bar - ${product.name} 🍱`;

    try {
      // 1. PRE-LOAD THE IMAGE: This is CRITICAL to avoid blank captures
      if (product.img) {
        await new Promise((resolve) => {
          const img = new Image();
          img.crossOrigin = "anonymous";
          img.src = product.img;
          img.onload = resolve;
          img.onerror = resolve; // Continue anyway
          setTimeout(resolve, 2000); // Safety timeout
        });
      }

      // Ensure hidden card is rendered
      await new Promise(resolve => setTimeout(resolve, 500));

      if (shareCardRef.current) {
        try {
          // Use pixelRatio: 1.5 to balance quality and mobile memory constraints
          const blob = await toBlob(shareCardRef.current, {
            quality: 0.95,
            cacheBust: true,
            backgroundColor: '#ffffff',
            pixelRatio: 1.5,
          });
          
          if (blob) {
            const fileName = `minami_${product.name.toLowerCase().replace(/\s+/g, '_')}.png`;
            const file = new File([blob], fileName, { type: 'image/png' });
            
            // Try combined share first (File + Text)
            if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
              try {
                await navigator.share({
                  files: [file],
                  title: `Minami Sushi Bar`,
                  text: text
                });
                setSharingProduct(null);
                return; // SUCCESS
              } catch (shareErr) {
                if (shareErr instanceof Error && shareErr.name === 'AbortError') throw shareErr;
                
                // Fallback to just the file
                try {
                  await navigator.share({
                    files: [file],
                  });
                  setSharingProduct(null);
                  return; // SUCCESS
                } catch (secondShareErr) {
                   if (secondShareErr instanceof Error && secondShareErr.name === 'AbortError') throw secondShareErr;
                   // If all sharing fails, proceed to download
                }
              }
            }
            
            // DOWNLOAD FALLBACK (If sharing is not available or failed)
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            
            alert("Tu dispositivo no soporta compartir imágenes directamente. La imagen se descargó y el link se copió al portapapeles para que puedas subirla.");
            navigator.clipboard.writeText(text);
            setSharingProduct(null);
          }
        } catch (err) {
          console.error("Capture or download failed:", err);
          throw err;
        }
      } else {
        // Fallback to text if shareCardRef missing
        if (navigator.share) {
          await navigator.share({
            title: `Minami Sushi Bar`,
            text: text,
            url: storeUrl
          });
          setSharingProduct(null);
        }
      }
    } catch (err) {
      if (err instanceof Error && err.name !== 'AbortError') {
        console.error('Final share fallback error:', err);
        navigator.clipboard.writeText(text);
        alert("Ocurrió un error al generar la tarjeta. Se copió el link informativo al portapapeles.");
      }
    } finally {
      setIsCapturing(false);
    }
  };

  const addToCart = (product: typeof products[0]) => {
    if (product.isOutOfStock) return;
    setCart(prev => {
      const exists = prev.find(item => item.product.id === product.id);
      if (exists) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
    // If added from modal, we might want to close it or keep it open.
    // Let's close it and open cart.
    setSelectedProduct(null);
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === id) {
        return { ...item, quantity: Math.max(0, item.quantity + delta) };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const subTotal = cart.reduce((acc, item) => {
    const price = item.product.isOffer && item.product.offerPrice ? item.product.offerPrice : item.product.price;
    return acc + (price * item.quantity);
  }, 0);
  
  let discount = 0;
  const fidelityFreq = storeSettings?.fidelityFrequency ? storeSettings.fidelityFrequency : 3;
  const fidelityThreshold = storeSettings?.fidelityThreshold !== undefined ? storeSettings.fidelityThreshold : 20000;
  const fidelityPercent = storeSettings?.fidelityDiscount !== undefined ? storeSettings.fidelityDiscount : 15;
  
  const isAtFidelityFreq = purchaseCount > 0 && purchaseCount % fidelityFreq === 0;
  const isFidelityMilestone = isAtFidelityFreq && subTotal >= fidelityThreshold;

  if (isFidelityMilestone) {
    discount = Math.round(subTotal * (fidelityPercent / 100));
  } else if (appliedCoupon && (!appliedCoupon.minAmount || subTotal >= appliedCoupon.minAmount)) {
    if (appliedCoupon.type === 'percentage') discount = Math.round(subTotal * (appliedCoupon.value / 100));
    else discount = appliedCoupon.value;
  }
  
  const deliveryCost = orderMethod === 'delivery' ? (deliveryZones.find(z => z.name === deliveryZone)?.price || 0) : 0;
  const totalAmount = Math.max(0, subTotal - discount) + deliveryCost;
  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const removeAccents = (str: string) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const filteredProducts = products.filter(p => {
    if (!p || !p.name) return false;
    
    const searchLower = removeAccents(searchQuery.toLowerCase());
    const matchName = removeAccents(String(p.name).toLowerCase()).includes(searchLower);
    const matchDesc = p.desc ? removeAccents(String(p.desc).toLowerCase()).includes(searchLower) : false;
    const matchTags = p.tags ? removeAccents(p.tags.join(' ').toLowerCase()).includes(searchLower) : false;
    const searchMatch = !searchQuery || matchName || matchDesc || matchTags;

    // If searching, ignore category filter to allow global search as requested
    if (searchQuery.trim() !== '') {
      return searchMatch;
    }

    const matchesCategory = activeCategory === 'all' || p.category === activeCategory || (activeCategory === 'combinados' && p.category === 'promos');
    return matchesCategory;
  });

  const generateWhatsAppLink = () => {
    if (!name.trim()) {
      alert("Por favor ingresá tu nombre completo.");
      return null;
    }
    if (!phone.trim()) {
      alert("Por favor ingresá tu teléfono.");
      return null;
    }
    if (orderMethod === 'delivery' && !address.trim()) {
      alert("Por favor ingresá tu dirección exacta de entrega.");
      return null;
    }

    let message = `*NUEVO PEDIDO - MINAMI SUSHI BAR*\n\n`;
    message += `*Nombre:* ${name}\n`;
    message += `*Teléfono:* ${phone}\n`;
    message += `*Método:* ${orderMethod === 'delivery' ? 'Delivery' : 'Retiro por local'}\n`;
    if (orderMethod === 'delivery') {
      message += `*Dirección:* ${address}\n`;
      message += `*Zona:* ${deliveryZones.find(z => z.name === deliveryZone)?.name}\n`;
    }
    
    const paymentMap = {
      'efectivo': 'Efectivo',
      'transferencia': 'Transferencia Bancaria',
      'mercadopago': 'MercadoPago / Tarjeta'
    };
    message += `*Pago:* ${paymentMap[paymentMethod]}\n\n`;
    message += `*Detalle de la compra:*\n`;
    
    cart.forEach(item => {
      const price = item.product.isOffer && item.product.offerPrice ? item.product.offerPrice : item.product.price;
      message += `- ${item.quantity}x ${item.product.name} _($${(price * item.quantity).toLocaleString()})_\n`;
    });
    
    message += `\n*Subtotal:* $${subTotal.toLocaleString()}\n`;
    if (discount > 0) {
      if (isFidelityMilestone) message += `🔥 *RECOMPENSA DE FIDELIDAD (${fidelityPercent}% OFF):* -$${discount.toLocaleString()} 🔥\n`;
      else message += `🎟️ *Cupón (${appliedCoupon?.code}):* -$${discount.toLocaleString()}\n`;
    }
    if (orderMethod === 'delivery') {
      message += `🛵 *Costo Envío:* $${deliveryCost.toLocaleString()}\n`;
    }
    
    message += `\n*TOTAL FINAL: $${totalAmount.toLocaleString()}*`;
    
    if (subTotal >= fidelityThreshold) {
      message += `\n\n_💡 ¡Recordá que siguiendo con nosotros durante el mes sumás beneficios! Cada ${fidelityFreq} compras tenés un ${fidelityPercent}% de descuento automático${fidelityThreshold > 0 ? ` en pedidos mayores a $${fidelityThreshold.toLocaleString()}` : ''}._`;
    } else {
      message += `\n\n_💡 ¡Haciendo una compra mayor a $${fidelityThreshold.toLocaleString()} sumás puntos para obtener un ${fidelityPercent}% de descuento automático en tu próxima meta de fidelidad!_`;
    }

    return `https://wa.me/5492926547663?text=${encodeURIComponent(message)}`;
  };

  const handleWhatsAppClick = async () => {
    const link = generateWhatsAppLink();
    if (!link || isSubmitting) return;
    
    setIsSubmitting(true);
    try {
      const { setDoc, doc, increment, addDoc, collection, serverTimestamp } = await import('firebase/firestore');
      
      // Save order to Firestore so admin can print it
      const orderData = {
        name,
        phone,
        method: orderMethod,
        address: orderMethod === 'delivery' ? address : null,
        zone: orderMethod === 'delivery' ? deliveryZone : null,
        paymentMethod,
        coupon: appliedCoupon ? appliedCoupon.code : (isFidelityMilestone ? 'FIDELITY' : null),
        discount,
        items: cart.map(item => ({
          id: item.product.id,
          name: item.product.name,
          category: item.product.category,
          price: item.product.isOffer && item.product.offerPrice ? item.product.offerPrice : item.product.price,
          quantity: item.quantity,
          pieces: item.product.pieces,
          comboContents: item.product.comboContents || ''
        })),
        subTotal,
        deliveryCost,
        totalAmount,
        status: 'new',
        createdAt: serverTimestamp()
      };
      
      // 1. Save order FIRST. If this fails, we stop.
      const orderRef = await addDoc(collection(db, 'orders'), orderData);
      
      if (!orderRef.id) {
        throw new Error("No se pudo generar el ID del pedido.");
      }

      // Update local tracking
      const cleanPhone = phone.replace(/\D/g, '');
      let newPurchases = purchaseCount;
      
      if (subTotal >= fidelityThreshold) {
        newPurchases = purchaseCount + 1;
        setPurchaseCount(newPurchases);
        localStorage.setItem('minami_user_data', JSON.stringify({ name, phone, address, purchases: newPurchases }));
      }

      // If Mercado Pago, create preference and redirect
      if (paymentMethod === 'mercadopago') {
        try {
          const res = await fetch('/api/mercadopago/preference', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              orderId: orderRef.id,
              payer: { name, phone }
            })
          });

          const text = await res.text();
          let data;
          try {
            data = JSON.parse(text);
          } catch (e) {
             throw new Error(`El servidor no respondió correctamente. Refresque la página o vuelva a Compartir la app. (Devolvió HTML en lugar de JSON).`);
          }
          
          if (!res.ok) throw new Error(data?.error || 'Error al generar preferencia MP');
          
          if (data.init_point) {
            // Guardar link de whatsapp pending
            localStorage.setItem('minami_pending_mp', JSON.stringify({ waLink: link }));
            window.location.href = data.init_point;
            return;
          }
        } catch (mpError: any) {
          console.error("MP Error:", mpError);
          alert(`Error Mercado Pago: ${mpError.message}\nPodés confirmar tu pedido igual por WhatsApp y arreglar el pago con el local.`);
          // Fallback down
        }
      }

      // All good! Success feedback
      setCart([]);
      setIsCartOpen(false);
      
      // Open WhatsApp
      window.open(link, '_blank');
      
      if (subTotal >= fidelityThreshold) {
        alert(`¡Pedido registrado con éxito! Serás redirigido a WhatsApp para coordinar el pago y entrega.\n\nPróxima meta de fidelidad: Compra ${newPurchases % fidelityFreq || fidelityFreq}/${fidelityFreq}`);
      } else {
        alert(`¡Pedido registrado con éxito! Serás redirigido a WhatsApp.\n\nNota: Esta compra no sumó para la meta de fidelidad por ser menor a $${fidelityThreshold.toLocaleString()}.`);
      }
    } catch (e) {
      console.error("Error saving order: ", e);
      handleFirestoreError(e, OperationType.CREATE, 'orders');
      alert("Hubo un error al registrar tu pedido en nuestro sistema. Por favor revisá tu conexión e intentá de nuevo. Si el problema persiste, contactanos por WhatsApp.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-brand-gray-light flex flex-col items-center justify-center gap-4">
        <div className="relative w-20 h-20">
          <div className="absolute inset-0 border-4 border-brand-orange/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
        </div>
        <p className="text-brand-black font-display font-bold animate-pulse uppercase tracking-widest text-xs">Cargando Menú...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-gray-light font-sans text-brand-black pb-24">
      {/* Navigation */}
      <nav className="bg-brand-black text-white py-4 px-4 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
            <motion.a 
              href="/" 
              whileHover={{ x: -2 }}
              className="flex items-center gap-2 hover:text-brand-orange transition-colors"
            >
              <ChevronLeft size={20} />
              <span className="font-medium text-sm">Volver al inicio</span>
            </motion.a>
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-xl uppercase tracking-widest hidden sm:block">Delivery & Pick Up</span>
          </div>
          <motion.button 
            onClick={() => setIsCartOpen(true)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 bg-brand-orange px-4 py-2 rounded-full hover:bg-brand-orange-dark transition-colors relative shadow-lg shadow-brand-orange/20"
          >
            <ShoppingBag size={18} />
            <span className="text-sm font-bold">${totalAmount.toLocaleString()}</span>
            {totalItems > 0 && (
              <motion.span 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 bg-white text-brand-orange text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-md"
              >
                {totalItems}
              </motion.span>
            )}
          </motion.button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 pt-10">
        {!storeOpen && (
          <div className="bg-red-50 text-red-600 p-6 rounded-2xl mb-8 border border-red-200 shadow-sm flex flex-col md:flex-row items-center gap-4 justify-center text-center md:text-left">
            <Info size={32} className="shrink-0" />
            <div>
              <h3 className="font-bold text-lg mb-1">Cerrado por el momento / Sin reservas disponibles</h3>
              <p className="text-sm opacity-90 mb-1">De momento no estamos tomando nuevos pedidos. Te esperamos para el próximo.</p>
              {storeSettings?.storeSchedule && Array.isArray(storeSettings.storeSchedule) && storeSettings.storeSchedule.length > 0 && (
                <div className="flex flex-wrap justify-center md:justify-start gap-x-4 gap-y-1 mt-2 border-t border-red-100 pt-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider block w-full text-center md:text-left mb-1 opacity-70">Nuestros Horarios para tomar reservas:</span>
                  {storeSettings.storeSchedule.map((s: any, i: number) => (
                    <div key={i} className="text-xs bg-red-100 px-2 py-0.5 rounded-md">
                      <span className="font-bold">{s.days}:</span> {s.hours}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">Armá tu pedido</h1>
        <p className="text-gray-500 mb-8 max-w-2xl">
          Elegí los rolls de nuestro menú y te los llevamos a tu casa o pasalos a retirarlos por Las Heras 323.
        </p>

        {/* Carousel Slider */}
        {sliderProducts.length > 0 && (
          <div className="relative w-full h-[300px] md:h-[400px] rounded-3xl overflow-hidden mb-12 shadow-2xl group cursor-pointer" onClick={() => setSelectedProduct(sliderProducts[currentSlide])}>
             <AnimatePresence initial={false}>
                <motion.div 
                  key={currentSlide}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8 }}
                  className="absolute inset-0"
                >
                  {sliderProducts[currentSlide]?.img ? (
                    <img 
                      src={getDirectImageUrl(sliderProducts[currentSlide].img)} 
                      alt="Slider" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-200 flex items-center justify-center"><ShoppingBag size={64} className="text-gray-300"/></div>
                  )}
                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-8 md:p-12">
                   {sliderProducts[currentSlide]?.isOffer && (
                      <span className="bg-red-600 text-white font-bold text-xs px-3 py-1 uppercase rounded-sm w-fit mb-3">En Oferta</span>
                   )}
                   <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-2 shadow-sm drop-shadow-md tracking-wide">{sliderProducts[currentSlide]?.name}</h2>
                   <p className="text-gray-200 mb-4 max-w-xl text-sm md:text-base line-clamp-2">{sliderProducts[currentSlide]?.desc}</p>
                   <button className="bg-brand-orange hover:bg-orange-500 text-white font-bold px-6 py-3 rounded-full w-fit flex items-center gap-2 transition-transform transform active:scale-95 shadow-lg">Ver Detalles <ChevronLeft className="rotate-180" size={16}/></button>
                 </div>
               </motion.div>
             </AnimatePresence>
             
             {/* Indicators */}
             <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
               {sliderProducts.map((_, i) => (
                  <button 
                    key={i} 
                    onClick={(e) => { e.stopPropagation(); setCurrentSlide(i); }}
                    className={`h-2 rounded-full transition-all ${i === currentSlide ? 'w-8 bg-brand-orange' : 'w-2 bg-white/50 hover:bg-white/80'}`}
                  />
               ))}
             </div>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="text"
              placeholder="Buscar por nombre, ingrediente (ej: palta, salmon)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-xl pl-12 pr-4 py-3 focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-2 mb-10 overflow-x-auto pb-2 scrollbar-none">
          {[
            { id: 'all', label: 'Todos' },
            { id: 'rolls', label: 'Rolls' },
            { id: 'combinados', label: 'Combinados' },
            { id: 'picoteo', label: 'Picoteo' },
            { id: 'salsas', label: 'Salsas' },
            { id: 'extras', label: 'Extras' }
          ].map(cat => (
            <motion.button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-5 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors border ${
                activeCategory === cat.id 
                  ? 'bg-brand-black text-white border-brand-black shadow-md' 
                  : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
              }`}
            >
              {cat.label}
            </motion.button>
          ))}
        </div>

        {/* Products Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {filteredProducts.map((product, idx) => (
            <motion.div 
              key={product.id} 
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              onClick={() => setSelectedProduct(product)}
              whileHover={{ y: -5 }}
              className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 flex flex-col group hover:shadow-xl transition-shadow cursor-pointer relative"
            >
              {product.isFeatured && (
                 <div className="absolute top-2 right-2 bg-brand-orange text-white text-[10px] font-bold px-2 py-1 rounded-sm z-10 shadow-md">DESTACADO</div>
              )}
              <button 
                onClick={(e) => handleShare(product, e)}
                className="absolute top-2 left-2 bg-white/80 hover:bg-white text-brand-black p-2 rounded-full z-30 shadow-sm backdrop-blur-md transition-all hover:scale-110"
                title="Compartir"
              >
                <Share2 size={16} />
              </button>
              {product.isOutOfStock && (
                 <div className="absolute inset-0 bg-white/60 backdrop-blur-[1px] z-20 flex items-center justify-center pointer-events-none">
                    <div className="bg-red-600 text-white font-bold py-1 px-4 rounded transform -rotate-12 shadow-lg">SIN STOCK</div>
                 </div>
              )}
              
              <div className="relative aspect-[4/3] overflow-hidden bg-gray-100 shrink-0">
                 {product.img ? (
                    <img 
                      src={getDirectImageUrl(product.img)} 
                      alt={product.name} 
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                      referrerPolicy="no-referrer"
                    />
                 ) : (
                    <div className="w-full h-full flex justify-center items-center text-gray-300">
                      <ShoppingBag size={48} strokeWidth={1} />
                    </div>
                 )}
                 {product.isOffer && (
                    <div className="absolute bottom-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded shadow-sm flex items-center gap-1">
                      En Promo
                    </div>
                 )}
              </div>
              <div className="p-5 flex flex-col flex-1">
                <div className="flex justify-between items-start mb-2 gap-2">
                  <h3 className="font-display font-bold text-lg leading-tight group-hover:text-brand-orange transition-colors">{product.name}</h3>
                  {product.pieces && <span className="text-xs bg-gray-100 text-gray-600 font-bold px-2 py-1 rounded shrink-0">{product.pieces}</span>}
                </div>
                {product.subCategories && product.subCategories.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {product.subCategories.map((sc: string, i: number) => (
                      <span key={i} className="text-[10px] font-bold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded-full">{sc}</span>
                    ))}
                  </div>
                )}
                {product.tags && product.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {product.tags.map((tag: string, i: number) => {
                      const tagDef = availableTags.find(t => t.name.toLowerCase() === tag.toLowerCase()) || { icon: '', name: tag };
                      return (
                        <span key={i} className="text-[10px] bg-orange-50 text-brand-orange px-1.5 py-0.5 rounded font-bold border border-orange-100 flex items-center gap-1">
                          {tagDef.icon} {tagDef.name.toUpperCase()}
                        </span>
                      );
                    })}
                  </div>
                )}
                {product.desc && (
                  <p className="text-xs text-gray-500 mb-4 line-clamp-2 flex-1">{product.desc}</p>
                )}
                <div className="flex items-center justify-between mt-auto z-30">
                  <div className="flex flex-col">
                    {product.isOffer && product.offerPrice ? (
                      <>
                        <span className="text-xs text-gray-400 line-through">${product.price.toLocaleString()}</span>
                        <span className="font-bold text-lg text-green-600">${product.offerPrice.toLocaleString()}</span>
                      </>
                    ) : (
                      <span className="font-bold text-lg text-brand-orange">${product.price.toLocaleString()}</span>
                    )}
                  </div>
                  <motion.button 
                    whileHover={{ scale: 1.1, backgroundColor: "#000", color: "#fff" }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (storeOpen && !product.isOutOfStock) addToCart(product);
                    }}
                    className={`${!storeOpen || product.isOutOfStock ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-gray-100 text-brand-black'} transition-colors w-10 h-10 rounded-full flex items-center justify-center shadow-sm`}
                    title={!storeOpen ? "Tienda cerrada" : (product.isOutOfStock ? "Sin Stock" : "Agregar")}
                  >
                    <Plus size={20} />
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </main>

      {/* Shopping Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-brand-black/40 backdrop-blur-sm z-50"
            />
            <motion.div 
              initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'tween', duration: 0.3 }}
              className="fixed inset-y-0 right-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-brand-black text-white">
                <h2 className="font-display font-bold text-xl flex items-center gap-2">
                  <ShoppingBag size={20} /> Tu Pedido
                </h2>
                <button onClick={() => setIsCartOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
                {cart.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-gray-400 gap-4">
                    <ShoppingBag size={48} strokeWidth={1} />
                    <p>Tu carrito está vacío</p>
                  </div>
                ) : (
                  <>
                    <div className="space-y-4">
                      {cart.map(item => (
                        <div key={item.product.id} className="flex gap-4 items-center">
                          <img 
                            src={getDirectImageUrl(item.product.img)} 
                            alt={item.product.name} 
                            className="w-16 h-16 rounded-xl object-cover" 
                            referrerPolicy="no-referrer" 
                          />
                          <div className="flex-1">
                            <h4 className="font-bold text-sm leading-tight">{item.product.name}</h4>
                            <p className="text-brand-orange text-sm font-semibold">
                              ${(item.product.isOffer && item.product.offerPrice ? item.product.offerPrice : item.product.price).toLocaleString()}
                            </p>
                          </div>
                          <div className="flex items-center gap-3 bg-gray-100 rounded-full px-2 py-1">
                            <button onClick={() => updateQuantity(item.product.id, -1)} className="w-6 h-6 flex items-center justify-center text-gray-600 hover:bg-white rounded-full transition-colors"><Minus size={14} /></button>
                            <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.product.id, 1)} className="w-6 h-6 flex items-center justify-center text-gray-600 hover:bg-white rounded-full transition-colors"><Plus size={14} /></button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <hr className="border-gray-100" />
                    
                    {/* Fidelity & Coupons */}
                    <div className="bg-gray-100 p-4 rounded-xl border border-gray-200">
                      {isAtFidelityFreq && subTotal < fidelityThreshold && (
                        <div className="mb-3 bg-orange-50 p-3 rounded-lg border border-orange-200">
                           <p className="text-[11px] text-orange-700 font-medium leading-tight">
                            ⚠️ ¡Llegaste a tu meta de fidelidad! Pero esta vez el descuento del {fidelityPercent}% solo se aplica en pedidos mayores a ${fidelityThreshold.toLocaleString()}.
                          </p>
                        </div>
                      )}

                      {isFidelityMilestone ? (
                        <div className="flex flex-col gap-2 bg-green-50 p-3 rounded-lg border border-green-200 animate-pulse">
                          <div className="flex items-center gap-2 text-green-700">
                            <Check size={20} className="stroke-[3px]" />
                            <span className="text-sm font-black uppercase tracking-tight">¡RECOMPENSA DE FIDELIDAD ACTIVADA!</span>
                          </div>
                          <p className="text-[11px] text-green-600 font-medium leading-tight">Tenés un {fidelityPercent}% de descuento automático por ser cliente frecuente. ¡Gracias por elegirnos! 🧡</p>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                           <input 
                              type="text" 
                              placeholder="Ingresar Cupón" 
                              value={couponCode} 
                              onChange={(e) => setCouponCode(e.target.value)} 
                              className="flex-1 bg-white border border-gray-300 rounded px-3 py-2 outline-none uppercase text-sm focus:border-brand-orange" 
                           />
                           <button onClick={handleApplyCoupon} className="px-4 py-2 bg-brand-black text-white rounded font-bold text-sm">Aplicar</button>
                        </div>
                      )}
                      
                      {appliedCoupon && !isFidelityMilestone && (
                        <div className="mt-2 text-sm text-green-600 font-bold flex items-center justify-between">
                          <span>Cupón aplicado ({appliedCoupon.code})</span>
                          <button onClick={() => setAppliedCoupon(null)} className="text-gray-500 hover:text-red-500"><X size={16}/></button>
                        </div>
                      )}
                    </div>

                    <hr className="border-gray-100" />

                    {/* Checkout Details */}
                    <div className="space-y-5">
                      <div className="flex justify-between items-center mt-4">
                        <h3 className="font-bold text-sm uppercase tracking-wider text-gray-400">Datos de Entrega</h3>
                        {(name || phone || address) && (
                          <button 
                            onClick={clearCustomerData}
                            className="text-[10px] bg-red-50 text-red-600 px-2 py-1 rounded-md font-black uppercase hover:bg-red-100 transition-colors"
                          >
                            Limpiar / Nuevo Cliente
                          </button>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3 mt-1">
                        <button 
                          onClick={() => setOrderMethod('pickup')}
                          className={`flex flex-col items-center justify-center gap-2 py-3 rounded-xl border-2 transition-colors ${
                            orderMethod === 'pickup' ? 'border-brand-orange text-brand-orange bg-brand-orange/5' : 'border-gray-100 text-gray-400 hover:border-gray-200'
                          }`}
                        >
                          <Building size={24} />
                          <span className="text-xs font-bold">Pick Up</span>
                        </button>
                        <button 
                          onClick={() => setOrderMethod('delivery')}
                          className={`flex flex-col items-center justify-center gap-2 py-3 rounded-xl border-2 transition-colors ${
                            orderMethod === 'delivery' ? 'border-brand-orange text-brand-orange bg-brand-orange/5' : 'border-gray-100 text-gray-400 hover:border-gray-200'
                          }`}
                        >
                          <MapPin size={24} />
                          <span className="text-xs font-bold">Delivery</span>
                        </button>
                      </div>

                      <div className="space-y-3 mt-4">
                        <input type="text" placeholder="Tu Nombre completo *" value={name} onChange={e => setName(e.target.value)} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all" />
                        <input type="tel" placeholder="Tu Teléfono *" value={phone} onChange={e => setPhone(e.target.value)} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all" />
                        
                        {orderMethod === 'delivery' && (
                          <>
                            <div className="flex flex-col gap-1">
                              <label className="text-xs font-bold text-gray-500 ml-1">Zona de envío *</label>
                              <select 
                                value={deliveryZone} 
                                onChange={e => setDeliveryZone(e.target.value)}
                                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all bg-white"
                              >
                                {deliveryZones.map(z => (
                                  <option key={z.id} value={z.id}>{z.name} (+${z.price})</option>
                                ))}
                              </select>
                            </div>
                            <input type="text" placeholder="Dirección exacta de entrega *" value={address} onChange={e => setAddress(e.target.value)} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all" />
                          </>
                        )}
                      </div>

                      <h3 className="font-bold text-sm uppercase tracking-wider text-gray-400 mt-6">Forma de Pago</h3>
                      <div className="grid grid-cols-3 gap-2">
                         <button onClick={() => setPaymentMethod('efectivo')} className={`flex flex-col items-center gap-1 py-2 rounded-xl border transition-colors ${paymentMethod === 'efectivo' ? 'bg-brand-black text-white border-brand-black' : 'border-gray-200 text-gray-500'}`}>
                           <Banknote size={18} /> <span className="text-[10px] font-bold uppercase">Efectivo</span>
                         </button>
                         <button onClick={() => { setPaymentMethod('transferencia'); setShowTransferModal(true); }} className={`flex flex-col items-center gap-1 py-2 rounded-xl border transition-colors ${paymentMethod === 'transferencia' ? 'bg-brand-black text-white border-brand-black' : 'border-gray-200 text-gray-500'}`}>
                           <CreditCard size={18} /> <span className="text-[10px] font-bold uppercase">Transf.</span>
                         </button>
                         <button onClick={() => setPaymentMethod('mercadopago')} className={`flex flex-col items-center gap-1 py-2 rounded-xl border transition-colors ${paymentMethod === 'mercadopago' ? 'bg-[#009EE3] text-white border-[#009EE3]' : 'border-gray-200 text-gray-500'}`}>
                           <Smartphone size={18} /> <span className="text-[10px] font-bold uppercase">App / MP</span>
                         </button>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 bg-gray-50 border-t border-gray-200 space-y-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-sm text-gray-500">
                      <span>Subtotal:</span>
                      <span>${subTotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between items-center text-sm font-bold text-green-600">
                        <span>{isFidelityMilestone ? 'Descuento Fidelidad:' : `Cupón ${appliedCoupon?.code}:`}</span>
                        <span>-${discount.toLocaleString()}</span>
                      </div>
                    )}
                    {orderMethod === 'delivery' && deliveryCost > 0 && (
                      <div className="flex justify-between items-center text-sm text-gray-500">
                        <span>Envío:</span>
                        <span>${deliveryCost.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center text-lg mt-2 pt-2 border-t border-gray-200">
                      <span className="font-bold text-brand-black">Total:</span>
                      <span className="font-bold text-brand-orange text-2xl">${totalAmount.toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <motion.button 
                    onClick={handleWhatsAppClick}
                    disabled={!storeOpen || subTotal < minPurchase || isSubmitting}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`w-full py-4 rounded-xl flex items-center justify-center gap-2 font-bold uppercase tracking-wide transition-all ${
                      storeOpen && subTotal >= minPurchase && !isSubmitting
                        ? 'bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-lg shadow-green-500/20' 
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {isSubmitting ? (
                      <>
                        <motion.div 
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                          className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                        />
                        <span>{paymentMethod === 'mercadopago' ? 'Generando pago...' : 'Registrando pedido...'}</span>
                      </>
                    ) : (
                      !storeOpen ? 'Tienda Cerrada' : (subTotal < minPurchase ? `Compra mínima: $${minPurchase.toLocaleString()}` : (paymentMethod === 'mercadopago' ? 'Pagar con Mercado Pago' : 'Confirmar por WhatsApp'))
                    )}
                  </motion.button>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="w-full py-3 rounded-xl flex items-center justify-center font-bold uppercase tracking-wide transition-colors bg-gray-100 text-brand-black hover:bg-gray-200"
                  >
                    Seguir Agregando Productos
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="fixed -left-[3000px] top-0 pointer-events-none" aria-hidden="true" style={{ width: '600px' }}>
        {sharingProduct && (
          <div 
            ref={shareCardRef}
            className="w-[600px] bg-white flex flex-col p-10 font-sans"
          >
            {/* Logo/Header - Matches user screenshot */}
            <div className="flex items-center gap-4 mb-10">
              <img src="/logo.png" className="w-16 h-16 object-contain" />
              <div className="flex flex-col">
                <span className="font-display font-black text-brand-black text-2xl tracking-tighter leading-none">MINAMI SUSHI</span>
                <span className="text-gray-300 font-bold text-[10px] uppercase tracking-widest mt-1">Sushi & Bar - Premium Experience</span>
              </div>
            </div>

            {/* Main Product Image - Centered and Clean */}
            <div className="relative aspect-square overflow-hidden rounded-[40px] mb-10 shadow-2xl border-4 border-gray-50">
              {sharingProduct.img ? (
                <img 
                  src={getDirectImageUrl(sharingProduct.img)} 
                  className="w-full h-full object-cover" 
                  crossOrigin="anonymous" 
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-gray-50 flex items-center justify-center text-gray-200">
                  <ShoppingBag size={180} strokeWidth={1} />
                </div>
              )}
            </div>
            
            <div className="px-2">
              {/* Title and Pieces Unit */}
              <div className="flex justify-between items-center gap-4 mb-6">
                <h3 className="font-display font-black text-6xl leading-tight text-brand-black tracking-tighter">{sharingProduct.name}</h3>
                {sharingProduct.pieces && (
                  <span className="bg-brand-black text-white font-black px-8 py-3 rounded-full text-xl whitespace-nowrap shadow-xl">
                    {sharingProduct.pieces}
                  </span>
                )}
              </div>

              {/* Tags Section */}
              <div className="flex flex-wrap gap-3 mb-8">
                {(sharingProduct.tags || []).map((tag: string, i: number) => {
                  const tagDef = availableTags.find(t => t.name.toLowerCase() === tag.toLowerCase()) || { icon: '🍣', name: tag };
                  return (
                    <span key={i} className="text-sm bg-gray-100 text-brand-black px-6 py-3 rounded-2xl font-black border border-gray-200 uppercase flex items-center gap-2">
                      {tagDef.icon} {tagDef.name}
                    </span>
                  );
                })}
              </div>

              {/* Description - Quoted and Styled */}
              <p className="text-gray-400 text-2xl mb-12 leading-relaxed italic font-medium max-w-lg">
                "{sharingProduct.desc || 'La mejor experiencia de sushi premium en la ciudad.'}"
              </p>

              {/* Footer: Price and Link */}
              <div className="mt-auto pt-10 border-t-2 border-gray-50 flex items-end justify-between">
                <div className="flex flex-col">
                  {sharingProduct.isOffer && sharingProduct.offerPrice ? (
                    <>
                      <span className="text-xl text-gray-300 line-through font-bold mb-1">${sharingProduct.price.toLocaleString()}</span>
                      <span className="font-black text-7xl text-green-600 tracking-tighter">${sharingProduct.offerPrice.toLocaleString()}</span>
                    </>
                  ) : (
                    <span className="font-black text-7xl text-brand-orange tracking-tighter">${sharingProduct.price.toLocaleString()}</span>
                  )}
                  <span className="text-brand-orange font-black text-sm uppercase tracking-widest mt-2">{sharingProduct.name} en Minami Sushi Bar</span>
                </div>
                
                <div className="flex flex-col items-end text-right pb-2">
                  <span className="text-xs font-black text-gray-300 uppercase tracking-widest mb-3">PEDÍ ONLINE EN:</span>
                  <div className="bg-brand-black text-white px-6 py-3 rounded-2xl shadow-xl font-bold text-sm tracking-tight border border-gray-800">
                    minamisushi.com.ar
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Sharing Modal */}
      <AnimatePresence>
        {sharingProduct && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-brand-black/90 backdrop-blur-md z-[150] flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setSharingProduct(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-[40px] w-full max-w-sm overflow-hidden shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              {isCapturing && (
                <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center gap-4">
                  <div className="w-12 h-12 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
                  <p className="font-bold text-brand-black">Generando tarjeta visual...</p>
                </div>
              )}
              
              <div className="p-6 text-center">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-brand-gray-light rounded-full text-[10px] font-black uppercase tracking-widest text-gray-500 mb-4">
                  Compartir Producto
                </div>
                
                <h3 className="font-display font-black text-2xl text-brand-black mb-6">
                  {sharingProduct.name}
                </h3>

                {/* Preview area */}
                <div className="relative aspect-square rounded-[32px] overflow-hidden mb-8 border-4 border-brand-gray-light shadow-inner">
                   {sharingProduct.img ? (
                     <img 
                       src={getDirectImageUrl(sharingProduct.img)} 
                       className="w-full h-full object-cover" 
                       key={sharingProduct.id} 
                       referrerPolicy="no-referrer" 
                     />
                   ) : (
                     <div className="w-full h-full bg-gray-100 flex items-center justify-center text-gray-300">
                       <ShoppingBag size={64} />
                     </div>
                   )}
                   <div className="absolute inset-0 bg-gradient-to-t from-brand-black/60 via-transparent to-transparent"></div>
                   <div className="absolute bottom-4 left-4 right-4 text-left">
                     <div className="flex items-center gap-2 mb-1">
                        <img src="/logo.png" className="w-6 h-6 object-contain" />
                        <span className="text-white font-black text-[10px] uppercase tracking-tighter">Minami Sushi Bar</span>
                     </div>
                     <p className="text-white/80 text-[10px] line-clamp-1 italic">{sharingProduct.desc}</p>
                   </div>
                </div>

                <div className="space-y-4">
                  {/* WhatsApp Context Option */}
                  <button 
                    onClick={() => executeShare(sharingProduct, 'text')}
                    disabled={isCapturing}
                    className="w-full py-4 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-3xl font-black text-base transition-all shadow-lg flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
                  >
                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.067 2.877 1.215 3.076.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                    WhatsApp (Texto y Link)
                  </button>

                  <div className="flex items-center gap-3 py-2">
                    <div className="h-px bg-gray-100 flex-1"></div>
                    <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">ó compartí visualmente</span>
                    <div className="h-px bg-gray-100 flex-1"></div>
                  </div>

                  <button 
                    onClick={() => executeShare(sharingProduct, 'image')}
                    disabled={isCapturing}
                    className="w-full py-4 bg-brand-black hover:bg-gray-900 text-white rounded-3xl font-black text-base transition-all shadow-xl flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
                  >
                    <Instagram className="w-5 h-5 text-pink-500" />
                    Compartir en Instagram
                  </button>

                  <button 
                    onClick={() => executeShare(sharingProduct, 'image')}
                    disabled={isCapturing}
                    className="w-full py-4 bg-gray-100 hover:bg-gray-200 text-brand-black rounded-3xl font-bold text-sm transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
                  >
                    <ImageIcon className="w-4 h-4 text-gray-400" />
                    Descargar Tarjeta Visual
                  </button>

                  <button 
                    onClick={() => setSharingProduct(null)}
                    className="text-gray-400 hover:text-brand-black font-bold text-xs uppercase tracking-widest transition-colors pt-2"
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {selectedProduct && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-brand-black/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4"
            onClick={() => setSelectedProduct(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="relative h-64 sm:h-80 bg-gray-100 shrink-0">
                {selectedProduct.img ? (
                  <img 
                    src={getDirectImageUrl(selectedProduct.img)} 
                    alt={selectedProduct.name} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer" 
                  />
                ) : (
                  <div className="w-full h-full flex justify-center items-center text-gray-300">
                     <ShoppingBag size={64} strokeWidth={1} />
                  </div>
                )}
                
                <button 
                  onClick={() => setSelectedProduct(null)}
                  className="absolute top-4 right-4 bg-brand-black/50 hover:bg-brand-black text-white w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-colors z-10"
                >
                  <X size={20} />
                </button>

                <button 
                  onClick={() => handleShare(selectedProduct)}
                  className="absolute top-4 left-4 bg-white/80 hover:bg-white text-brand-black w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all hover:scale-110 z-10 shadow-lg"
                  title="Compartir"
                >
                  <Share2 size={18} />
                </button>
                
                {selectedProduct.isFeatured && (
                  <div className="absolute top-4 left-4 bg-brand-orange text-white text-xs font-bold px-3 py-1.5 rounded shadow-lg flex items-center gap-1">
                    DESTACADO
                  </div>
                )}
              </div>
              
              <div className="p-6 overflow-y-auto">
                <div className="flex justify-between items-start gap-4 mb-2">
                  <h2 className="text-2xl font-display font-bold leading-tight">{selectedProduct.name}</h2>
                  {selectedProduct.pieces && <span className="text-sm bg-gray-100 text-gray-600 font-bold px-3 py-1.5 rounded shrink-0">{selectedProduct.pieces}</span>}
                </div>
                {selectedProduct.subCategories && selectedProduct.subCategories.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedProduct.subCategories.map((sc: string, i: number) => (
                      <span key={i} className="text-sm font-bold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">{sc}</span>
                    ))}
                  </div>
                )}
                
                {selectedProduct.tags && selectedProduct.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedProduct.tags.map((tag: string, i: number) => {
                      const tagDef = availableTags.find(t => t.name.toLowerCase() === tag.toLowerCase()) || { icon: '', name: tag };
                      return (
                        <span key={i} className="text-xs bg-orange-50 text-brand-orange px-2 py-1 rounded font-bold border border-orange-100 flex items-center gap-1">
                          {tagDef.icon} {tagDef.name.toUpperCase()}
                        </span>
                      );
                    })}
                  </div>
                )}
                
                <div className="flex-grow">
                  <p className="text-gray-600 leading-relaxed mb-4">{selectedProduct.desc || 'Sin descripción.'}</p>
                  
                  {selectedProduct.category === 'combinados' && Array.isArray(selectedProduct.comboVarieties) && selectedProduct.comboVarieties.length > 0 && (
                    <div className="bg-orange-50/50 rounded-2xl p-5 border border-orange-100/30 mb-8">
                      <h4 className="text-[10px] font-black text-brand-orange uppercase tracking-widest mb-3 flex items-center gap-2">
                        <CheckCircle2 size={12} className="stroke-[3]" /> Variedades Incluidas:
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                        {selectedProduct.comboVarieties.map((vId: string) => {
                          const vDoc = products.find(p => p.id === vId);
                          return vDoc ? (
                            <button 
                              key={vId} 
                              onClick={() => setSelectedVariety(vDoc)}
                              className="flex items-center gap-2 text-xs text-gray-700 font-medium hover:text-brand-orange text-left transition-colors group"
                            >
                              <div className="w-1.5 h-1.5 rounded-full bg-brand-orange/40 group-hover:bg-brand-orange transition-colors shrink-0" />
                              <span className="truncate">{vDoc.name}</span>
                            </button>
                          ) : null;
                        })}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center justify-between border-t border-gray-100 pt-6">
                  <div className="flex flex-col">
                    <span className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-1">Precio</span>
                    {selectedProduct.isOffer && selectedProduct.offerPrice ? (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-400 line-through">${selectedProduct.price.toLocaleString()}</span>
                        <span className="font-bold text-3xl text-green-600">${selectedProduct.offerPrice.toLocaleString()}</span>
                      </div>
                    ) : (
                      <span className="font-bold text-3xl text-brand-orange">${selectedProduct.price.toLocaleString()}</span>
                    )}
                  </div>
                  
                  <button 
                    onClick={() => {
                        if (storeOpen && !selectedProduct.isOutOfStock) addToCart(selectedProduct);
                    }}
                    disabled={!storeOpen || selectedProduct.isOutOfStock}
                    className={`px-8 py-3.5 rounded-xl font-bold uppercase tracking-wide transition-all shadow-[0_4px_14px_0_rgba(255,107,0,0.39)] ${!storeOpen || selectedProduct.isOutOfStock ? 'bg-gray-200 text-gray-400 shadow-none cursor-not-allowed' : 'bg-brand-orange hover:bg-brand-orange-dark hover:scale-105 text-white'}`}
                  >
                    {!storeOpen ? 'Cerrado' : (selectedProduct.isOutOfStock ? 'Sin stock' : 'Agregar')}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Variety Details Modal */}
      <AnimatePresence>
        {selectedVariety && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-brand-black/80 backdrop-blur-md z-[120] flex items-center justify-center p-4"
            onClick={() => setSelectedVariety(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="relative h-64 bg-gray-100 shrink-0">
                {selectedVariety.img ? (
                  <img 
                    src={getDirectImageUrl(selectedVariety.img)} 
                    alt={selectedVariety.name} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer" 
                  />
                ) : (
                  <div className="w-full h-full flex justify-center items-center text-gray-300">
                     <ImageIcon size={64} strokeWidth={1} />
                  </div>
                )}
                
                <button 
                  onClick={() => setSelectedVariety(null)}
                  className="absolute top-4 right-4 bg-brand-black/50 hover:bg-brand-black text-white w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-colors z-10"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-6">
                <h2 className="text-2xl font-display font-bold leading-tight mb-4">{selectedVariety.name}</h2>
                <p className="text-gray-600 leading-relaxed text-sm mb-6">{selectedVariety.desc || 'Sin descripción.'}</p>
                <div className="flex gap-4">
                  <button 
                    onClick={() => setSelectedVariety(null)}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold uppercase tracking-wide py-3 rounded-xl transition-colors text-sm"
                  >
                    Volver
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Transfer Details Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 bg-brand-black/50 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl relative">
            <button onClick={() => setShowTransferModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-brand-black z-10 transition-colors">
              <X size={24} />
            </button>
            <div className="p-6">
               <h2 className="text-xl font-bold mb-4 text-brand-black border-b pb-2">Datos para Transferencia</h2>
               <div className="space-y-3 text-sm text-gray-700">
                  <div className="flex justify-between items-center bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <span className="font-semibold text-gray-500">Alias</span>
                    <span className="font-bold text-lg select-all">minamisushi</span>
                  </div>
                  <div className="flex justify-between items-center bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <span className="font-semibold text-gray-500">Titular</span>
                    <span className="font-bold">German Battaglia</span>
                  </div>
                  <div className="flex justify-between items-center bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <span className="font-semibold text-gray-500">DNI</span>
                    <span className="font-bold">24.171.874</span>
                  </div>
                  <div className="flex justify-between items-center bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <span className="font-semibold text-gray-500">Entidad</span>
                    <span className="font-bold text-brand-orange">Naranja X</span>
                  </div>
               </div>
               
               <div className="mt-6 p-4 bg-orange-50 border border-brand-orange/20 rounded-xl text-center">
                 <p className="text-brand-orange font-bold text-sm">⚠️ IMPORTANTE ⚠️</p>
                 <p className="text-gray-600 text-xs mt-1">Una vez realizado el pedido, deberás enviar el comprobante de pago por WhatsApp para confirmar la orden.</p>
               </div>
               
               <button 
                 onClick={() => setShowTransferModal(false)}
                 className="w-full mt-6 bg-brand-black text-white py-3 rounded-xl font-bold uppercase transition-colors"
               >
                 Entendido
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
