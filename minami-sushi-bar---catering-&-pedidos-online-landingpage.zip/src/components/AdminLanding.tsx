import React, { useState, useEffect } from 'react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, onSnapshot, doc, setDoc, deleteDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { Plus, Trash2, Edit2, X, Image as ImageIcon, Check, Loader2, Link as LinkIcon, Save } from 'lucide-react';
import AdminBlog from './AdminBlog';
import { getDirectImageUrl } from '../lib/imageUtils';

type SubTab = 'services' | 'blog' | 'gallery' | 'menu';

export default function AdminLanding() {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('services');
  const [services, setServices] = useState<any[]>([]);
  const [galleryImages, setGalleryImages] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [featuredIds, setFeaturedIds] = useState<string[]>([]);
  const [veggieIds, setVeggieIds] = useState<string[]>([]);
  const [highlightTab, setHighlightTab] = useState<'featured' | 'veggie'>('featured');
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<any>(null);
  const [editingPhoto, setEditingPhoto] = useState<any>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);

  // Gallery Settings
  const [gallerySettings, setGallerySettings] = useState({
    coverImg: '',
    driveLink: ''
  });
  const [isSavingGallery, setIsSavingGallery] = useState(false);

  const [form, setForm] = useState({
    title: '',
    desc: '',
    img: ''
  });

  const [photoForm, setPhotoForm] = useState({
    url: '',
    title: '',
    order: 0
  });

  useEffect(() => {
    const unsubServices = onSnapshot(collection(db, 'landingServices'), (snapshot) => {
      if (snapshot.empty) {
        // Option to auto-seed if admin sees it's empty
        const initialServices = [
          { title: "Casamientos", desc: "Un toque elegante y exótico para la noche más importante de tu vida.", img: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&q=80&w=800" },
          { title: "Eventos Empresariales", desc: "Sorprendé a tus clientes y equipo con una propuesta gastronómica de primer nivel.", img: "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&q=80&w=800" },
          { title: "Cumpleaños y Celebraciones", desc: "Desde cumples de 15 hasta reuniones especiales, nos adaptamos a tu festejo.", img: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?auto=format&fit=crop&q=80&w=800" },
          { title: "Sushi en tu Casa", desc: "Cumpleaños, reuniones o juntadas. Vamos y armamos la mesa de sushi en la comodidad de tu hogar.", img: "https://images.unsplash.com/photo-1617196035154-1e7e6e28ba2d?auto=format&fit=crop&q=80&w=800" }
        ];
        initialServices.forEach((srv, idx) => {
          setDoc(doc(db, 'landingServices', `service_${idx}`), srv);
        });
      }
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setServices(docs);
      if (activeSubTab === 'services') setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'landingServices');
    });

    const unsubGallery = onSnapshot(collection(db, 'landingGallery'), (snapshot) => {
      if (snapshot.empty) {
        const initialGallery = [
          { url: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&q=80&w=800", title: "Catering Exclusivo", order: 0 },
          { url: "https://images.unsplash.com/photo-1579871494447-0811cf80d49d?auto=format&fit=crop&q=80&w=800", title: "Sushi de Autor", order: 1 },
          { url: "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&q=80&w=800", title: "Eventos VIP", order: 2 },
          { url: "https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&q=80&w=800", title: "Presentaciones", order: 3 },
          { url: "https://images.unsplash.com/photo-1563612116625-3012372fcec8?auto=format&fit=crop&q=80&w=800", title: "Momentos Minami", order: 4 }
        ];
        initialGallery.forEach((img, idx) => {
          setDoc(doc(db, 'landingGallery', `photo_${idx}`), img);
        });
      }
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setGalleryImages(docs.sort((a: any, b: any) => (a.order || 0) - (b.order || 0)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'landingGallery');
    });

    const unsubSettings = onSnapshot(doc(db, 'landingSettings', 'gallery'), (docSnap) => {
      if (docSnap.exists()) {
        setGallerySettings(docSnap.data() as any);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'landingSettings/gallery');
    });

    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setProducts(docs.sort((a: any, b: any) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'products'));

    const unsubHighlights = onSnapshot(doc(db, 'landingSettings', 'highlights'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setFeaturedIds(data.featuredIds || []);
        setVeggieIds(data.veggieIds || []);
      }
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'landingSettings/highlights'));

    return () => {
      unsubServices();
      unsubGallery();
      unsubSettings();
      unsubProducts();
      unsubHighlights();
    };
  }, []);

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.img) return alert("Título e imagen son obligatorios");

    setIsSaving(true);
    try {
      const serviceId = editingService?.id || `service_${Date.now()}`;
      await setDoc(doc(db, 'landingServices', serviceId), {
        ...form,
        updatedAt: serverTimestamp()
      });
      setIsModalOpen(false);
      setEditingService(null);
      setForm({ title: '', desc: '', img: '' });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'landingServices');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingGallery(true);
    try {
      await setDoc(doc(db, 'landingSettings', 'gallery'), {
        ...gallerySettings,
        updatedAt: serverTimestamp()
      }, { merge: true });
      alert("Galería actualizada con éxito");
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'landingSettings/gallery');
    } finally {
      setIsSavingGallery(false);
    }
  };

  const deleteService = async (id: string) => {
    if (!window.confirm("¿Seguro que querés eliminar este servicio?")) return;
    try {
      await deleteDoc(doc(db, 'landingServices', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `landingServices/${id}`);
    }
  };

  const openEdit = (srv: any) => {
    setEditingService(srv);
    setForm({ title: srv.title, desc: srv.desc, img: srv.img });
    setIsModalOpen(true);
  };

  const handleSaveGalleryImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoForm.url) return alert("La URL es obligatoria");
    setIsSaving(true);
    try {
      const photoId = editingPhoto?.id || `photo_${Date.now()}`;
      await setDoc(doc(db, 'landingGallery', photoId), {
        ...photoForm,
        updatedAt: serverTimestamp()
      });
      setIsPhotoModalOpen(false);
      setEditingPhoto(null);
      setPhotoForm({ url: '', title: '', order: galleryImages.length });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'landingGallery');
    } finally {
      setIsSaving(false);
    }
  };

  const deleteGalleryImage = async (id: string) => {
    if (!window.confirm("¿Seguro que querés eliminar esta foto?")) return;
    try {
      await deleteDoc(doc(db, 'landingGallery', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `landingGallery/${id}`);
    }
  };

  const openEditPhoto = (photo: any) => {
    setEditingPhoto(photo);
    setPhotoForm({ url: photo.url, title: photo.title || '', order: photo.order || 0 });
    setIsPhotoModalOpen(true);
  };

  const toggleFeatured = async (productId: string) => {
    const isVeggie = highlightTab === 'veggie';
    const currentList = isVeggie ? veggieIds : featuredIds;
    
    const newList = currentList.includes(productId) 
      ? currentList.filter(id => id !== productId)
      : [...currentList, productId];
    
    if (isVeggie) setVeggieIds(newList);
    else setFeaturedIds(newList);

    try {
      await setDoc(doc(db, 'landingSettings', 'highlights'), {
        featuredIds: isVeggie ? featuredIds : newList,
        veggieIds: isVeggie ? newList : veggieIds,
        updatedAt: serverTimestamp()
      }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'landingSettings/highlights');
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-100">
        <div className="flex gap-8">
          <button 
            onClick={() => setActiveSubTab('services')}
            className={`pb-4 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === 'services' ? 'border-brand-orange text-brand-orange' : 'border-transparent text-gray-400 hover:text-brand-black'}`}
          >
            Servicios
          </button>
          <button 
            onClick={() => setActiveSubTab('blog')}
            className={`pb-4 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === 'blog' ? 'border-brand-orange text-brand-orange' : 'border-transparent text-gray-400 hover:text-brand-black'}`}
          >
            Blog
          </button>
          <button 
            onClick={() => setActiveSubTab('gallery')}
            className={`pb-4 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === 'gallery' ? 'border-brand-orange text-brand-orange' : 'border-transparent text-gray-400 hover:text-brand-black'}`}
          >
            Galería
          </button>
          <button 
            onClick={() => setActiveSubTab('menu')}
            className={`pb-4 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === 'menu' ? 'border-brand-orange text-brand-orange' : 'border-transparent text-gray-400 hover:text-brand-black'}`}
          >
            Menú Destacado
          </button>
        </div>
      </div>

      {activeSubTab === 'services' && (
        <div className="space-y-6 animate-in fade-in duration-500">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-display font-bold text-brand-black">Servicios</h2>
              <p className="text-gray-500 text-sm">Gestioná las tarjetas de la sección "Para todo tipo de eventos".</p>
            </div>
            <button 
              onClick={() => { setEditingService(null); setForm({ title: '', desc: '', img: '' }); setIsModalOpen(true); }}
              className="bg-brand-orange text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-brand-orange-dark transition-colors shadow-lg shadow-brand-orange/20"
            >
              <Plus size={20} /> Nuevo Servicio
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((srv) => (
              <div key={srv.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-shadow group">
                <div className="aspect-[4/5] relative">
                  <img 
                    src={getDirectImageUrl(srv.img)} 
                    alt={srv.title} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                    <button 
                      onClick={() => openEdit(srv)}
                      className="bg-white text-brand-black p-2 rounded-full hover:bg-brand-orange hover:text-white transition-colors"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button 
                      onClick={() => deleteService(srv.id)}
                      className="bg-white text-red-600 p-2 rounded-full hover:bg-red-600 hover:text-white transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="font-bold text-brand-black truncate">{srv.title}</h4>
                  <p className="text-xs text-gray-400 line-clamp-2 mt-1">{srv.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'blog' && <AdminBlog />}

      {activeSubTab === 'gallery' && (
        <div className="space-y-12 animate-in slide-in-from-bottom-2 duration-500 pb-20">
          {/* Settings Section */}
          <div className="max-w-2xl">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
              <h2 className="text-2xl font-display font-bold text-brand-black mb-2">Configuración General</h2>
              <p className="text-gray-500 text-sm mb-8">Personalizá la portada y el destino de la galería "Capturando momentos".</p>
              
              <form onSubmit={handleSaveGallery} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                      <ImageIcon size={14} /> Foto de Portada (Opcional)
                    </label>
                    <input 
                      type="text" 
                      value={gallerySettings.coverImg}
                      onChange={e => setGallerySettings({...gallerySettings, coverImg: e.target.value})}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                    />
                    {gallerySettings.coverImg && (
                      <div className="mt-2 aspect-[21/9] rounded-xl overflow-hidden border border-gray-100">
                        <img 
                          src={getDirectImageUrl(gallerySettings.coverImg)} 
                          alt="Cover Preview" 
                          className="w-full h-full object-cover" 
                          referrerPolicy="no-referrer" 
                        />
                      </div>
                    )}
                    <p className="text-[10px] text-gray-400 mt-1 italic">Si está vacía, no se mostrará la tarjeta de portada.</p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                      <LinkIcon size={14} /> Link a Google Drive (o similar)
                    </label>
                    <input 
                      type="text" 
                      value={gallerySettings.driveLink}
                      onChange={e => setGallerySettings({...gallerySettings, driveLink: e.target.value})}
                      placeholder="https://drive.google.com/..."
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <button 
                    disabled={isSavingGallery}
                    className="w-full bg-brand-orange text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-brand-orange-dark transition-all shadow-lg shadow-brand-orange/20"
                  >
                    {isSavingGallery ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                    Guardar Configuración
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Individual Photos Section */}
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-display font-bold text-brand-black">Fotos de la Galería</h2>
                <p className="text-gray-500 text-sm">Gestioná las fotos que aparecen en la cuadrícula de la web.</p>
              </div>
              <button 
                onClick={() => { setEditingPhoto(null); setPhotoForm({ url: '', title: '', order: galleryImages.length }); setIsPhotoModalOpen(true); }}
                className="bg-brand-orange text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-brand-orange-dark transition-colors shadow-lg shadow-brand-orange/20"
              >
                <Plus size={20} /> Nueva Foto
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {galleryImages.map((photo) => (
                <div key={photo.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm group relative aspect-square">
                  <img 
                    src={getDirectImageUrl(photo.url)} 
                    alt={photo.title || 'Gallery'} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button 
                      onClick={() => openEditPhoto(photo)}
                      className="bg-white text-brand-black p-2 rounded-full hover:bg-brand-orange hover:text-white transition-colors"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => deleteGalleryImage(photo.id)}
                      className="bg-white text-red-600 p-2 rounded-full hover:bg-red-600 hover:text-white transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="absolute top-2 left-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">
                    #{photo.order}
                  </div>
                  {photo.title && (
                    <div className="absolute bottom-0 inset-x-0 bg-black/60 text-white p-2 text-[10px] truncate backdrop-blur-sm">
                      {photo.title}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'menu' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-2 duration-500 pb-20">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-display font-bold text-brand-black">Sabores que Destacan</h2>
              <p className="text-gray-500 text-sm">Seleccioná qué variedades mostrar en cada pestaña de la landing page.</p>
            </div>
            <div className="flex bg-gray-100 p-1 rounded-xl">
              <button 
                onClick={() => setHighlightTab('featured')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${highlightTab === 'featured' ? 'bg-brand-orange text-white' : 'text-gray-500 hover:text-brand-black'}`}
              >
                DESTACADOS
              </button>
              <button 
                onClick={() => setHighlightTab('veggie')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${highlightTab === 'veggie' ? 'bg-brand-orange text-white' : 'text-gray-500 hover:text-brand-black'}`}
              >
                VEGGIES
              </button>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                {highlightTab === 'featured' ? featuredIds.length : veggieIds.length} Seleccionados para {highlightTab === 'featured' ? 'Destacados' : 'Veggies'}
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {products
                .filter(p => highlightTab === 'veggie' ? (p.category === 'veggie' || (p.tags && p.tags.includes('Veggie'))) : true)
                .map((product) => {
                  const isFeatured = highlightTab === 'featured' ? featuredIds.includes(product.id) : veggieIds.includes(product.id);
                return (
                  <button
                    key={product.id}
                    onClick={() => toggleFeatured(product.id)}
                    className={`relative text-left rounded-2xl border-2 transition-all overflow-hidden group ${
                      isFeatured 
                        ? 'border-brand-orange bg-brand-orange/5' 
                        : 'border-gray-100 hover:border-gray-200 bg-white'
                    }`}
                  >
                    <div className="aspect-square relative">
                      <img 
                        src={getDirectImageUrl(product.img)} 
                        alt={product.name}
                        className={`w-full h-full object-cover transition-opacity ${isFeatured ? 'opacity-80' : 'opacity-100'}`}
                        referrerPolicy="no-referrer"
                      />
                      {isFeatured && (
                        <div className="absolute inset-0 flex items-center justify-center bg-brand-orange/20">
                          <div className="bg-white text-brand-orange p-2 rounded-full shadow-lg">
                            <Check size={20} className="stroke-[3]" />
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <h4 className={`text-sm font-bold truncate ${isFeatured ? 'text-brand-black' : 'text-gray-600'}`}>
                        {product.name}
                      </h4>
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-tight">{product.category}</p>
                    </div>
                  </button>
                );
              })}
            </div>
            
            {products.length === 0 && (
              <div className="text-center py-12 border-2 border-dashed border-gray-100 rounded-3xl">
                <p className="text-gray-400 text-sm">No hay productos en el stock. Agregalos en el Panel de Stock.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODALS */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white">
              <h3 className="font-bold text-lg text-brand-black">{editingService ? 'Editar Servicio' : 'Nuevo Servicio'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={24} /></button>
            </div>
            <form onSubmit={handleSaveService} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Título</label>
                <input 
                  type="text" 
                  value={form.title}
                  onChange={e => setForm({...form, title: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                  placeholder="Ej: Casamientos"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Descripción Corta</label>
                <textarea 
                  value={form.desc}
                  onChange={e => setForm({...form, desc: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium h-24 resize-none"
                  placeholder="Breve descripción del servicio..."
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">URL de Imagen</label>
                <input 
                  type="text" 
                  value={form.img}
                  onChange={e => setForm({...form, img: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                  placeholder="https://images.unsplash.com/..."
                />
                {form.img && (
                  <div className="mt-2 aspect-[4/5] rounded-xl overflow-hidden border border-gray-100 max-h-40">
                    <img 
                      src={getDirectImageUrl(form.img)} 
                      alt="Preview" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer" 
                    />
                  </div>
                )}
              </div>

              <div className="pt-2">
                <button 
                  disabled={isSaving}
                  className="w-full bg-brand-orange text-white py-3 rounded-xl font-bold transition-all hover:bg-brand-orange-dark flex items-center justify-center gap-2"
                >
                  {isSaving ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                  {editingService ? 'Actualizar Servicio' : 'Guardar Servicio'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {isPhotoModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white">
              <h3 className="font-bold text-lg text-brand-black">{editingPhoto ? 'Editar Foto' : 'Nueva Foto Galería'}</h3>
              <button onClick={() => setIsPhotoModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={24} /></button>
            </div>
            <form onSubmit={handleSaveGalleryImage} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Título / Nombre</label>
                <input 
                  type="text" 
                  value={photoForm.title}
                  onChange={e => setPhotoForm({...photoForm, title: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                  placeholder="Ej: Plato Especial"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">URL de la Imagen</label>
                <input 
                  type="text" 
                  value={photoForm.url}
                  onChange={e => setPhotoForm({...photoForm, url: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                  placeholder="https://images.unsplash.com/..."
                />
                {photoForm.url && (
                  <div className="mt-2 aspect-square rounded-xl overflow-hidden border border-gray-100 max-h-40">
                    <img 
                      src={getDirectImageUrl(photoForm.url)} 
                      alt="Preview" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer" 
                    />
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Orden (Posición)</label>
                <input 
                  type="number" 
                  value={photoForm.order}
                  onChange={e => setPhotoForm({...photoForm, order: parseInt(e.target.value) || 0})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange font-medium"
                />
              </div>

              <div className="pt-2">
                <button 
                  disabled={isSaving}
                  className="w-full bg-brand-orange text-white py-3 rounded-xl font-bold transition-all hover:bg-brand-orange-dark flex items-center justify-center gap-2"
                >
                  {isSaving ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                  {editingPhoto ? 'Actualizar Foto' : 'Añadir Foto'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
