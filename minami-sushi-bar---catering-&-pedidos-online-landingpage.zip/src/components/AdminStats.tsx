import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { format, subDays, startOfDay, endOfDay, isSameDay, startOfMonth, startOfYear } from 'date-fns';
import { es } from 'date-fns/locale';
import { X, Gift, Percent, Tag, Trash2 } from 'lucide-react';

export default function AdminStats({ 
  orders, 
  settings = {},
  customerFidelity = {}, 
  onUpdateFidelity,
  onDeleteCustomer 
}: { 
  orders: any[], 
  settings?: any,
  customerFidelity?: Record<string, number>,
  onUpdateFidelity?: (phone: string, count: number) => void,
  onDeleteCustomer?: (phone: string, name: string) => void 
}) {
  const COLORS = ['#FF6B00', '#FFA940', '#FFC069', '#FFD591', '#FFE5B4', '#FFF1CC'];
  const threshold = settings?.fidelityThreshold ?? 0;

  const [promoModalOpen, setPromoModalOpen] = useState(false);
  const [promoCustomer, setPromoCustomer] = useState<any>(null);
  const [promoType, setPromoType] = useState<'discount' | 'coupon' | 'free'>('discount');
  const [promoDetails, setPromoDetails] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);

  const openPromoModal = (customer: any) => {
    setPromoCustomer(customer);
    setPromoModalOpen(true);
  };

  const handleSyncFidelity = async () => {
    if (!window.confirm("¿Seguro que querés sincronizar los puntos de fidelidad de TODOS los clientes basándose en el historial de pedidos y el monto mínimo actual? Esto sobrescribirá los valores manuales.")) return;
    
    setIsSyncing(true);
    try {
      let updatedCount = 0;
      // We'll update them one by one via the prop provided
      for (const customer of stats.allCustomers) {
        if (customer.totalCount !== customer.count) {
          await onUpdateFidelity?.(customer.phone, customer.count);
          updatedCount++;
        }
      }
      alert(`Sincronización completada con éxito. Se actualizaron ${updatedCount} clientes.`);
    } catch (e) {
      console.error("Fidelity Sync Error:", e);
      alert("Error durante la sincronización. Ver consola para más detalles.");
    } finally {
      setIsSyncing(false);
    }
  };

  const stats = useMemo(() => {
    const today = new Date();
    
    // Revenue logic
    let todayRev = 0;
    let thisMonthRev = 0;
    let thisYearRev = 0;
    
    // Last 7 days chart
    const last7Days = Array.from({ length: 7 }).map((_, i) => subDays(today, 6 - i));
    const dailyData = last7Days.map(date => {
      return {
        name: format(date, 'eee d', { locale: es }),
        ingresos: 0,
        pedidos: 0,
        date
      };
    });

    const topProductsMap: Record<string, number> = {};
    const customerMap: Record<string, { phone: string, name: string, count: number, totalSpent: number, lastOrderDate: Date, orders: { date: Date, amount: number }[] }> = {};

    orders.forEach(order => {
      // Skip cancelled orders
      if (order.status === 'cancelled' || order.status === 'anulado') return;

      const orderDate = order.createdAt?.toDate ? order.createdAt.toDate() : new Date(order.createdAt);
      if (!orderDate || isNaN(orderDate.getTime())) return;
      
      const amount = Number(order.totalAmount) || 0;

      // Global revs
      if (orderDate >= startOfDay(today)) todayRev += amount;
      if (orderDate >= startOfMonth(today)) thisMonthRev += amount;
      if (orderDate >= startOfYear(today)) thisYearRev += amount;

      // Group for chart
      const dayChart = dailyData.find(d => isSameDay(d.date, orderDate));
      if (dayChart) {
        dayChart.ingresos += amount;
        dayChart.pedidos += 1;
      }

      // Group products
      if (order.items && Array.isArray(order.items)) {
        order.items.forEach((item: any) => {
          if (!item || !item.name) return;
          if (!topProductsMap[item.name]) topProductsMap[item.name] = 0;
          topProductsMap[item.name] += (Number(item.quantity) || 0);
        });
      }

      // Group customers by phone
      if (order.phone) {
        if (!customerMap[order.phone]) {
          customerMap[order.phone] = { 
            phone: order.phone,
            name: order.name || 'Desconocido', 
            count: 0,
            totalSpent: 0,
            lastOrderDate: orderDate,
            orders: []
          };
        }
        
        const customer = customerMap[order.phone];
        // ONLY count if meets threshold
        if (amount >= threshold) {
          customer.count += 1;
        }
        
        customer.totalSpent += amount;
        customer.orders.push({ date: orderDate, amount });
        
        if (orderDate > customer.lastOrderDate) {
          customer.lastOrderDate = orderDate;
        }
        
        if (order.name && customer.name === 'Desconocido') {
            customer.name = order.name;
        }
      }
    });

    // Sort top products
    const topProducts = Object.entries(topProductsMap)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5); // top 5

    // Sort top customers (for the summary widget)
    const allCustomers = Object.values(customerMap).map(c => {
      const cleanPhone = c.phone.replace(/\D/g, '');
      const dbCount = customerFidelity[cleanPhone];
      return {
        ...c,
        totalCount: dbCount !== undefined ? dbCount : c.count
      };
    }).sort((a, b) => b.lastOrderDate.getTime() - a.lastOrderDate.getTime());
    
    const topCustomers = [...allCustomers].sort((a, b) => b.totalCount - a.totalCount).slice(0, 5);

    return { todayRev, thisMonthRev, thisYearRev, dailyData, topProducts, topCustomers, allCustomers };
  }, [orders, customerFidelity, threshold]);

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold text-brand-black">Estadísticas</h1>
        <p className="text-brand-gray">Resumen de ventas y métricas clave.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex flex-col justify-center items-center text-center">
          <span className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-2">Hoy</span>
          <span className="text-4xl font-bold text-brand-black">${stats.todayRev.toLocaleString()}</span>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex flex-col justify-center items-center text-center">
          <span className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-2">Este Mes</span>
          <span className="text-4xl font-bold text-brand-black">${stats.thisMonthRev.toLocaleString()}</span>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex flex-col justify-center items-center text-center">
          <span className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-2">Este Año</span>
          <span className="text-4xl font-bold text-brand-black">${stats.thisYearRev.toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 lg:col-span-2">
          <h3 className="font-bold text-lg mb-6">Ingresos Últimos 7 Días</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.dailyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dx={-10} tickFormatter={value => `$${value}`} />
                <Tooltip 
                  cursor={{ fill: '#F9FAFB' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, 'Ingresos']}
                />
                <Bar dataKey="ingresos" fill="#FF6B00" radius={[4, 4, 0, 0]} maxBarSize={50} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex-1">
            <h3 className="font-bold text-lg mb-4">Top 5 Productos</h3>
            {stats.topProducts.length > 0 ? (
              <>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stats.topProducts}
                        innerRadius={30}
                        outerRadius={50}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {stats.topProducts.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 flex flex-col gap-2">
                  {stats.topProducts.map((p, i) => (
                    <div key={i} className="flex justify-between items-center text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                        <span className="text-gray-600 truncate max-w-[120px]">{p.name}</span>
                      </div>
                      <span className="font-bold">{p.value} ud.</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
                <div className="h-full flex items-center justify-center text-gray-400 italic">No hay suficientes datos.</div>
            )}
          </div>
          
          <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex-1">
             <h3 className="font-bold text-lg mb-4">Clientes Frecuentes</h3>
             {stats.topCustomers.length > 0 ? (
               <div className="flex flex-col gap-3">
                 {stats.topCustomers.map((c, i) => (
                   <div key={i} className="flex justify-between items-center bg-gray-50 p-2 rounded-lg text-sm">
                     <div className="flex flex-col">
                       <span className="font-bold text-brand-black">{c.name}</span>
                       <span className="text-xs text-gray-400">{c.phone}</span>
                     </div>
                     <div className="bg-orange-100 text-brand-orange font-bold px-2 py-1 rounded">
                       {c.totalCount} {c.totalCount === 1 ? 'pedido' : 'pedidos'}
                     </div>
                   </div>
                 ))}
               </div>
             ) : (
               <div className="h-full flex items-center justify-center text-gray-400 italic">No hay clientes aún.</div>
             )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 mt-8 overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h3 className="font-bold text-xl text-brand-black">Directorio de Clientes</h3>
            <p className="text-sm text-gray-500">Historial completo para fidelización y promociones.</p>
          </div>
          <button 
            onClick={handleSyncFidelity}
            disabled={isSyncing}
            className={`px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${isSyncing ? 'bg-gray-100 text-gray-400' : 'bg-orange-50 text-brand-orange hover:bg-orange-100'}`}
          >
            {isSyncing ? 'Sincronizando...' : 'Sincronizar Puntos con Pedidos'}
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr>
                <th className="px-6 py-4 font-bold">Cliente</th>
                <th className="px-6 py-4 font-bold">Contacto</th>
                <th className="px-6 py-4 font-bold">Compras (Fidelidad)</th>
                <th className="px-6 py-4 font-bold">Total Gastado</th>
                <th className="px-6 py-4 font-bold">Última Compra</th>
                <th className="px-6 py-4 font-bold">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {stats.allCustomers.map((c, i) => (
                <tr key={i} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4 font-bold text-brand-black">{c.name}</td>
                  <td className="px-6 py-4 text-brand-gray">{c.phone}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                       <input 
                         type="number" 
                         key={`${c.phone}-${c.totalCount}`}
                         defaultValue={c.totalCount}
                         onBlur={(e) => onUpdateFidelity?.(c.phone, parseInt(e.target.value) || 0)}
                         className="w-16 border border-orange-200 rounded px-2 py-1 text-center font-bold text-brand-orange bg-orange-50 focus:outline-none focus:ring-1 focus:ring-brand-orange" 
                       />
                       <div className="flex flex-col">
                          <span className="text-[10px] text-gray-400 italic">Sugerido: {c.count}</span>
                          <span className="text-[8px] text-gray-400 italic">(Pedidos ≥ ${threshold.toLocaleString()})</span>
                       </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-bold text-green-600">
                    ${c.totalSpent.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-brand-black">{format(c.lastOrderDate, 'dd/MM/yyyy')}</span>
                      <span className="text-xs text-gray-400">
                        Hace {Math.floor((new Date().getTime() - c.lastOrderDate.getTime()) / (1000 * 3600 * 24))} días
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => openPromoModal(c)}
                        className="text-white bg-[#25D366] hover:bg-[#20bd5a] px-3 py-1.5 rounded font-medium text-xs transition-colors"
                      >
                        Enviar Promo
                      </button>
                      <button 
                        onClick={() => onDeleteCustomer?.(c.phone, c.name)}
                        className="text-gray-400 hover:text-red-500 transition-colors p-1.5"
                        title="Borrar todos los datos de este cliente"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {stats.allCustomers.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-400 italic">No hay clientes registrados aún.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {promoModalOpen && promoCustomer && (
        <div className="fixed inset-0 bg-brand-black/50 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl relative">
            <button onClick={() => setPromoModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-brand-black z-10 transition-colors">
              <X size={24} />
            </button>
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-1">Enviar Promo a {promoCustomer.name}</h2>
              <p className="text-gray-500 text-sm mb-6">Selecciona el tipo de promoción para enviarle por WhatsApp.</p>
              
              <div className="grid grid-cols-3 gap-3 mb-6">
                <button 
                  onClick={() => setPromoType('discount')} 
                  className={`p-3 rounded-xl border flex flex-col items-center gap-2 ${promoType === 'discount' ? 'border-brand-orange bg-orange-50 text-brand-orange' : 'border-gray-200 text-gray-500 hover:border-brand-orange'}`}
                >
                  <Percent size={20} />
                  <span className="text-xs font-bold">Descuento</span>
                </button>
                <button 
                  onClick={() => setPromoType('coupon')} 
                  className={`p-3 rounded-xl border flex flex-col items-center gap-2 ${promoType === 'coupon' ? 'border-brand-orange bg-orange-50 text-brand-orange' : 'border-gray-200 text-gray-500 hover:border-brand-orange'}`}
                >
                  <Tag size={20} />
                  <span className="text-xs font-bold">Cupón</span>
                </button>
                <button 
                  onClick={() => setPromoType('free')} 
                  className={`p-3 rounded-xl border flex flex-col items-center gap-2 ${promoType === 'free' ? 'border-brand-orange bg-orange-50 text-brand-orange' : 'border-gray-200 text-gray-500 hover:border-brand-orange'}`}
                >
                  <Gift size={20} />
                  <span className="text-xs font-bold">Gratis</span>
                </button>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  {promoType === 'discount' && 'Ej: Tu próximo pedido tiene 15% OFF'}
                  {promoType === 'coupon' && 'Ej: Código MINAMI20 para $2000 de regalo'}
                  {promoType === 'free' && 'Ej: Un Roll extra de regalo con tu compra'}
                </label>
                <textarea 
                  rows={3} 
                  value={promoDetails} 
                  onChange={e => setPromoDetails(e.target.value)} 
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-orange resize-none" 
                  placeholder="Detalles de la promoción..." 
                />
              </div>

              <button 
                onClick={() => {
                  let message = `¡Hola ${promoCustomer.name}! Tenemos una sorpresa de Minami Sushi Bar para vos 🍣✨\n\n`;
                  if (promoType === 'discount') message += `*¡Tenés un descuento especial!*\n${promoDetails}\n\n`;
                  if (promoType === 'coupon') message += `*¡Tu cupón de regalo!*\n${promoDetails}\n\n`;
                  if (promoType === 'free') message += `*¡Te damos algo gratis!*\n${promoDetails}\n\n`;
                  message += `Hacé tu pedido ahora en nuestra tienda online. ¡Te esperamos!`;
                  
                  const phoneFormatted = promoCustomer.phone.replace(/[^0-9]/g, '').startsWith('54') ? promoCustomer.phone.replace(/[^0-9]/g, '') : '549' + promoCustomer.phone.replace(/[^0-9]/g, '');
                  window.open(`https://wa.me/${phoneFormatted}?text=${encodeURIComponent(message)}`, '_blank');
                  setPromoModalOpen(false);
                  setPromoDetails('');
                }}
                className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white py-3.5 rounded-xl font-bold flex justify-center items-center gap-2 transition-colors"
              >
                Enviar por WhatsApp
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
