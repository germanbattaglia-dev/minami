import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu as MenuIcon, X, MapPin, Phone, Mail, Instagram, Facebook, ChevronRight, ChevronLeft, ChevronDown, CheckCircle2, Image as ImageIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { db, handleFirestoreError, OperationType } from './firebase';
import { collection, onSnapshot, query, doc } from 'firebase/firestore';
import { getDirectImageUrl } from './lib/imageUtils';

import WhatsAppButton from './components/WhatsAppButton';
import Chatbot from './components/Chatbot';
import DeliveryPopup from './components/DeliveryPopup';

const LOGO_URL = "https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?auto=format&fit=crop&q=80&w=100&h=100"; // Placeholder mapping, let's just use CSS text for logo for simplicity or an img tag if we had the actual file served. I will make a typographic logo that mimics the real one.

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-brand-gray-light font-sans selection:bg-brand-orange selection:text-white">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-brand-black/95 backdrop-blur-md py-3 shadow-lg' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <motion.a 
              href="#" 
              className="group"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Logo size="md" />
            </motion.a>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <NavLink href="/#servicios" scrolled={isScrolled}>Servicios</NavLink>
              <NavLink href="/#menu" scrolled={isScrolled}>Menú</NavLink>
              <NavLink href="/#galeria" scrolled={isScrolled}>Galería</NavLink>
              <NavLink href="/#faq" scrolled={isScrolled}>FAQ</NavLink>
              <NavLink href="/tienda" scrolled={isScrolled}>Delivery & Pick Up</NavLink>
              <motion.a 
                href="/#contacto" 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-brand-orange hover:bg-brand-orange-dark text-white px-6 py-2.5 rounded-full font-medium transition-colors text-sm uppercase tracking-wide"
              >
                Cotizar Evento
              </motion.a>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={28} /> : <MenuIcon size={28} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-brand-black pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col space-y-6 text-center">
              <MobileNavLink href="/#servicios" onClick={() => setMobileMenuOpen(false)}>Servicios</MobileNavLink>
              <MobileNavLink href="/#menu" onClick={() => setMobileMenuOpen(false)}>Menú</MobileNavLink>
              <MobileNavLink href="/#galeria" onClick={() => setMobileMenuOpen(false)}>Galería</MobileNavLink>
              <MobileNavLink href="/#faq" onClick={() => setMobileMenuOpen(false)}>FAQ</MobileNavLink>
              <MobileNavLink href="/tienda" onClick={() => setMobileMenuOpen(false)}>Delivery & Pick Up</MobileNavLink>
              <a 
                href="/#contacto" 
                onClick={() => setMobileMenuOpen(false)}
                className="bg-brand-orange text-white px-8 py-3 rounded-full font-medium uppercase tracking-wide inline-block mt-4"
              >
                Cotizar Evento
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main>
        {/* Hero Section */}
        <HeroSection />

        {/* Services Section */}
        <ServicesSection />

        {/* Menu Section */}
        <MenuSection />

        {/* Gallery Section */}
        <GallerySection />

        {/* Testimonials */}
        <TestimonialsSection />

        {/* Blog Section */}
        <BlogSection />

        {/* FAQ Section */}
        <FAQSection />

        {/* Contact Section */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Widgets & Popups */}
      <DeliveryPopup />
      <WhatsAppButton />
      <Chatbot />
    </div>
  );
}

// -- Components --

function Logo({ size = 'md' }: { size?: 'sm' | 'md' }) {
  const [imgError, setImgError] = useState(false);
  
  const isSmall = size === 'sm';
  const imgClasses = isSmall ? "w-10 h-10" : "w-12 h-12";
  const circleClasses = isSmall ? "w-8 h-8 text-base" : "w-10 h-10 text-xl";
  const titleClasses = isSmall ? "text-lg" : "text-xl";
  const subtitleClasses = isSmall ? "text-[9px]" : "text-[10px]";

  return (
    <div className="flex items-center gap-2 group">
      {!imgError ? (
        <img 
          src="/logo.png" 
          alt="Minami Sushi Bar" 
          className={`${imgClasses} object-contain rounded-full bg-white p-0.5`}
          onError={() => setImgError(true)}
        />
      ) : (
        <div className={`${circleClasses} rounded-full bg-brand-orange text-white flex items-center justify-center font-display font-bold group-hover:bg-white group-hover:text-brand-orange transition-colors shrink-0`}>
          M
        </div>
      )}
      <div className="flex flex-col">
        <span className={`font-display font-bold ${titleClasses} leading-none tracking-tight text-white`}>MINAMI</span>
        <span className={`${subtitleClasses} tracking-widest font-semibold text-brand-orange uppercase`}>Sushi Bar</span>
      </div>
    </div>
  );
}

function NavLink({ href, children, scrolled }: { href: string; children: React.ReactNode; scrolled: boolean }) {
  const isInternal = href.startsWith('/#') || href.startsWith('http');
  if (isInternal) {
    return (
      <a 
        href={href} 
        className={`text-sm font-medium hover:text-brand-orange transition-colors ${scrolled ? 'text-gray-200' : 'text-gray-200'}`}
      >
        {children}
      </a>
    );
  }
  return (
    <Link 
      to={href} 
      className={`text-sm font-medium hover:text-brand-orange transition-colors ${scrolled ? 'text-gray-200' : 'text-gray-200'}`}
    >
      {children}
    </Link>
  );
}

function MobileNavLink({ href, children, onClick }: { href: string; children: React.ReactNode; onClick: () => void }) {
  const isInternal = href.startsWith('/#') || href.startsWith('http');
  if (isInternal) {
    return (
      <a 
        href={href} 
        onClick={onClick}
        className="text-2xl font-display font-medium text-white hover:text-brand-orange transition-colors"
      >
        {children}
      </a>
    );
  }
  return (
    <Link 
      to={href} 
      onClick={onClick}
      className="text-2xl font-display font-medium text-white hover:text-brand-orange transition-colors"
    >
      {children}
    </Link>
  );
}

function HeroSection() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&q=80&w=2650" 
          alt="Sushi background" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/60"></div>
        {/* Soft gradient overlay for text readability */}
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-brand-black to-transparent"></div>
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto mt-20">
        <motion.span 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-brand-orange font-semibold tracking-widest uppercase text-sm mb-4 block"
        >
          Experiencia Premium
        </motion.span>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-5xl md:text-7xl font-display font-bold text-white leading-tight mb-6"
        >
          Llevamos el mejor <span className="text-brand-orange italic font-light">Sushi Bar</span> a tu evento.
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl mx-auto font-light"
        >
          Casamientos, cumpleaños, eventos corporativos y celebraciones especiales. Calidad, frescura y diseño en cada pieza.
        </motion.p>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.a 
            href="#contacto" 
            whileHover={{ scale: 1.05, translateY: -2 }}
            whileTap={{ scale: 0.95 }}
            className="bg-brand-orange hover:bg-brand-orange-dark text-white px-8 py-4 rounded-full font-medium transition-all text-sm uppercase tracking-wider w-full sm:w-auto shadow-lg shadow-brand-orange/20"
          >
            Cotizar ahora
          </motion.a>
          <motion.a 
            href="#menu" 
            whileHover={{ backgroundColor: "rgba(255,255,255,0.1)", scale: 1.05, translateY: -2 }}
            whileTap={{ scale: 0.95 }}
            className="bg-transparent border border-white/30 hover:bg-white/10 text-white px-8 py-4 rounded-full font-medium transition-all text-sm uppercase tracking-wider w-full sm:w-auto"
          >
            Ver Menú
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}

function ServicesSection() {
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'landingServices'));
    const unsub = onSnapshot(q, (snapshot) => {
      const loaded = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setServices(loaded);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'landingServices');
    });
    return () => unsub();
  }, []);

  return (
    <section id="servicios" className="py-24 bg-white text-brand-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm text-brand-orange font-bold tracking-widest uppercase mb-2">Servicios</h2>
          <h3 className="text-4xl md:text-5xl font-display font-light">Para todo tipo de <span className="font-bold">eventos</span></h3>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((srv, idx) => (
            <motion.div 
              key={srv.id || idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ y: -10 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className="group cursor-pointer"
            >
              <div className="overflow-hidden rounded-2xl mb-6 relative aspect-[4/5] shadow-xl">
                <img 
                  src={getDirectImageUrl(srv.img)} 
                  alt={srv.title} 
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                  referrerPolicy="no-referrer" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80"></div>
                <div className="absolute bottom-6 left-6 right-6">
                  <h4 className="text-2xl font-display font-semibold text-white mb-2">{srv.title}</h4>
                  <p className="text-gray-300 text-sm font-light leading-relaxed">{srv.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Catering Services Highlights */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {[
            { 
              title: "Barra de Sushi Tradicional 🍣", 
              highlight: "Experiencia Clásica",
              desc: "Nuestro servicio insignia para eventos de gala, casamientos y reuniones corporativas. Un sushiman profesional preparando las piezas en vivo.",
              linkText: "Contratar para mi evento",
              matchKeywords: ['barra'],
              theme: 'dark'
            },
            {
              title: "Sushi en tu Casa Chef Service 🏠",
              highlight: "Privado & Exclusivo",
              desc: "Llevamos la barra a tu living. Ideal para cenas íntimas, cumpleaños o juntadas con amigos donde buscás sorprender sin moverte de casa.",
              linkText: "Reservar fecha",
              matchKeywords: ['sushi', 'casa'],
              theme: 'light'
            },
            {
              title: "Pancho Sushi Experience 🌭",
              highlight: "Propuesta Innovadora",
              desc: "¡Lo más pedido en recepciones! Una fusión sorprendente y deliciosa que rompe los esquemas tradicionales. Ideal para sorprender.",
              linkText: "Saber más",
              matchKeywords: ['pancho'],
              theme: 'orange'
            }
          ].map((card, i) => {
            const matchedSrv = services.find(s => 
              card.matchKeywords.every(kw => s.title?.toLowerCase().includes(kw))
            );
            const imgUrl = matchedSrv ? getDirectImageUrl(matchedSrv.img) : null;

            return (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`group relative overflow-hidden rounded-3xl p-8 border ${
                  card.theme === 'dark' ? 'bg-brand-black border-white/5 text-white' : 
                  card.theme === 'orange' ? 'bg-brand-orange border-orange-400 text-white' : 
                  'bg-white border-gray-100 text-brand-black'
                } shadow-2xl flex flex-col h-full`}
              >
                {imgUrl ? (
                  <div className="absolute inset-0 z-0">
                    <img 
                      src={imgUrl} 
                      alt={card.title} 
                      className="w-full h-full object-cover opacity-20 group-hover:scale-110 transition-transform duration-1000" 
                      referrerPolicy="no-referrer"
                    />
                    <div className={`absolute inset-0 ${
                      card.theme === 'dark' ? 'bg-brand-black/60' : 
                      card.theme === 'orange' ? 'bg-brand-orange/60' : 
                      'bg-white/80'
                    }`} />
                  </div>
                ) : (
                  <div className={`absolute top-0 right-0 w-32 h-32 blur-3xl -mr-16 -mt-16 rounded-full group-hover:opacity-60 transition-opacity ${
                    card.theme === 'dark' ? 'bg-brand-orange/10' : 
                    card.theme === 'orange' ? 'bg-white/10' : 
                    'bg-brand-orange/5'
                  }`}></div>
                )}
                
                <div className="relative z-10 flex flex-col h-full">
                  <span className={`${
                    card.theme === 'dark' ? 'text-brand-orange' : 
                    card.theme === 'orange' ? 'text-white/60' : 
                    'text-gray-400'
                  } font-black text-xs uppercase tracking-[0.2em] mb-4 block`}>
                    {card.highlight}
                  </span>
                  <h4 className="text-2xl font-display font-bold mb-4 leading-tight">
                    {card.title.split(' ').map((word, j) => (
                      <React.Fragment key={j}>
                        {word} {j === 2 && <br />}
                      </React.Fragment>
                    ))}
                  </h4>
                  <p className={`${
                    card.theme === 'dark' ? 'text-gray-400' : 
                    card.theme === 'orange' ? 'text-white/80' : 
                    'text-gray-500'
                  } font-light mb-8 flex-grow text-sm`}>
                    {matchedSrv?.desc || card.desc}
                  </p>
                  <a href="#contacto" className={`flex items-center gap-2 font-bold uppercase tracking-widest text-[10px] ${
                    card.theme === 'orange' ? 'text-white' : 'text-brand-orange'
                  }`}>
                    {card.linkText} <ChevronRight size={14} />
                  </a>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function MenuSection() {
  const [activeTab, setActiveTab] = useState('featured');
  const [products, setProducts] = useState<any[]>([]);
  const [featuredIds, setFeaturedIds] = useState<string[]>([]);
  const [veggieIds, setVeggieIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch products
    const q = query(collection(db, 'products'));
    const unsubProducts = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      fetched.sort((a: any, b: any) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
      setProducts(fetched);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'products'));

    // Fetch highlights
    const unsubHighlights = onSnapshot(doc(db, 'landingSettings', 'highlights'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setFeaturedIds(data.featuredIds || []);
        setVeggieIds(data.veggieIds || []);
      }
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'landingSettings/highlights'));

    return () => {
      unsubProducts();
      unsubHighlights();
    };
  }, []);

  const menuCategories = [
    { id: 'featured', label: 'Destacados' },
    { id: 'veggie', label: 'Veggies' }
  ];

  const getFilteredItems = () => {
    if (loading) return [];
    
    // Explicit selection logic
    if (activeTab === 'featured' && featuredIds.length > 0) {
      return products.filter(p => featuredIds.includes(p.id));
    }
    if (activeTab === 'veggie' && veggieIds.length > 0) {
      return products.filter(p => veggieIds.includes(p.id));
    }

    // Fallback logic if no explicit selection
    if (activeTab === 'veggie') {
      return products.filter(p => 
        (p.tags && p.tags.some((t: string) => t.toLowerCase() === 'veggie')) ||
        p.category === 'veggie'
      ).slice(0, 8);
    }
    
    // Default featured: top rated or first 8
    return products.slice(0, 8);
  };

  const displayItems = getFilteredItems();

  return (
    <section id="menu" className="py-24 bg-brand-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
           <h2 className="text-sm text-brand-orange font-bold tracking-widest uppercase mb-2">Nuestro Menú</h2>
           <h3 className="text-4xl md:text-5xl font-display font-light">Sabores que <span className="font-bold">destacan</span></h3>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {menuCategories.map(cat => (
             <motion.button
               key={cat.id}
               onClick={() => setActiveTab(cat.id)}
               whileHover={{ scale: 1.05 }}
               whileTap={{ scale: 0.95 }}
               className={`px-8 py-2.5 rounded-full text-sm font-bold tracking-wider uppercase transition-all ${
                 activeTab === cat.id 
                   ? 'bg-brand-orange text-white shadow-lg shadow-brand-orange/30' 
                   : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
               }`}
             >
               {cat.label}
             </motion.button>
          ))}
        </div>

        {/* Menu Grid */}
        <AnimatePresence mode="wait">
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="grid sm:grid-cols-2 lg:grid-cols-2 gap-x-12 gap-y-10 max-w-4xl mx-auto"
          >
            {displayItems.map((item, idx) => (
               <motion.div 
                 key={item.id || idx} 
                 initial={{ opacity: 0, x: -10 }}
                 animate={{ opacity: 1, x: 0 }}
                 transition={{ delay: idx * 0.1 }}
                 className="flex gap-4 group"
               >
                 <div className="w-24 h-24 shrink-0 rounded-2xl overflow-hidden bg-gray-800 shadow-lg">
                   <img 
                     src={getDirectImageUrl(item.img)} 
                     alt={item.name} 
                     loading="lazy"
                     decoding="async"
                     className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                     referrerPolicy="no-referrer" 
                   />
                 </div>
                 <div>
                   <div className="flex justify-between items-baseline mb-1">
                     <h4 className="text-lg font-display font-semibold text-white group-hover:text-brand-orange transition-colors">{item.name}</h4>
                   </div>
                   <p className="text-gray-400 text-sm leading-relaxed line-clamp-2">{item.desc}</p>
                 </div>
               </motion.div>
            ))}
            {displayItems.length === 0 && !loading && (
              <div className="col-span-full text-center py-12 text-gray-500">
                Próximamente más variedades en esta categoría.
              </div>
            )}
          </motion.div>
        </AnimatePresence>
        
        <div className="mt-16 text-center">
            <p className="text-gray-400 italic font-serif mb-6 text-sm">Ofrecemos opciones personalizadas según las necesidades de su evento. Incluyendo opciones sin tacc.</p>
            <a href="#contacto" className="inline-flex items-center gap-2 text-brand-orange font-medium hover:text-white transition-colors">
              Solicitar menú completo <ChevronRight size={16} />
            </a>
        </div>
      </div>
    </section>
  );
}

function GallerySection() {
  const [gallery, setGallery] = useState({ coverImg: '', driveLink: '' });
  const [images, setImages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubSettings = onSnapshot(doc(db, 'landingSettings', 'gallery'), (snap) => {
      if (snap.exists()) {
        setGallery(snap.data() as any);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'landingSettings/gallery');
    });

    const unsubImages = onSnapshot(collection(db, 'landingGallery'), (snap) => {
      const loaded = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setImages(loaded.sort((a: any, b: any) => (a.order || 0) - (b.order || 0)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'landingGallery');
    });

    return () => {
      unsubSettings();
      unsubImages();
    };
  }, []);

  const defaultImages = [
    "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1579871494447-0811cf80d49d?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1563612116625-3012372fcec8?auto=format&fit=crop&q=80&w=800"
  ];

  const displayImages = images.length > 0 ? images.map(i => i.url) : defaultImages;

  return (
    <section id="galeria" className="py-24 bg-brand-gray-light font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div>
            <h2 className="text-sm text-brand-orange font-bold tracking-widest uppercase mb-2">Galería</h2>
            <h3 className="text-4xl md:text-5xl font-display font-light text-brand-black">Capturando <span className="font-bold">momentos</span></h3>
          </div>
          <div className="flex flex-col items-end gap-2">
            <a href="https://instagram.com/minamisushibar" target="_blank" rel="noreferrer" className="inline-flex mt-4 md:mt-0 items-center gap-2 text-brand-black hover:text-brand-orange transition-colors font-medium">
              Seguinos en Instagram <Instagram size={18} />
            </a>
          </div>
        </div>

        {gallery.coverImg && (
          <div className="relative group rounded-3xl overflow-hidden shadow-2xl bg-brand-black mb-12">
            <div className="aspect-[21/9] relative scale-100 group-hover:scale-105 transition-transform duration-1000">
              <img 
                src={getDirectImageUrl(gallery.coverImg)} 
                alt="Gallery Cover" 
                className="w-full h-full object-cover opacity-70" 
                referrerPolicy="no-referrer" 
              />
            </div>
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                className="max-w-xl"
              >
                <h4 className="text-white text-3xl md:text-5xl font-display font-bold mb-6 drop-shadow-lg">Nuestra Experiencia Completa</h4>
                <p className="text-white/80 mb-8 font-light max-w-md mx-auto hidden md:block">Explorá nuestro historial de eventos, presentaciones y momentos únicos capturados en cada servicio.</p>
                {gallery.driveLink && (
                  <a 
                    href={gallery.driveLink} 
                    target="_blank" 
                    rel="noreferrer"
                    className="inline-flex items-center gap-3 bg-brand-orange text-white px-8 py-4 rounded-full font-bold uppercase tracking-widest text-xs hover:bg-white hover:text-brand-orange transition-all shadow-xl"
                  >
                    Ver galería completa <ImageIcon size={18} />
                  </a>
                )}
              </motion.div>
            </div>
          </div>
        )}

        <div className="relative group overflow-hidden">
          {/* Navigation Arrows */}
          <div className="flex">
            <button 
              onClick={() => {
                if (scrollRef.current) {
                  const scrollAmount = scrollRef.current.offsetWidth * 0.8;
                  scrollRef.current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
                }
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-white/90 text-brand-black p-2 md:p-4 rounded-full shadow-2xl hover:bg-brand-orange hover:text-white transition-all transform hover:scale-110 flex items-center justify-center opacity-100 md:opacity-0 md:group-hover:opacity-100"
            >
              <ChevronLeft size={20} className="md:w-6 md:h-6" />
            </button>
            <button 
              onClick={() => {
                if (scrollRef.current) {
                  const scrollAmount = scrollRef.current.offsetWidth * 0.8;
                  scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
                }
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-white/90 text-brand-black p-2 md:p-4 rounded-full shadow-2xl hover:bg-brand-orange hover:text-white transition-all transform hover:scale-110 flex items-center justify-center opacity-100 md:opacity-0 md:group-hover:opacity-100"
            >
              <ChevronRight size={20} className="md:w-6 md:h-6" />
            </button>
          </div>

          <motion.div 
            ref={scrollRef}
            className="flex gap-4 overflow-x-auto pb-8 snap-x snap-mandatory scrollbar-hide no-scrollbar"
            style={{ 
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
              WebkitOverflowScrolling: 'touch'
            }}
          >
            {displayImages.map((img, idx) => (
              <motion.div 
                key={idx} 
                initial={{ opacity: 0, scale: 0.9 }} 
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="flex-none w-[80vw] md:w-[45vw] lg:w-[30vw] aspect-square overflow-hidden rounded-3xl bg-gray-200 shadow-xl snap-center relative group/item"
              >
                <img 
                  src={getDirectImageUrl(img)} 
                  alt={`Gallery ${idx}`} 
                  className="w-full h-full object-cover group-hover/item:scale-110 transition-transform duration-700" 
                  referrerPolicy="no-referrer" 
                />
                {images[idx]?.title && (
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover/item:opacity-100 transition-opacity flex items-end p-6">
                    <p className="text-white font-display font-bold text-lg">{images[idx].title}</p>
                  </div>
                )}
              </motion.div>
            ))}
          </motion.div>
          
          {/* Scroll Indicators */}
          <div className="flex justify-center gap-2 mt-8">
            {displayImages.map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 rounded-full bg-brand-orange/40" />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  const testimonials = [
    { text: "El servicio fue impecable de principio a fin. El sushi super fresco y el armado de la mesa fue espectacular. ¡Todos los invitados quedaron encantados!", author: "María Eugenia", event: "Casamiento en Coronel Suarez" },
    { text: "Contratamos a Minami para la fiesta de fin de año de la empresa y la experiencia fue de otro nivel. Profesionales absolutos.", author: "Juan Pablo S.", event: "Evento Corporativo" },
    { text: "Celebré mis 30 años y quería algo distinto. El Sushi Bar en vivo fue la atracción de la noche. Riquísimo y con una presentación hermosa.", author: "Lucía M.", event: "Cumpleaños" }
  ];

  return (
    <section className="py-24 bg-brand-orange text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-display font-bold mb-16">Lo que dicen nuestros <span className="font-light italic">clientes</span></h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <div key={idx} className="bg-brand-black/10 backdrop-blur-sm p-8 rounded-3xl text-left border border-white/10 shadow-xl">
              <div className="flex text-yellow-300 mb-6">
                 {[...Array(5)].map((_, i) => <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>)}
              </div>
              <p className="text-lg font-medium leading-snug mb-8">"{t.text}"</p>
              <div>
                 <p className="font-bold text-sm tracking-wide uppercase">{t.author}</p>
                 <p className="text-white/70 text-sm font-light mt-1">{t.event}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BlogSection() {
  const [posts, setPosts] = useState<any[]>([]);
  const [selectedPost, setSelectedPost] = useState<any>(null);

  useEffect(() => {
    let isSubscribed = true;
    const fetchBlog = async () => {
      const { collection, onSnapshot, query, orderBy } = await import('firebase/firestore');
      const { db } = await import('./firebase');
      
      const q = query(collection(db, 'blog'), orderBy('createdAt', 'desc'));
      
      const unsub = onSnapshot(q, async (snapshot) => {
        if (!isSubscribed) return;
        
        let loadedPosts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setPosts(loadedPosts);
      }, (error) => {
         console.error("Blog fetch error", error);
      });
      
      return unsub;
    };
    
    let unsubCall: any = null;
    fetchBlog().then(unsub => { unsubCall = unsub; });
    
    return () => {
      isSubscribed = false;
      if (unsubCall) unsubCall();
    }
  }, []);

  if (posts.length === 0) return null;

  return (
    <section id="blog" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm text-brand-orange font-bold tracking-widest uppercase mb-2">Novedades</h2>
          <h3 className="text-4xl md:text-5xl font-display font-light">Nuestro <span className="font-bold">Blog</span></h3>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {posts.map((post, idx) => (
             <motion.div 
                key={post.id || idx} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="group block cursor-pointer"
                onClick={(e) => { e.preventDefault(); setSelectedPost(post); }}
             >
                <div className="overflow-hidden rounded-2xl mb-4 aspect-video bg-gray-100 shadow-lg">
                  <img 
                    src={getDirectImageUrl(post.img)} 
                    alt={post.title} 
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                    referrerPolicy="no-referrer" 
                  />
                </div>
                <div className="flex items-center gap-4 text-xs font-semibold text-brand-gray uppercase tracking-widest mb-3">
                  <span>{post.date}</span>
                  <span className="w-1 h-1 rounded-full bg-brand-orange"></span>
                  <span className="text-brand-orange">Noticias</span>
                </div>
                <h4 className="text-2xl font-display font-bold text-brand-black mb-2 group-hover:text-brand-orange transition-colors">{post.title}</h4>
                <p className="text-brand-gray text-sm leading-relaxed">{post.desc}</p>
             </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {selectedPost && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedPost(null)}
            className="fixed inset-0 z-[100] bg-brand-black/80 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl relative"
            >
              <button 
                onClick={() => setSelectedPost(null)} 
                className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors z-10"
              >
                <X size={20} />
              </button>
              
              <div className="w-full h-64 sm:h-80 relative bg-gray-100">
                <img 
                  src={getDirectImageUrl(selectedPost.img)} 
                  alt={selectedPost.title} 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer" 
                />
              </div>
              
              <div className="p-8 md:p-12">
                <div className="flex items-center gap-4 text-xs font-semibold text-brand-gray uppercase tracking-widest mb-4">
                  <span>{selectedPost.date}</span>
                  <span className="w-1 h-1 rounded-full bg-brand-orange"></span>
                  <span className="text-brand-orange">Noticias</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-brand-black mb-6 leading-tight">{selectedPost.title}</h2>
                <div className="prose prose-lg text-brand-gray max-w-none">
                  {selectedPost.content ? (
                    selectedPost.content.split('\n').map((paragraph: string, i: number) => (
                      <p key={i} className="mb-4 text-sm md:text-base leading-relaxed">{paragraph}</p>
                    ))
                  ) : (
                    <p className="text-sm md:text-base leading-relaxed italic">No hay más detalles para esta entrada.</p>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

function FAQSection() {
  const faqs = [
    { q: "¿Para cuántas personas ofrecen servicio?", a: "Ofrecemos catering para eventos desde 20 personas. Nos adaptamos a la escala de tu festejo garantizando la misma calidad." },
    { q: "¿Cómo se calcula la cantidad de piezas?", a: "Si el sushi es el plato principal, calculamos entre 14 y 16 piezas por persona. Si es una recepción o acompañamiento, calculamos entre 7 y 9 piezas." },
    { q: "¿Van con la vajilla y personal?", a: "Sí, nuestro servicio incluye las piezas de sushi, tablas de presentación premium (madera, pizarra negra), soja, wasabi, jengibre, palitos y sushimans/camareras según lo requiera el evento." },
    { q: "¿Tienen opciones para celíacos o veganos?", a: "¡Por supuesto! Diseñamos menúes paralelos sin TACC (con protocolos para evitar contaminación cruzada) y excelentes opciones veganas y vegetarianas." },
    { q: "¿Con cuánta anticipación debo reservar?", a: "Sugerimos reservar con al menos 60 días de anticipación para asegurar disponibilidad de fecha, especialmente en temporada alta (noviembre a marzo)." },
  ];

  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-brand-gray-light">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm text-brand-orange font-bold tracking-widest uppercase mb-2">Preguntas Frecuentes</h2>
          <h3 className="text-4xl md:text-5xl font-display font-light">Resolviendo tus <span className="font-bold">dudas</span></h3>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => (
             <div key={idx} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100">
               <button 
                 onMouseEnter={() => setOpenIdx(idx)}
                 onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                 className="w-full px-6 py-5 text-left flex justify-between items-center focus:outline-none"
               >
                 <span className="font-display font-semibold text-brand-black text-lg">{faq.q}</span>
                 <ChevronDown className={`shrink-0 text-brand-orange transition-transform duration-300 ${openIdx === idx ? 'rotate-180' : ''}`} />
               </button>
               <AnimatePresence>
                 {openIdx === idx && (
                   <motion.div
                     initial={{ height: 0, opacity: 0 }}
                     animate={{ height: 'auto', opacity: 1 }}
                     exit={{ height: 0, opacity: 0 }}
                     className="overflow-hidden"
                   >
                     <p className="px-6 pb-6 text-brand-gray font-light leading-relaxed">
                       {faq.a}
                     </p>
                   </motion.div>
                 )}
               </AnimatePresence>
             </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  const [formState, setFormState] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormState('submitting');
    
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get('name') as string,
      phone: formData.get('phone') as string,
      date: formData.get('date') as string,
      guests: formData.get('guests') as string,
      type: formData.get('type') as string,
      message: formData.get('message') as string,
      status: 'new',
      createdAt: new Date(),
    };

    try {
      // Import these at the top of the file: import { collection, addDoc } from 'firebase/firestore'; import { db, handleFirestoreError, OperationType } from './firebase';
      // I'll dynamically import them to avoid top-level issues since App.tsx is already large, but it's better to add them at the top.
      const { collection, addDoc, serverTimestamp } = await import('firebase/firestore');
      const { db, handleFirestoreError, OperationType } = await import('./firebase');
      
      await addDoc(collection(db, 'quotes'), {
        ...data,
        createdAt: serverTimestamp()
      });

      // Prepare WhatsApp message
      const waMsg = `🍣 *PEDIDO DE COTIZACIÓN - MINAMI* 🍣\n\n` +
        `👤 *Nombre:* ${data.name}\n` +
        `📞 *Tel/WS:* ${data.phone}\n` +
        `📅 *Fecha:* ${data.date}\n` +
        `👥 *Invitados:* ${data.guests}\n` +
        `✨ *Tipo de Evento:* ${data.type.toUpperCase()}\n` +
        `💬 *Mensaje:* ${data.message}\n\n` +
        `_Enviado desde el sitio web minamisushibar.com.ar_`;

      const waUrl = `https://wa.me/5492926547663?text=${encodeURIComponent(waMsg)}`;
      
      setFormState('success');
      
      // Open WhatsApp after a short delay
      setTimeout(() => {
        window.open(waUrl, '_blank');
      }, 1500);

      setTimeout(() => setFormState('idle'), 5000);
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      console.error(error);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      handleFirestoreError(error, OperationType.CREATE, 'quotes');
      setFormState('idle');
      alert("Hubo un error al enviar tu consulta. Por favor, escribinos por WhatsApp.");
    }
  };

  return (
    <section id="contacto" className="py-24 bg-brand-black text-white relative">
      {/* Decorative gradient */}
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-brand-orange/10 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-display font-light mb-6">Cotizá tu <span className="font-bold">evento</span></h2>
            <p className="text-gray-400 font-light mb-12 text-lg">Dejanos los detalles de tu evento y te enviaremos una propuesta personalizada a la brevedad.</p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center shrink-0 text-brand-orange">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Teléfono / WhatsApp</h4>
                  <p className="text-xl font-display">2926-547663</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center shrink-0 text-brand-orange">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Email</h4>
                  <p className="text-xl font-display">minamisushibarr@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center shrink-0 text-brand-orange">
                  <Instagram size={24} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Redes Sociales</h4>
                  <p className="text-xl font-display">@minamisushibar</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="bg-white rounded-3xl p-8 md:p-10 text-brand-black shadow-2xl relative overflow-hidden">
            {formState === 'success' ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-white z-10">
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-brand-orange mb-4">
                  <CheckCircle2 size={64} />
                </motion.div>
                <h4 className="text-2xl font-display font-bold mb-2">¡Mensaje enviado!</h4>
                <p className="text-brand-gray text-center px-6">Gracias por contactarnos. Te enviaremos una respuesta pronto.</p>
              </div>
            ) : null}

            <form onSubmit={handleSubmit} className="space-y-6">

              <div className="grid grid-cols-2 gap-6">
                <div className="col-span-2 sm:col-span-1">
                  <label htmlFor="name" className="block text-xs font-bold uppercase tracking-widest text-brand-gray mb-2">Nombre</label>
                  <input type="text" name="name" id="name" required className="w-full border-b-2 border-gray-200 bg-transparent py-2 focus:border-brand-orange focus:outline-none transition-colors" placeholder="Tu nombre" />
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <label htmlFor="phone" className="block text-xs font-bold uppercase tracking-widest text-brand-gray mb-2">Teléfono</label>
                  <input type="tel" name="phone" id="phone" required className="w-full border-b-2 border-gray-200 bg-transparent py-2 focus:border-brand-orange focus:outline-none transition-colors" placeholder="Ej: 2926 123456" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="col-span-2 sm:col-span-1">
                  <label htmlFor="date" className="block text-xs font-bold uppercase tracking-widest text-brand-gray mb-2">Fecha del Evento</label>
                  <input type="date" name="date" id="date" className="w-full border-b-2 border-gray-200 bg-transparent py-2 focus:border-brand-orange focus:outline-none transition-colors text-brand-black" />
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <label htmlFor="guests" className="block text-xs font-bold uppercase tracking-widest text-brand-gray mb-2">Invitados (aprox)</label>
                  <input type="number" name="guests" id="guests" className="w-full border-b-2 border-gray-200 bg-transparent py-2 focus:border-brand-orange focus:outline-none transition-colors text-brand-black" placeholder="Ej: 50" />
                </div>
              </div>
              
              <div>
                <label htmlFor="type" className="block text-xs font-bold uppercase tracking-widest text-brand-gray mb-2">Tipo de Evento</label>
                <select name="type" id="type" className="w-full border-b-2 border-gray-200 bg-transparent py-2 focus:border-brand-orange focus:outline-none transition-colors text-brand-black">
                  <option value="casamiento">Casamiento</option>
                  <option value="corporativo">Corporativo</option>
                  <option value="cumpleanos">Cumpleaños</option>
                  <option value="sushi_casa">Sushi en casa</option>
                  <option value="otro">Otro</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-xs font-bold uppercase tracking-widest text-brand-gray mb-2">Mensaje Adicional</label>
                <textarea name="message" id="message" rows={3} className="w-full border-b-2 border-gray-200 bg-transparent py-2 focus:border-brand-orange focus:outline-none transition-colors resize-none" placeholder="Contanos más sobre tu evento..."></textarea>
              </div>

              <motion.button 
                type="submit" 
                disabled={formState === 'submitting'}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white py-4 rounded-xl font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {formState === 'submitting' ? 'Enviando...' : 'Pedir Cotización'}
              </motion.button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-[#050505] text-white pt-20 pb-10 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2">
            <div className="mb-6 inline-block">
              <Logo size="sm" />
            </div>
            <p className="text-gray-400 font-light max-w-sm mb-6">
              Llevando la excelencia del sushi a tus eventos más importantes. Calidad premium, servicio profesional y una experiencia inolvidable.
            </p>
            <div className="flex gap-4">
              <a href="https://instagram.com/minamisushibar" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand-orange hover:border-brand-orange transition-all">
                <Instagram size={18} />
              </a>
              <a href="https://facebook.com/minamisushibar" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand-orange hover:border-brand-orange transition-all">
                <Facebook size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display font-bold text-sm tracking-widest uppercase mb-6">Enlaces</h4>
            <ul className="space-y-3">
              <li><a href="#servicios" className="text-gray-400 hover:text-white transition-colors font-light text-sm">Servicios</a></li>
              <li><a href="#menu" className="text-gray-400 hover:text-white transition-colors font-light text-sm">Menú</a></li>
              <li><a href="#galeria" className="text-gray-400 hover:text-white transition-colors font-light text-sm">Galería</a></li>
              <li><a href="#blog" className="text-gray-400 hover:text-white transition-colors font-light text-sm">Blog</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-sm tracking-widest uppercase mb-6">Contacto</h4>
            <ul className="space-y-3">
              <li className="text-gray-400 font-light text-sm">2926-547663</li>
              <li className="text-gray-400 font-light text-sm">minamisushibarr@gmail.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 font-light">
          <p>&copy; {new Date().getFullYear()} Minami Sushi Bar. Todos los derechos reservados.</p>
          <p className="mt-4 md:mt-0 flex items-center gap-2">
            Diseñado con amor para paladares exigentes.
            <a href="/admin" className="hover:text-white transition-colors" title="Acceso a Administradores">· Admin</a>
          </p>
        </div>
      </div>
    </footer>
  );
}

